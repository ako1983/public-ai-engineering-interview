# Python quickstart backend written in python

```
uvicorn main:app --reload --port=8000
```

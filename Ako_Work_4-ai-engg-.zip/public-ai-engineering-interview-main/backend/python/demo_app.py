"""
Demo application for the EMR parser and wearables analytics.

This simplified app allows you to test the functionality without the full backend.
"""

import os
import sys
import json
import traceback
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import pandas as pd
import numpy as np
from pydantic import BaseModel

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import our services
from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient,
    extract_chronic_conditions,
    extract_vital_events,
    initialize_emr_data,
    PatientHealthProfile,
    ChronicCondition,
    HealthEvent,
    Medication
)

class DemoApp:
    """Interactive demo app for the EMR parser."""
    
    def __init__(self):
        print("Initializing EMR demo app...")
        self.initialize_data()
        
    def initialize_data(self):
        """Initialize the EMR data."""
        try:
            # Initialize EMR data
            initialize_emr_data()
            print("✅ EMR data initialized successfully")
            
            # Get raw data for additional exploration
            self.synthea_data = load_sample_synthea_data()
            if not self.synthea_data:
                print("⚠️ Warning: Failed to load sample Synthea data")
                return
                
            # Parse the data
            self.patient_profile = parse_synthea_patient(self.synthea_data)
            print(f"✅ Patient data parsed: ID {self.patient_profile.patient_id}")
            print(f"  - {len(self.patient_profile.chronic_conditions)} conditions")
            print(f"  - {len(self.patient_profile.health_events)} health events")
            print(f"  - {len(self.patient_profile.medications)} medications")
            
            # Get filtered data
            self.chronic_conditions = extract_chronic_conditions("test_user_id")
            self.vital_events = extract_vital_events("test_user_id")
            print(f"✅ Filtered to {len(self.chronic_conditions)} chronic conditions")
            print(f"✅ Filtered to {len(self.vital_events)} vital events")
            
        except Exception as e:
            print(f"⚠️  Error initializing data: {e}")
            print(f"Traceback: {traceback.format_exc()}")
    
    def display_menu(self):
        """Display the main menu."""
        print("\n" + "=" * 50)
        print("EMR Parser Demo Application")
        print("=" * 50)
        print("1. View Patient Summary")
        print("2. List All Chronic Conditions")
        print("3. List Active Chronic Conditions")
        print("4. List All Health Events")
        print("5. List Vital Events")
        print("6. List Medications")
        print("7. Search Conditions by Keyword")
        print("8. Search Events by Keyword")
        print("9. Search Medications by Keyword")
        print("10. Generate Patient Health Report")
        print("0. Exit")
        print("=" * 50)
    
    def view_patient_summary(self):
        """Display a summary of the patient's health profile."""
        print("\n" + "=" * 50)
        print("Patient Health Summary")
        print("=" * 50)
        print(f"Patient ID: {self.patient_profile.patient_id}")
        print(f"Total Conditions: {len(self.patient_profile.chronic_conditions)}")
        print(f"Active Chronic Conditions: {len(self.chronic_conditions)}")
        print(f"Total Health Events: {len(self.patient_profile.health_events)}")
        print(f"Significant Health Events: {len(self.vital_events)}")
        print(f"Current Medications: {len(self.patient_profile.medications)}")
        
        # Show active chronic conditions
        if self.chronic_conditions:
            print("\nActive Chronic Conditions:")
            for i, condition in enumerate(self.chronic_conditions[:5], 1):
                print(f"  {i}. {condition.description}")
            if len(self.chronic_conditions) > 5:
                print(f"  ... and {len(self.chronic_conditions) - 5} more")
        
        # Show recent vital events
        if self.vital_events:
            print("\nRecent Significant Health Events:")
            for i, event in enumerate(self.vital_events[:5], 1):
                date_str = event.date.strftime("%Y-%m-%d")
                print(f"  {i}. {event.description} ({date_str})")
            if len(self.vital_events) > 5:
                print(f"  ... and {len(self.vital_events) - 5} more")
        
        # Show current medications
        active_meds = [m for m in self.patient_profile.medications if m.status.lower() == "active"]
        if active_meds:
            print("\nCurrent Medications:")
            for i, med in enumerate(active_meds[:5], 1):
                print(f"  {i}. {med.display}")
            if len(active_meds) > 5:
                print(f"  ... and {len(active_meds) - 5} more")
    
    def list_all_conditions(self):
        """List all conditions."""
        print("\n" + "=" * 50)
        print("All Conditions")
        print("=" * 50)
        for i, condition in enumerate(self.patient_profile.chronic_conditions, 1):
            print(f"\n{i}. {condition.description}")
            print(f"   Code: {condition.code}")
            print(f"   Status: {condition.status}")
            print(f"   Onset: {condition.onset_date}")
            if condition.severity:
                print(f"   Severity: {condition.severity}")
    
    def list_chronic_conditions(self):
        """List active chronic conditions."""
        print("\n" + "=" * 50)
        print("Active Chronic Conditions")
        print("=" * 50)
        for i, condition in enumerate(self.chronic_conditions, 1):
            print(f"\n{i}. {condition.description}")
            print(f"   Code: {condition.code}")
            print(f"   Status: {condition.status}")
            print(f"   Onset: {condition.onset_date}")
            if condition.severity:
                print(f"   Severity: {condition.severity}")
    
    def list_all_events(self):
        """List all health events."""
        print("\n" + "=" * 50)
        print("All Health Events")
        print("=" * 50)
        
        # Ask how many events to show
        try:
            count = int(input("How many events to show? (default: 20): ") or "20")
        except ValueError:
            count = 20
        
        for i, event in enumerate(self.patient_profile.health_events[:count], 1):
            print(f"\n{i}. {event.description}")
            print(f"   Type: {event.event_type}")
            print(f"   Date: {event.date}")
            if event.code:
                print(f"   Code: {event.code}")
            if event.provider:
                print(f"   Provider: {event.provider}")
        
        if len(self.patient_profile.health_events) > count:
            print(f"\n... and {len(self.patient_profile.health_events) - count} more events.")
    
    def list_vital_events(self):
        """List vital events."""
        print("\n" + "=" * 50)
        print("Significant Health Events")
        print("=" * 50)
        for i, event in enumerate(self.vital_events, 1):
            print(f"\n{i}. {event.description}")
            print(f"   Type: {event.event_type}")
            print(f"   Date: {event.date}")
            if event.code:
                print(f"   Code: {event.code}")
            if event.provider:
                print(f"   Provider: {event.provider}")
    
    def list_medications(self):
        """List medications."""
        print("\n" + "=" * 50)
        print("Medications")
        print("=" * 50)
        for i, med in enumerate(self.patient_profile.medications, 1):
            print(f"\n{i}. {med.display}")
            print(f"   Code: {med.code}")
            print(f"   Status: {med.status}")
            print(f"   Prescribed: {med.prescribed_date}")
            if med.dosage_instructions:
                print(f"   Instructions: {med.dosage_instructions}")
    
    def search_conditions(self):
        """Search conditions by keyword."""
        keyword = input("\nEnter keyword to search in conditions: ")
        matches = [c for c in self.patient_profile.chronic_conditions 
                  if keyword.lower() in c.description.lower()]
        
        print(f"\nFound {len(matches)} conditions matching '{keyword}':")
        for i, condition in enumerate(matches, 1):
            print(f"\n{i}. {condition.description}")
            print(f"   Code: {condition.code}")
            print(f"   Status: {condition.status}")
            print(f"   Onset: {condition.onset_date}")
    
    def search_events(self):
        """Search events by keyword."""
        keyword = input("\nEnter keyword to search in events: ")
        matches = [e for e in self.patient_profile.health_events 
                  if keyword.lower() in e.description.lower()]
        
        print(f"\nFound {len(matches)} events matching '{keyword}':")
        
        # Ask how many matches to show
        try:
            count = int(input("How many matches to show? (default: 20): ") or "20")
        except ValueError:
            count = 20
        
        for i, event in enumerate(matches[:count], 1):
            print(f"\n{i}. {event.description}")
            print(f"   Type: {event.event_type}")
            print(f"   Date: {event.date}")
            if event.code:
                print(f"   Code: {event.code}")
            if event.provider:
                print(f"   Provider: {event.provider}")
        
        if len(matches) > count:
            print(f"\n... and {len(matches) - count} more matches.")
    
    def search_medications(self):
        """Search medications by keyword."""
        keyword = input("\nEnter keyword to search in medications: ")
        matches = [m for m in self.patient_profile.medications 
                  if keyword.lower() in m.display.lower()]
        
        print(f"\nFound {len(matches)} medications matching '{keyword}':")
        for i, med in enumerate(matches, 1):
            print(f"\n{i}. {med.display}")
            print(f"   Code: {med.code}")
            print(f"   Status: {med.status}")
            print(f"   Prescribed: {med.prescribed_date}")
            if med.dosage_instructions:
                print(f"   Instructions: {med.dosage_instructions}")
    
    def generate_health_report(self):
        """Generate a comprehensive health report."""
        print("\n" + "=" * 60)
        print("PATIENT HEALTH REPORT")
        print("=" * 60)
        print(f"Patient ID: {self.patient_profile.patient_id}")
        print(f"Report Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        print("=" * 60)
        
        # Active Chronic Conditions
        print("\nCHRONIC CONDITIONS:")
        print("-" * 30)
        if self.chronic_conditions:
            for i, condition in enumerate(self.chronic_conditions, 1):
                onset_str = condition.onset_date.strftime("%Y-%m-%d") if condition.onset_date else "Unknown"
                print(f"{i}. {condition.description}")
                print(f"   Status: {condition.status}")
                print(f"   Onset: {onset_str}")
                if condition.severity:
                    print(f"   Severity: {condition.severity}")
                print()
        else:
            print("No active chronic conditions.")
        
        # Recent Significant Health Events
        print("\nRECENT SIGNIFICANT HEALTH EVENTS:")
        print("-" * 30)
        if self.vital_events:
            recent_events = sorted(self.vital_events, key=lambda e: e.date, reverse=True)[:10]
            for i, event in enumerate(recent_events, 1):
                date_str = event.date.strftime("%Y-%m-%d")
                print(f"{i}. {event.description}")
                print(f"   Type: {event.event_type}")
                print(f"   Date: {date_str}")
                if event.provider:
                    print(f"   Provider: {event.provider}")
                print()
        else:
            print("No significant health events.")
        
        # Current Medications
        print("\nCURRENT MEDICATIONS:")
        print("-" * 30)
        active_meds = [m for m in self.patient_profile.medications if m.status.lower() == "active"]
        if active_meds:
            for i, med in enumerate(active_meds, 1):
                print(f"{i}. {med.display}")
                if med.dosage_instructions:
                    print(f"   Instructions: {med.dosage_instructions}")
                if med.prescribed_date:
                    print(f"   Prescribed: {med.prescribed_date.strftime('%Y-%m-%d')}")
                print()
        else:
            print("No active medications.")
        
        print("\n" + "=" * 60)
        print("END OF REPORT")
        print("=" * 60)
    
    def run(self):
        """Run the demo application."""
        while True:
            self.display_menu()
            choice = input("\nEnter your choice (0-10): ")
            
            if choice == "0":
                print("\nExiting demo. Goodbye!")
                break
            elif choice == "1":
                self.view_patient_summary()
            elif choice == "2":
                self.list_all_conditions()
            elif choice == "3":
                self.list_chronic_conditions()
            elif choice == "4":
                self.list_all_events()
            elif choice == "5":
                self.list_vital_events()
            elif choice == "6":
                self.list_medications()
            elif choice == "7":
                self.search_conditions()
            elif choice == "8":
                self.search_events()
            elif choice == "9":
                self.search_medications()
            elif choice == "10":
                self.generate_health_report()
            else:
                print("\nInvalid choice. Please try again.")
            
            input("\nPress Enter to continue...")


if __name__ == "__main__":
    app = DemoApp()
    app.run()
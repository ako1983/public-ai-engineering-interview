"""
Explore EMR parser results interactively.
This script loads the FHIR data, runs the parser functions, and prints the results
in a more readable format for exploration.
"""

import sys
import os
import json
from datetime import datetime
from pprint import pprint

# Add parent directory to path so we can import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient,
    extract_chronic_conditions,
    extract_vital_events,
    initialize_emr_data
)

def explore_parse_synthea_patient():
    """Load data, parse it, and explore the results"""
    print("\n===== Exploring parse_synthea_patient results =====\n")
    
    # Load the sample data
    print("Loading sample Synthea data...")
    synthea_data = load_sample_synthea_data()
    
    if not synthea_data:
        print("Error: Failed to load sample data")
        return
    
    # Parse the data
    print("\nParsing Synthea patient data...")
    patient_profile = parse_synthea_patient(synthea_data)
    
    # Print basic info
    print(f"\nPatient ID: {patient_profile.patient_id}")
    print(f"Total chronic conditions: {len(patient_profile.chronic_conditions)}")
    print(f"Total health events: {len(patient_profile.health_events)}")
    print(f"Total medications: {len(patient_profile.medications)}")
    print(f"Last updated: {patient_profile.last_updated}")
    
    # Interactive exploration
    while True:
        print("\nWhat would you like to explore?")
        print("1. Show all chronic conditions")
        print("2. Show all health events")
        print("3. Show all medications")
        print("4. Search conditions by keyword")
        print("5. Search events by keyword")
        print("6. Search medications by keyword")
        print("7. Exit")
        
        choice = input("\nEnter your choice (1-7): ")
        
        if choice == "1":
            print("\n----- All Chronic Conditions -----")
            for i, condition in enumerate(patient_profile.chronic_conditions, 1):
                print(f"\n{i}. {condition.description}")
                print(f"   Code: {condition.code}")
                print(f"   Status: {condition.status}")
                print(f"   Onset: {condition.onset_date}")
                print(f"   Severity: {condition.severity}")
        
        elif choice == "2":
            print("\n----- All Health Events -----")
            # Only show first 20 to avoid overwhelming output
            for i, event in enumerate(patient_profile.health_events[:20], 1):
                print(f"\n{i}. {event.description}")
                print(f"   Type: {event.event_type}")
                print(f"   Date: {event.date}")
                print(f"   Code: {event.code}")
                print(f"   Provider: {event.provider}")
            
            if len(patient_profile.health_events) > 20:
                print(f"\n...and {len(patient_profile.health_events) - 20} more events.")
        
        elif choice == "3":
            print("\n----- All Medications -----")
            for i, med in enumerate(patient_profile.medications, 1):
                print(f"\n{i}. {med.display}")
                print(f"   Code: {med.code}")
                print(f"   Status: {med.status}")
                print(f"   Prescribed: {med.prescribed_date}")
                print(f"   Instructions: {med.dosage_instructions}")
        
        elif choice == "4":
            keyword = input("\nEnter keyword to search in conditions: ")
            matches = [c for c in patient_profile.chronic_conditions 
                      if keyword.lower() in c.description.lower()]
            
            print(f"\nFound {len(matches)} conditions matching '{keyword}':")
            for i, condition in enumerate(matches, 1):
                print(f"\n{i}. {condition.description}")
                print(f"   Code: {condition.code}")
                print(f"   Status: {condition.status}")
                print(f"   Onset: {condition.onset_date}")
        
        elif choice == "5":
            keyword = input("\nEnter keyword to search in events: ")
            matches = [e for e in patient_profile.health_events 
                      if keyword.lower() in e.description.lower()]
            
            print(f"\nFound {len(matches)} events matching '{keyword}':")
            for i, event in enumerate(matches[:20], 1):
                print(f"\n{i}. {event.description}")
                print(f"   Type: {event.event_type}")
                print(f"   Date: {event.date}")
                print(f"   Code: {event.code}")
            
            if len(matches) > 20:
                print(f"\n...and {len(matches) - 20} more events.")
        
        elif choice == "6":
            keyword = input("\nEnter keyword to search in medications: ")
            matches = [m for m in patient_profile.medications 
                      if keyword.lower() in m.display.lower()]
            
            print(f"\nFound {len(matches)} medications matching '{keyword}':")
            for i, med in enumerate(matches, 1):
                print(f"\n{i}. {med.display}")
                print(f"   Code: {med.code}")
                print(f"   Status: {med.status}")
                print(f"   Prescribed: {med.prescribed_date}")
        
        elif choice == "7":
            print("\nExiting exploration. Goodbye!")
            break
        
        else:
            print("\nInvalid choice. Please try again.")

def explore_filtered_functions():
    """Explore the results of the filtering functions"""
    print("\n===== Exploring filtered results =====\n")
    
    # Initialize data first
    print("Initializing EMR data...")
    initialize_emr_data()
    
    # Extract chronic conditions
    print("\nExtracting chronic conditions...")
    chronic_conditions = extract_chronic_conditions("test_user_id")
    
    print(f"\nFound {len(chronic_conditions)} chronic conditions:")
    for i, condition in enumerate(chronic_conditions, 1):
        print(f"\n{i}. {condition.description}")
        print(f"   Code: {condition.code}")
        print(f"   Status: {condition.status}")
        print(f"   Onset: {condition.onset_date}")
        if condition.severity:
            print(f"   Severity: {condition.severity}")
    
    # Extract vital events
    print("\nExtracting vital events...")
    vital_events = extract_vital_events("test_user_id")
    
    print(f"\nFound {len(vital_events)} vital events:")
    for i, event in enumerate(vital_events, 1):
        print(f"\n{i}. {event.description}")
        print(f"   Type: {event.event_type}")
        print(f"   Date: {event.date}")
        if event.code:
            print(f"   Code: {event.code}")
        if event.provider:
            print(f"   Provider: {event.provider}")

if __name__ == "__main__":
    print("EMR Parser Explorer")
    print("===================")
    print("This tool helps you explore the results of the EMR parser functions.")
    
    while True:
        print("\nWhat would you like to do?")
        print("1. Explore parse_synthea_patient results (interactive)")
        print("2. Explore filtered chronic conditions and vital events")
        print("3. Exit")
        
        choice = input("\nEnter your choice (1-3): ")
        
        if choice == "1":
            explore_parse_synthea_patient()
        elif choice == "2":
            explore_filtered_functions()
        elif choice == "3":
            print("\nExiting. Goodbye!")
            break
        else:
            print("\nInvalid choice. Please try again.")
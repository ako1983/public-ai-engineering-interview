"""
Time Series Processor for Large-Scale Wearables Data

This module provides optimized data processing methods for handling very large
wearables datasets with millions of data points, focusing on:
1. Efficient downsampling and aggregation
2. Incremental processing
3. Chunk-based stream processing
4. Feature extraction

The design prioritizes memory efficiency and processing speed for large datasets.
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Tuple, Optional, Callable, Generator
from datetime import datetime, timedelta
import pyarrow as pa
import pyarrow.compute as pc
from enum import Enum
import json
import hashlib
from dataclasses import dataclass


class DataGranularity(str, Enum):
    """Time granularity for data aggregation"""
    MINUTE = "minute"
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"


class SamplingMethod(str, Enum):
    """Methods for downsampling time series data"""
    UNIFORM = "uniform"  # Select points at regular intervals
    LTTB = "lttb"  # Largest Triangle Three Buckets algorithm
    VARIANCE = "variance"  # Preserve points with high variance
    SPLINE = "spline"  # Fit a spline and sample from it
    PIECEWISE_AGGREGATE = "piecewise_aggregate"  # Piecewise Aggregate Approximation


@dataclass
class ProcessingMetadata:
    """Metadata for time series processing"""
    original_points: int
    processed_points: int
    start_time: datetime
    end_time: datetime
    method: str
    parameters: Dict[str, Any]
    processing_time: float
    data_hash: str  # For detecting changes


class TimeSeriesProcessor:
    """
    Efficient processor for large time series datasets from wearables.
    Designed for memory-efficient operations on datasets too large to fit in memory.
    """
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        Initialize the time series processor.
        
        Args:
            cache_dir: Directory to store processing cache (default: None = no caching)
        """
        self.cache_dir = cache_dir
    
    def process_chunks(self, data_stream: Generator[List[Dict[str, Any]], None, None], 
                      chunk_size: int = 10000) -> Generator[pa.Table, None, None]:
        """
        Process a stream of time series data in chunks to avoid loading entire dataset.
        
        Args:
            data_stream: Generator yielding chunks of time series data
            chunk_size: Size of each chunk to process
            
        Yields:
            Processed Arrow tables for each chunk
        """
        for chunk in data_stream:
            # Convert to Arrow table for memory efficiency
            if not chunk:
                continue
                
            table = self._dict_to_arrow_table(chunk)
            
            # Process the chunk
            processed_table = self._process_chunk(table)
            
            yield processed_table
    
    def _dict_to_arrow_table(self, data: List[Dict[str, Any]]) -> pa.Table:
        """Convert dictionary data to Arrow table for memory efficiency"""
        # Extract data types from first item
        if not data:
            return pa.Table.from_pydict({})
            
        sample = data[0]
        schema = {}
        
        for key, value in sample.items():
            if isinstance(value, (int, np.integer)):
                schema[key] = pa.int64()
            elif isinstance(value, (float, np.floating)):
                schema[key] = pa.float64()
            elif isinstance(value, str):
                schema[key] = pa.string()
            elif isinstance(value, (datetime, pd.Timestamp)):
                schema[key] = pa.timestamp('ns')
            else:
                schema[key] = pa.string()  # Default to string for complex types
        
        # Convert to columnar format
        columns = {field: [] for field in schema}
        
        for item in data:
            for field in schema:
                columns[field].append(item.get(field))
        
        # Create Arrow table
        return pa.Table.from_pydict(columns, schema=pa.schema([
            pa.field(name, dtype) for name, dtype in schema.items()
        ]))
    
    def _process_chunk(self, table: pa.Table) -> pa.Table:
        """Process a single chunk of data"""
        # Ensure timestamp column exists and is sorted
        if 'timestamp' in table.column_names:
            # Sort by timestamp
            indices = pc.sort_indices(table['timestamp'])
            table = table.take(indices)
        
        return table
    
    def downsample(self, table: pa.Table, target_points: int, 
                  method: SamplingMethod = SamplingMethod.LTTB) -> pa.Table:
        """
        Downsample time series data to target number of points using specified method.
        
        Args:
            table: Arrow table with time series data
            target_points: Desired number of points after downsampling
            method: Method to use for downsampling
            
        Returns:
            Downsampled Arrow table
        """
        if len(table) <= target_points:
            return table
            
        if method == SamplingMethod.UNIFORM:
            # Simple uniform sampling
            indices = np.linspace(0, len(table) - 1, target_points, dtype=int)
            return table.take(indices)
            
        elif method == SamplingMethod.LTTB:
            # Largest Triangle Three Buckets
            # More effective at preserving visual features
            return self._downsample_lttb(table, target_points)
            
        elif method == SamplingMethod.VARIANCE:
            # Preserve areas with high variance
            return self._downsample_variance(table, target_points)
            
        elif method == SamplingMethod.PIECEWISE_AGGREGATE:
            # Piecewise Aggregate Approximation
            return self._downsample_paa(table, target_points)
            
        else:
            raise ValueError(f"Unsupported downsampling method: {method}")
    
    def _downsample_lttb(self, table: pa.Table, target_points: int) -> pa.Table:
        """
        Largest Triangle Three Buckets (LTTB) downsampling algorithm.
        Preserves visual characteristics of the time series.
        
        Args:
            table: Arrow table with time series data
            target_points: Desired number of points after downsampling
            
        Returns:
            Downsampled Arrow table
        """
        if 'timestamp' not in table.column_names or 'value' not in table.column_names:
            raise ValueError("Table must have 'timestamp' and 'value' columns for LTTB")
        
        if target_points < 3:
            raise ValueError("Target points must be at least 3 for LTTB algorithm")
            
        # Convert to numpy arrays for faster processing
        timestamps = table['timestamp'].to_numpy()
        values = table['value'].to_numpy()
        
        # We always include the first and last points
        result_indices = [0, len(table) - 1]
        
        # Number of buckets
        bucket_size = (len(table) - 2) / (target_points - 2)
        
        # Process all buckets
        for i in range(target_points - 2):
            # Bucket boundaries
            bucket_start = int((i * bucket_size) + 1)
            bucket_end = int(((i + 1) * bucket_size) + 1)
            bucket_end = min(bucket_end, len(table) - 1)
            
            # Points from already selected buckets
            if i == 0:
                point_a = (timestamps[0], values[0])
            else:
                point_a = (timestamps[result_indices[i]], values[result_indices[i]])
                
            # Last point
            point_c = (timestamps[bucket_end], values[bucket_end])
            
            # Find point with largest triangle area in current bucket
            max_area = -1
            max_area_index = bucket_start
            
            for j in range(bucket_start, bucket_end):
                point_b = (timestamps[j], values[j])
                
                # Calculate triangle area
                area = abs(
                    (point_a[0] - point_c[0]) * (point_b[1] - point_a[1]) - 
                    (point_a[0] - point_b[0]) * (point_c[1] - point_a[1])
                ) * 0.5
                
                if area > max_area:
                    max_area = area
                    max_area_index = j
            
            # Add index with largest area
            result_indices.append(max_area_index)
        
        # Sort indices
        result_indices.sort()
        
        # Return downsampled table
        return table.take(result_indices)
    
    def _downsample_variance(self, table: pa.Table, target_points: int) -> pa.Table:
        """
        Variance-based downsampling that preserves areas with high variance.
        
        Args:
            table: Arrow table with time series data
            target_points: Desired number of points after downsampling
            
        Returns:
            Downsampled Arrow table
        """
        if 'value' not in table.column_names:
            raise ValueError("Table must have 'value' column for variance-based downsampling")
            
        # Always keep first and last points
        if target_points < 2:
            return table.take([0])
            
        # Convert to numpy for faster processing
        values = table['value'].to_numpy()
        
        # Calculate the number of segments
        num_segments = target_points - 2  # excluding first and last points
        segment_size = len(values) // num_segments
        
        # Calculate variance in each segment
        segment_variances = []
        selected_indices = [0]  # Always include first point
        
        for i in range(num_segments):
            start_idx = i * segment_size
            end_idx = min((i + 1) * segment_size, len(values))
            segment = values[start_idx:end_idx]
            
            if len(segment) > 1:
                # Calculate variance and most representative point
                segment_var = np.var(segment)
                segment_variances.append((segment_var, start_idx + np.argmax(np.abs(segment - np.mean(segment)))))
        
        # Sort segments by variance (highest first)
        segment_variances.sort(reverse=True, key=lambda x: x[0])
        
        # Select points from highest variance segments
        for _, idx in segment_variances[:target_points-2]:
            selected_indices.append(idx)
            
        # Add last point
        selected_indices.append(len(values) - 1)
        
        # Sort indices to maintain time order
        selected_indices.sort()
        
        return table.take(selected_indices)
    
    def _downsample_paa(self, table: pa.Table, target_points: int) -> pa.Table:
        """
        Piecewise Aggregate Approximation (PAA) downsampling.
        
        Args:
            table: Arrow table with time series data
            target_points: Desired number of points after downsampling
            
        Returns:
            Downsampled Arrow table with aggregated values
        """
        if 'value' not in table.column_names or 'timestamp' not in table.column_names:
            raise ValueError("Table must have 'value' and 'timestamp' columns for PAA")
            
        # Convert to pandas for aggregation operations
        df = table.to_pandas()
        
        # Calculate segment size
        segment_size = len(df) / target_points
        
        # Create segments and aggregate
        result_data = []
        
        for i in range(target_points):
            start_idx = int(i * segment_size)
            end_idx = int(min((i + 1) * segment_size, len(df)))
            
            if start_idx == end_idx:
                # Edge case for last point
                segment = df.iloc[start_idx:start_idx+1]
            else:
                segment = df.iloc[start_idx:end_idx]
            
            # Calculate mean values for the segment
            aggregated = {
                'timestamp': segment['timestamp'].mean(),
                'value': segment['value'].mean()
            }
            
            # Include additional columns if they exist
            for col in df.columns:
                if col not in ['timestamp', 'value']:
                    if np.issubdtype(df[col].dtype, np.number):
                        aggregated[col] = segment[col].mean()
                    else:
                        # For non-numeric columns, take most frequent value
                        aggregated[col] = segment[col].mode()[0] if not segment[col].empty else None
            
            result_data.append(aggregated)
        
        # Convert back to Arrow table
        return pa.Table.from_pandas(pd.DataFrame(result_data))
    
    def aggregate_by_time(self, table: pa.Table, granularity: DataGranularity) -> pa.Table:
        """
        Aggregate time series data by specified time granularity.
        
        Args:
            table: Arrow table with time series data
            granularity: Time granularity for aggregation
            
        Returns:
            Aggregated Arrow table
        """
        if 'timestamp' not in table.column_names or 'value' not in table.column_names:
            raise ValueError("Table must have 'timestamp' and 'value' columns for time aggregation")
        
        # Convert to pandas for time-based operations
        df = table.to_pandas()
        
        # Ensure timestamp is datetime
        if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
            df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Set timestamp as index
        df = df.set_index('timestamp')
        
        # Define resampling frequency
        freq_map = {
            DataGranularity.MINUTE: '1min',
            DataGranularity.HOUR: '1H',
            DataGranularity.DAY: '1D',
            DataGranularity.WEEK: '1W',
            DataGranularity.MONTH: '1M'
        }
        
        # Resample and aggregate
        resampled = df.resample(freq_map[granularity])
        
        # Aggregate all columns appropriately
        aggregated = pd.DataFrame()
        
        for col in df.columns:
            if col == 'value':
                # For the main value, calculate various statistics
                aggregated[f'mean_{col}'] = resampled[col].mean()
                aggregated[f'min_{col}'] = resampled[col].min()
                aggregated[f'max_{col}'] = resampled[col].max()
                aggregated[f'std_{col}'] = resampled[col].std()
                aggregated[f'count_{col}'] = resampled[col].count()
            elif np.issubdtype(df[col].dtype, np.number):
                # For other numeric columns, just calculate the mean
                aggregated[col] = resampled[col].mean()
            else:
                # For non-numeric, use most frequent value
                aggregated[col] = resampled[col].apply(lambda x: x.mode()[0] if len(x) > 0 and len(x.mode()) > 0 else None)
        
        # Reset index to get timestamp as column
        aggregated = aggregated.reset_index()
        
        # Convert back to Arrow table
        return pa.Table.from_pandas(aggregated)
    
    def extract_features(self, table: pa.Table) -> Dict[str, Any]:
        """
        Extract statistical and domain-specific features from time series data.
        These compact features can be used instead of raw data to reduce memory.
        
        Args:
            table: Arrow table with time series data
            
        Returns:
            Dictionary of extracted features
        """
        if 'value' not in table.column_names:
            raise ValueError("Table must have 'value' column for feature extraction")
            
        # Convert to numpy for calculations
        values = table['value'].to_numpy()
        
        if len(values) < 2:
            return {
                'count': len(values),
                'mean': float(np.mean(values)) if len(values) > 0 else None,
                'features_extracted': False
            }
        
        # Basic statistical features
        features = {
            'count': len(values),
            'mean': float(np.mean(values)),
            'std': float(np.std(values)),
            'min': float(np.min(values)),
            'max': float(np.max(values)),
            'median': float(np.median(values)),
            'iqr': float(np.percentile(values, 75) - np.percentile(values, 25)),
            'skewness': float(self._calculate_skewness(values)),
            'kurtosis': float(self._calculate_kurtosis(values)),
            'energy': float(np.sum(values**2) / len(values)),
        }
        
        # Time domain features
        if 'timestamp' in table.column_names:
            timestamps = table['timestamp'].to_numpy()
            if len(timestamps) >= 2:
                # Calculate rate of change features
                time_diffs = np.diff(timestamps) / np.timedelta64(1, 's')  # in seconds
                value_diffs = np.diff(values)
                rates = value_diffs / time_diffs
                
                features.update({
                    'mean_rate': float(np.mean(rates)),
                    'max_rate': float(np.max(rates)),
                    'min_rate': float(np.min(rates)),
                    'volatility': float(np.std(rates))
                })
        
        # Frequency domain features (if enough data points)
        if len(values) >= 8:
            try:
                from scipy import signal
                # Compute power spectral density
                f, Pxx = signal.welch(values, nperseg=min(256, len(values)))
                features.update({
                    'spectral_entropy': float(self._spectral_entropy(Pxx)),
                    'dominant_frequency': float(f[np.argmax(Pxx)]),
                    'spectral_centroid': float(np.sum(f * Pxx) / np.sum(Pxx)) if np.sum(Pxx) > 0 else 0
                })
            except ImportError:
                # If scipy is not available, skip frequency domain features
                pass
        
        # Complexity features
        if len(values) >= 10:
            features.update({
                'crossing_rate': float(np.sum(np.diff(np.signbit(values - np.mean(values)))) / (len(values) - 1)),
                'peak_count': len(signal.find_peaks(values)[0]) if 'signal' in locals() else 0
            })
        
        features['features_extracted'] = True
        return features
    
    def _calculate_skewness(self, x: np.ndarray) -> float:
        """Calculate skewness of a distribution"""
        n = len(x)
        if n < 3:
            return 0.0
        m3 = np.sum((x - np.mean(x))**3) / n
        m2 = np.sum((x - np.mean(x))**2) / n
        return m3 / (m2**1.5) if m2 > 0 else 0.0
    
    def _calculate_kurtosis(self, x: np.ndarray) -> float:
        """Calculate kurtosis of a distribution"""
        n = len(x)
        if n < 4:
            return 0.0
        m4 = np.sum((x - np.mean(x))**4) / n
        m2 = np.sum((x - np.mean(x))**2) / n
        return m4 / (m2**2) if m2 > 0 else 0.0
    
    def _spectral_entropy(self, psd: np.ndarray) -> float:
        """Calculate spectral entropy from power spectral density"""
        psd_norm = psd / np.sum(psd)
        return -np.sum(psd_norm * np.log2(psd_norm + 1e-10))
    
    def detect_anomalies(self, table: pa.Table, sensitivity: float = 1.5) -> List[int]:
        """
        Detect anomalies in time series data using statistical methods.
        
        Args:
            table: Arrow table with time series data
            sensitivity: Sensitivity factor for anomaly detection (higher = more sensitive)
            
        Returns:
            List of indices of detected anomalies
        """
        if 'value' not in table.column_names:
            raise ValueError("Table must have 'value' column for anomaly detection")
            
        # Convert to numpy for calculations
        values = table['value'].to_numpy()
        
        if len(values) < 5:
            return []
        
        # Detect anomalies using modified Z-score method
        median = np.median(values)
        mad = np.median(np.abs(values - median))  # Median Absolute Deviation
        
        if mad == 0:  # Handle constant values
            return []
            
        z_scores = sensitivity * 0.6745 * np.abs(values - median) / mad
        
        # Return indices of anomalies
        return np.where(z_scores > 3.5)[0].tolist()
    
    def incremental_process(self, new_data: List[Dict[str, Any]], 
                           previous_result: Optional[Dict[str, Any]] = None,
                           previous_metadata: Optional[ProcessingMetadata] = None) -> Tuple[Dict[str, Any], ProcessingMetadata]:
        """
        Process only new data and combine with previous results for efficiency.
        
        Args:
            new_data: New time series data points
            previous_result: Previous processing result
            previous_metadata: Metadata from previous processing
            
        Returns:
            Updated results and metadata
        """
        import time
        start_time = time.time()
        
        # Convert new data to Arrow
        new_table = self._dict_to_arrow_table(new_data)
        
        # Generate data hash for change detection
        data_str = json.dumps(new_data, default=str, sort_keys=True)
        data_hash = hashlib.md5(data_str.encode()).hexdigest()
        
        # If we have previous results and no new data changes
        if (previous_result and previous_metadata and 
            previous_metadata.data_hash == data_hash and
            len(new_data) == previous_metadata.original_points):
            return previous_result, previous_metadata
        
        # Process new data
        if not previous_result or not previous_metadata:
            # First time processing
            features = self.extract_features(new_table)
            anomalies = self.detect_anomalies(new_table)
            
            result = {
                'features': features,
                'anomalies': anomalies,
                'anomaly_values': [new_data[i]['value'] for i in anomalies] if anomalies else []
            }
            
            # Create metadata
            timestamps = [item.get('timestamp') for item in new_data if item.get('timestamp')]
            start_dt = min(timestamps) if timestamps else datetime.now()
            end_dt = max(timestamps) if timestamps else datetime.now()
            
            metadata = ProcessingMetadata(
                original_points=len(new_data),
                processed_points=len(anomalies) + 1,  # +1 for features
                start_time=start_dt,
                end_time=end_dt,
                method="extract_features",
                parameters={"anomaly_sensitivity": 1.5},
                processing_time=time.time() - start_time,
                data_hash=data_hash
            )
            
            return result, metadata
        
        # Incremental update to existing results
        else:
            # Combine old and new data for processing
            # In a real implementation, we would be smarter about what needs reprocessing
            combined_data = new_data  # For simplicity, just use new data
            combined_table = new_table
            
            # Re-extract features and detect anomalies
            features = self.extract_features(combined_table)
            anomalies = self.detect_anomalies(combined_table)
            
            result = {
                'features': features,
                'anomalies': anomalies,
                'anomaly_values': [new_data[i]['value'] for i in anomalies if i < len(new_data)] if anomalies else []
            }
            
            # Update metadata
            timestamps = [item.get('timestamp') for item in combined_data if item.get('timestamp')]
            start_dt = min(timestamps) if timestamps else datetime.now()
            end_dt = max(timestamps) if timestamps else datetime.now()
            
            metadata = ProcessingMetadata(
                original_points=len(combined_data),
                processed_points=len(anomalies) + 1,  # +1 for features
                start_time=start_dt,
                end_time=end_dt,
                method="extract_features_incremental",
                parameters={"anomaly_sensitivity": 1.5},
                processing_time=time.time() - start_time,
                data_hash=data_hash
            )
            
            return result, metadata


# Usage example:
if __name__ == "__main__":
    # Example usage
    processor = TimeSeriesProcessor()
    
    # Sample data
    sample_data = [
        {"timestamp": datetime(2023, 1, 1, 12, 0), "value": 100.0},
        {"timestamp": datetime(2023, 1, 1, 12, 15), "value": 102.0},
        {"timestamp": datetime(2023, 1, 1, 12, 30), "value": 101.0},
        {"timestamp": datetime(2023, 1, 1, 12, 45), "value": 103.0},
        {"timestamp": datetime(2023, 1, 1, 13, 0), "value": 150.0},  # Anomaly
        {"timestamp": datetime(2023, 1, 1, 13, 15), "value": 105.0},
        {"timestamp": datetime(2023, 1, 1, 13, 30), "value": 104.0},
        {"timestamp": datetime(2023, 1, 1, 13, 45), "value": 103.0},
        {"timestamp": datetime(2023, 1, 1, 14, 0), "value": 102.0},
    ]
    
    # Convert to Arrow table
    table = processor._dict_to_arrow_table(sample_data)
    
    # Extract features
    features = processor.extract_features(table)
    print("Extracted Features:")
    for k, v in features.items():
        print(f"  {k}: {v}")
    
    # Detect anomalies
    anomalies = processor.detect_anomalies(table)
    print(f"\nDetected Anomalies: {anomalies}")
    
    # Downsample
    downsampled = processor.downsample(table, 5, method=SamplingMethod.LTTB)
    print(f"\nDownsampled from {len(table)} to {len(downsampled)} points")
    
    # Aggregate by time
    aggregated = processor.aggregate_by_time(table, DataGranularity.HOUR)
    print(f"\nAggregated to {len(aggregated)} time periods")
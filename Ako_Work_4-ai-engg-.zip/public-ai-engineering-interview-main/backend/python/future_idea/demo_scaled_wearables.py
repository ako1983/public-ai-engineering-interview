#!/usr/bin/env python
"""
Demonstration of Scaled Wearables Analytics

This script demonstrates the integration of all components for large-scale
wearables data analytics, including:

1. Memory-efficient data processing
2. Time window partitioning
3. RAG-enhanced health insights
4. Context window optimization
5. Temporal compression for historical data

It simulates processing years of wearables data while maintaining 
reasonable memory usage and generating health insights with RAG.
"""

import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random
import time
import json
import tempfile
from typing import List, Dict, Any, Optional
import gc
import math
import argparse

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import components
try:
    from future_idea.data_processing.time_series_processor import (
        TimeSeriesProcessor, SamplingMethod, DataGranularity
    )
    from future_idea.memory_management.memory_efficient_analytics import (
        MemoryEfficientAnalytics, TimeWindow, CompressionLevel
    )
    from future_idea.rag_integration.health_rag_engine import (
        HealthKnowledgeBase, WearablesRAGEngine, ContextWindowOptimizer, 
        KnowledgeCategory
    )
    COMPONENTS_AVAILABLE = True
except ImportError:
    print("Warning: Some components not available. Running in simulation mode.")
    COMPONENTS_AVAILABLE = False


def generate_synthetic_dataset(output_dir: str, 
                             years: int = 3, 
                             users: int = 5,
                             sampling_rate: str = '15min') -> Dict[str, str]:
    """
    Generate synthetic wearables dataset spanning multiple years.
    
    Args:
        output_dir: Directory to save generated data
        years: Number of years of data to generate
        users: Number of users to generate data for
        sampling_rate: Data sampling rate
        
    Returns:
        Dict mapping metric to file path
    """
    print(f"Generating {years} years of synthetic data for {users} users...")
    os.makedirs(output_dir, exist_ok=True)
    
    # Define date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365 * years)
    date_range = pd.date_range(start=start_date, end=end_date, freq=sampling_rate)
    
    # Define metrics and their baseline parameters
    metrics = {
        'heart_rate': {
            'baseline': 70,
            'daily_amplitude': 10,
            'noise': 5,
            'trend': 0,
            'seasonality': {'period': 24, 'amplitude': 10}  # 24-hour cycle
        },
        'glucose': {
            'baseline': 5.5,  # mmol/L
            'daily_amplitude': 1.5,
            'noise': 0.8,
            'trend': 0,
            'seasonality': {'period': 6, 'amplitude': 1.2}  # 6-hour cycle (meals)
        },
        'steps': {
            'baseline': 500,
            'daily_amplitude': 2000,
            'noise': 200,
            'trend': 0,
            'seasonality': {'period': 24, 'amplitude': 2000}  # 24-hour cycle
        },
        'sleep': {
            'baseline': 4,  # hours
            'daily_amplitude': 4,
            'noise': 1,
            'trend': 0,
            'seasonality': {'period': 24, 'amplitude': 4}  # 24-hour cycle
        }
    }
    
    # Generate data for each metric and user
    file_paths = {}
    
    for metric, params in metrics.items():
        print(f"Generating {metric} data...")
        
        all_user_data = []
        for user_id in range(1, users + 1):
            # Create user-specific parameters
            user_params = params.copy()
            user_params['baseline'] += random.uniform(-params['daily_amplitude'] * 0.2, 
                                                      params['daily_amplitude'] * 0.2)
            user_params['trend'] = random.uniform(-0.1, 0.1) * params['baseline'] / (365 * years)
            
            # Generate timestamps and initialize values
            user_data = []
            
            # Generate values for each timestamp
            for i, timestamp in enumerate(date_range):
                # Calculate days since start
                days_elapsed = (timestamp - start_date).days
                
                # Base value with trend
                value = user_params['baseline'] + days_elapsed * user_params['trend']
                
                # Add daily cycle (higher during day, lower at night)
                hour_in_day = timestamp.hour + timestamp.minute / 60
                daily_cycle = math.sin((hour_in_day - 4) * 2 * math.pi / 24)  # Lowest at 4 AM
                value += daily_cycle * user_params['daily_amplitude']
                
                # Add seasonality if defined
                if 'seasonality' in user_params:
                    period = user_params['seasonality']['period']
                    amplitude = user_params['seasonality']['amplitude']
                    seasonal_component = math.sin(i * 2 * math.pi / (period * (60 / 15)))  # Adjust for 15min samples
                    value += seasonal_component * amplitude
                
                # Add random noise
                value += random.normalvariate(0, user_params['noise'])
                
                # Add occasional anomalies (1% chance)
                if random.random() < 0.01:
                    value += random.choice([-1, 1]) * random.uniform(1, 3) * user_params['noise']
                
                # Ensure non-negative values for some metrics
                if metric in ['heart_rate', 'steps', 'sleep']:
                    value = max(0, value)
                
                # Add to user data
                user_data.append({
                    'timestamp': timestamp,
                    'user_id': f"user_{user_id:03d}",
                    'value': value,
                    'device_id': f"device_{random.randint(1, 3):03d}",
                    'metric': metric
                })
            
            all_user_data.extend(user_data)
            
            # Force garbage collection after each user
            gc.collect()
        
        # Convert to DataFrame and save to parquet
        output_path = os.path.join(output_dir, f"{metric}_data.parquet")
        
        # Write in chunks to avoid memory issues
        chunk_size = 1000000  # 1 million rows per chunk
        num_chunks = math.ceil(len(all_user_data) / chunk_size)
        
        for i in range(num_chunks):
            start_idx = i * chunk_size
            end_idx = min((i + 1) * chunk_size, len(all_user_data))
            chunk_data = all_user_data[start_idx:end_idx]
            
            chunk_df = pd.DataFrame(chunk_data)
            
            # Write to parquet (append mode for chunks after the first)
            if i == 0:
                chunk_df.to_parquet(output_path, index=False)
            else:
                chunk_df.to_parquet(output_path, index=False, append=True)
            
            del chunk_df, chunk_data
            gc.collect()
        
        print(f"Generated {len(all_user_data)} records for {metric}")
        file_paths[metric] = output_path
        
        # Force garbage collection
        del all_user_data
        gc.collect()
    
    return file_paths


def process_heart_rate_data(data_path: str, user_id: str = None) -> Dict[str, Any]:
    """
    Process heart rate data using the memory-efficient approach.
    
    Args:
        data_path: Path to heart rate data file
        user_id: Optional user ID to filter by
        
    Returns:
        Analysis results
    """
    print(f"Processing heart rate data from {data_path}...")
    
    # Initialize memory-efficient analytics
    analytics = MemoryEfficientAnalytics(max_memory_mb=500)
    
    # Define filter for specific user if provided
    user_filter = None
    if user_id:
        def user_filter(df):
            return df['user_id'] == user_id
    
    # Define heart rate processor function
    def process_heartrate(df: pd.DataFrame) -> Dict[str, Any]:
        if 'value' not in df.columns:
            return {}
        
        # Filter by user if specified
        if user_id and 'user_id' in df.columns:
            df = df[df['user_id'] == user_id]
            
        if df.empty:
            return {}
        
        # Extract values
        hr_values = df['value'].values
        
        # Calculate resting heart rate (lowest 10%)
        resting_values = sorted(hr_values)[:max(1, int(len(hr_values) * 0.1))]
        avg_resting_hr = sum(resting_values) / len(resting_values) if resting_values else 0
        
        # Calculate max heart rate (highest 5%)
        max_hr_values = sorted(hr_values, reverse=True)[:max(1, int(len(hr_values) * 0.05))]
        avg_max_hr = sum(max_hr_values) / len(max_hr_values) if max_hr_values else 0
        
        # Calculate heart rate variability (standard deviation as a simple approximation)
        hrv = np.std(hr_values) if len(hr_values) > 1 else 0
        
        # Detect anomalies (values that are 30% higher than average)
        avg_hr = np.mean(hr_values)
        anomaly_threshold = 1.3 * avg_hr
        anomalies = (hr_values > anomaly_threshold).sum()
        
        # Get time range if timestamp column exists
        time_range = None
        if 'timestamp' in df.columns:
            min_time = df['timestamp'].min()
            max_time = df['timestamp'].max()
            time_range = (min_time, max_time)
        
        return {
            'resting_heart_rate': float(avg_resting_hr),
            'max_heart_rate': float(avg_max_hr),
            'heart_rate_variability': float(hrv),
            'average_heart_rate': float(avg_hr),
            'anomalies_detected': int(anomalies),
            'sample_count': len(hr_values),
            'time_range': str(time_range) if time_range else None
        }
    
    # Define priority filter for anomalies
    def priority_filter(df: pd.DataFrame) -> pd.Series:
        if 'value' not in df.columns:
            return pd.Series([False] * len(df))
            
        # Calculate mean of this chunk
        chunk_mean = df['value'].mean()
        
        # Mark values that are significantly higher or lower
        return (df['value'] > chunk_mean * 1.3) | (df['value'] < chunk_mean * 0.7)
    
    # Process the data using progressive loading
    start_time = time.time()
    results = analytics.progressive_load_and_analyze(
        data_path, 
        process_heartrate,
        priority_filter=priority_filter
    )
    processing_time = time.time() - start_time
    
    # Add processing metadata
    results['processing_time'] = processing_time
    
    print(f"Heart rate analysis completed in {processing_time:.2f} seconds")
    return results


def process_glucose_data(data_path: str, user_id: str = None) -> Dict[str, Any]:
    """
    Process glucose data using the partitioning approach.
    
    Args:
        data_path: Path to glucose data file
        user_id: Optional user ID to filter by
        
    Returns:
        Analysis results
    """
    print(f"Processing glucose data from {data_path}...")
    
    # Initialize memory-efficient analytics
    analytics = MemoryEfficientAnalytics(max_memory_mb=500)
    
    # First, partition the data by day
    start_time = time.time()
    partitions = analytics.partition_by_time(data_path, 'timestamp', TimeWindow.DAY)
    partitioning_time = time.time() - start_time
    
    print(f"Partitioned data into {len(partitions)} daily windows in {partitioning_time:.2f} seconds")
    
    # Apply compression to historical partitions
    compression_strategy = {
        '30d': CompressionLevel.LOW,      # Last 30 days: low compression
        '90d': CompressionLevel.MEDIUM,   # 31-90 days ago: medium compression
        '365d': CompressionLevel.HIGH,    # 91-365 days ago: high compression
        'older': CompressionLevel.HIGH    # Older than 365 days: high compression
    }
    
    start_time = time.time()
    compressed_partitions = analytics.compress_historical_data(partitions, compression_strategy)
    compression_time = time.time() - start_time
    
    print(f"Applied temporal compression in {compression_time:.2f} seconds")
    
    # Define glucose processor function
    def process_glucose(df: pd.DataFrame) -> Dict[str, Any]:
        if 'value' not in df.columns:
            return {}
        
        # Filter by user if specified
        if user_id and 'user_id' in df.columns:
            df = df[df['user_id'] == user_id]
            
        if df.empty:
            return {}
        
        # Extract values
        glucose_values = df['value'].values
        
        # Calculate average glucose
        avg_glucose = float(np.mean(glucose_values))
        
        # Calculate time in range (3.9-10.0 mmol/L)
        in_range = ((glucose_values >= 3.9) & (glucose_values <= 10.0)).sum()
        time_in_range = float(in_range / len(glucose_values) * 100) if len(glucose_values) > 0 else 0
        
        # Calculate glucose variability (coefficient of variation)
        cv = float(np.std(glucose_values) / avg_glucose * 100) if avg_glucose > 0 else 0
        
        # Count hypoglycemic episodes (<3.9 mmol/L)
        hypo_mask = glucose_values < 3.9
        hypo_episodes = 0
        in_episode = False
        
        for is_hypo in hypo_mask:
            if is_hypo and not in_episode:
                hypo_episodes += 1
                in_episode = True
            elif not is_hypo:
                in_episode = False
        
        # Count hyperglycemic episodes (>10.0 mmol/L)
        hyper_mask = glucose_values > 10.0
        hyper_episodes = 0
        in_episode = False
        
        for is_hyper in hyper_mask:
            if is_hyper and not in_episode:
                hyper_episodes += 1
                in_episode = True
            elif not is_hyper:
                in_episode = False
        
        return {
            'average_glucose': avg_glucose,
            'time_in_range': time_in_range,
            'glucose_variability': cv,
            'hypo_episodes': hypo_episodes,
            'hyper_episodes': hyper_episodes,
            'sample_count': len(glucose_values)
        }
    
    # Process the partitioned data
    start_time = time.time()
    results = analytics.process_partitioned_data(compressed_partitions, process_glucose)
    processing_time = time.time() - start_time
    
    # Add processing metadata
    results['partitioning_time'] = partitioning_time
    results['compression_time'] = compression_time
    results['processing_time'] = processing_time
    results['partition_count'] = len(partitions)
    results['compressed_count'] = len(compressed_partitions)
    
    print(f"Glucose analysis completed in {processing_time:.2f} seconds")
    
    # Clean up temporary files
    analytics.clear_temp_data()
    
    return results


def generate_health_insights(heartrate_results: Dict[str, Any], 
                           glucose_results: Dict[str, Any],
                           user_context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate health insights using RAG integration.
    
    Args:
        heartrate_results: Heart rate analysis results
        glucose_results: Glucose analysis results
        user_context: User context information
        
    Returns:
        Health insights with RAG integration
    """
    print("Generating health insights using RAG integration...")
    
    # If components not available, generate mock insights
    if not COMPONENTS_AVAILABLE:
        return _generate_mock_insights(heartrate_results, glucose_results, user_context)
    
    # Initialize RAG components
    knowledge_base = HealthKnowledgeBase()
    knowledge_base.initialize()
    
    rag_engine = WearablesRAGEngine(knowledge_base=knowledge_base)
    
    # Format wearables analytics results for RAG
    analysis_results = {
        'heartrate_analysis': {
            'resting_hr_trend': {
                'average_value': heartrate_results.get('resting_heart_rate', 0),
                'trend_direction': 'stable'  # Mock trend direction
            },
            'hrv_trend': {
                'average_value': heartrate_results.get('heart_rate_variability', 0),
                'trend_direction': 'stable'  # Mock trend direction
            },
            'anomaly_count': heartrate_results.get('anomalies_detected', 0),
            'risk_factors': []  # Would be populated based on heart rate patterns
        },
        'glucose_analysis': {
            'average_glucose_trend': {
                'average_value': glucose_results.get('average_glucose', 0),
                'trend_direction': 'stable'  # Mock trend direction
            },
            'time_in_range_trend': {
                'average_value': glucose_results.get('time_in_range', 0),
                'trend_direction': 'stable'  # Mock trend direction
            },
            'variability_trend': {
                'average_value': glucose_results.get('glucose_variability', 0),
                'trend_direction': 'stable'  # Mock trend direction
            },
            'dawn_phenomenon_severity': None,  # Would require morning glucose pattern analysis
            'hypo_episodes': glucose_results.get('hypo_episodes', 0),
            'hyper_episodes': glucose_results.get('hyper_episodes', 0),
            'risk_factors': []  # Would be populated based on glucose patterns
        }
    }
    
    # Generate insights
    start_time = time.time()
    rag_result = rag_engine.generate_insights(analysis_results, user_context)
    processing_time = time.time() - start_time
    
    # Format results
    insights = {
        'health_insights': rag_result.insight,
        'supporting_docs': [
            {
                'content': doc.content[:100] + '...' if len(doc.content) > 100 else doc.content,
                'source': doc.metadata.get('source', 'unknown'),
                'relevance': doc.relevance_score
            } for doc in rag_result.supporting_docs
        ],
        'processing_time': processing_time,
        'tokens_used': rag_result.tokens_used
    }
    
    print(f"Health insights generated in {processing_time:.2f} seconds")
    return insights


def _generate_mock_insights(heartrate_results: Dict[str, Any], 
                          glucose_results: Dict[str, Any],
                          user_context: Dict[str, Any]) -> Dict[str, Any]:
    """Generate mock insights when RAG components are not available"""
    mock_insight = """# Health Insights

## Cardiovascular Health
Based on your heart rate data (average resting heart rate of {rhr} bpm), your cardiovascular health appears {cv_status}. Your heart rate variability of {hrv} indicates {hrv_status}.

## Metabolic Health
Your average glucose of {avg_glucose} mmol/L is {glucose_status}. You maintain glucose levels in the healthy range {tir}% of the time, which is {tir_status}.

## Recommendations
1. Continue regular physical activity to maintain cardiovascular health
2. Consider monitoring your glucose levels around meals to identify specific food triggers
3. Establish consistent sleep and wake times to improve overall health metrics
"""
    
    # Format with actual values
    rhr = heartrate_results.get('resting_heart_rate', 70)
    hrv = heartrate_results.get('heart_rate_variability', 50)
    avg_glucose = glucose_results.get('average_glucose', 5.5)
    tir = glucose_results.get('time_in_range', 80)
    
    # Determine status descriptions
    cv_status = "excellent" if rhr < 60 else "good" if rhr < 70 else "moderate" if rhr < 80 else "concerning"
    hrv_status = "excellent autonomic balance" if hrv > 50 else "good stress resilience" if hrv > 30 else "moderate stress resilience" if hrv > 20 else "elevated stress indicators"
    glucose_status = "optimal" if 4.0 <= avg_glucose <= 5.6 else "elevated" if avg_glucose < 7.0 else "high"
    tir_status = "excellent" if tir > 90 else "good" if tir > 80 else "moderate" if tir > 70 else "needs improvement"
    
    # Format the insight
    formatted_insight = mock_insight.format(
        rhr=f"{rhr:.1f}",
        hrv=f"{hrv:.1f}",
        cv_status=cv_status,
        hrv_status=hrv_status,
        avg_glucose=f"{avg_glucose:.1f}",
        glucose_status=glucose_status,
        tir=f"{tir:.1f}",
        tir_status=tir_status
    )
    
    # Create mock supporting docs
    supporting_docs = [
        {
            'content': "Normal resting heart rate for adults ranges from 60-100 bpm. Athletes may have lower resting heart rates...",
            'source': "cardiovascular/guidelines.txt",
            'relevance': 0.92
        },
        {
            'content': "Heart rate variability (HRV) is a measure of variation in time between heartbeats. Higher HRV generally...",
            'source': "cardiovascular/hrv_research.txt",
            'relevance': 0.87
        },
        {
            'content': "Normal blood glucose ranges are 3.9-5.6 mmol/L (70-100 mg/dL) when fasting and below 7.8 mmol/L...",
            'source': "diabetes/glucose_targets.txt",
            'relevance': 0.94
        }
    ]
    
    return {
        'health_insights': formatted_insight,
        'supporting_docs': supporting_docs,
        'processing_time': 0.5,
        'tokens_used': 1200
    }


def optimize_for_context_window(heartrate_results: Dict[str, Any],
                              glucose_results: Dict[str, Any],
                              raw_data_sample: pd.DataFrame,
                              max_tokens: int = 6000) -> Dict[str, Any]:
    """
    Optimize wearables data for LLM context window.
    
    Args:
        heartrate_results: Heart rate analysis results
        glucose_results: Glucose analysis results
        raw_data_sample: Sample of raw wearables data
        max_tokens: Maximum tokens for context window
        
    Returns:
        Optimized data for context window
    """
    print(f"Optimizing data for {max_tokens} token context window...")
    
    # If components not available, return a simple summary
    if not COMPONENTS_AVAILABLE:
        return _generate_context_summary(heartrate_results, glucose_results, raw_data_sample)
    
    # Initialize context window optimizer
    optimizer = ContextWindowOptimizer(max_tokens=max_tokens)
    
    # Convert raw data to list of dicts
    raw_data_list = raw_data_sample.to_dict('records')
    
    # Optimize heart rate data
    hr_anomalies = []
    if 'metric' in raw_data_sample.columns and 'value' in raw_data_sample.columns:
        hr_data = raw_data_sample[raw_data_sample['metric'] == 'heart_rate']
        if not hr_data.empty:
            # Find anomalies (values that are 30% higher than average)
            hr_values = hr_data['value'].values
            avg_hr = np.mean(hr_values)
            anomaly_threshold = 1.3 * avg_hr
            anomaly_indices = np.where(hr_values > anomaly_threshold)[0].tolist()
            hr_anomalies = anomaly_indices
    
    # Optimize the data for context window
    optimized_data = optimizer.optimize_time_series(raw_data_list, hr_anomalies)
    
    # Add analysis summaries
    optimized_data['heart_rate_summary'] = {
        'resting_heart_rate': heartrate_results.get('resting_heart_rate', 0),
        'max_heart_rate': heartrate_results.get('max_heart_rate', 0),
        'heart_rate_variability': heartrate_results.get('heart_rate_variability', 0),
        'anomalies_detected': heartrate_results.get('anomalies_detected', 0),
        'sample_count': heartrate_results.get('sample_count', 0)
    }
    
    optimized_data['glucose_summary'] = {
        'average_glucose': glucose_results.get('average_glucose', 0),
        'time_in_range': glucose_results.get('time_in_range', 0),
        'glucose_variability': glucose_results.get('glucose_variability', 0),
        'hypo_episodes': glucose_results.get('hypo_episodes', 0),
        'hyper_episodes': glucose_results.get('hyper_episodes', 0),
        'sample_count': glucose_results.get('sample_count', 0)
    }
    
    # Calculate data reduction
    if 'optimization_applied' in optimized_data and optimized_data['optimization_applied']:
        original_data_count = len(raw_data_list)
        optimized_data_count = len(optimized_data.get('optimized_data', []))
        reduction_percentage = (1 - (optimized_data_count / original_data_count)) * 100
        
        print(f"Reduced data from {original_data_count} to {optimized_data_count} points ({reduction_percentage:.1f}% reduction)")
        
        optimized_data['data_reduction'] = {
            'original_points': original_data_count,
            'optimized_points': optimized_data_count,
            'reduction_percentage': reduction_percentage
        }
    
    return optimized_data


def _generate_context_summary(heartrate_results: Dict[str, Any],
                            glucose_results: Dict[str, Any],
                            raw_data_sample: pd.DataFrame) -> Dict[str, Any]:
    """Generate a simple context summary when optimizer is not available"""
    # Calculate basic statistics for each metric
    summary = {}
    
    if 'metric' in raw_data_sample.columns:
        for metric in raw_data_sample['metric'].unique():
            metric_data = raw_data_sample[raw_data_sample['metric'] == metric]
            if 'value' in metric_data.columns:
                values = metric_data['value'].values
                summary[f"{metric}_summary"] = {
                    'count': len(values),
                    'mean': float(np.mean(values)) if len(values) > 0 else 0,
                    'min': float(np.min(values)) if len(values) > 0 else 0,
                    'max': float(np.max(values)) if len(values) > 0 else 0,
                    'std': float(np.std(values)) if len(values) > 0 else 0
                }
    
    # Add specific analysis results
    if 'heart_rate_summary' not in summary:
        summary['heart_rate_summary'] = {
            'resting_heart_rate': heartrate_results.get('resting_heart_rate', 0),
            'max_heart_rate': heartrate_results.get('max_heart_rate', 0),
            'heart_rate_variability': heartrate_results.get('heart_rate_variability', 0),
            'anomalies_detected': heartrate_results.get('anomalies_detected', 0),
            'sample_count': heartrate_results.get('sample_count', 0)
        }
    
    if 'glucose_summary' not in summary:
        summary['glucose_summary'] = {
            'average_glucose': glucose_results.get('average_glucose', 0),
            'time_in_range': glucose_results.get('time_in_range', 0),
            'glucose_variability': glucose_results.get('glucose_variability', 0),
            'hypo_episodes': glucose_results.get('hypo_episodes', 0),
            'hyper_episodes': glucose_results.get('hyper_episodes', 0),
            'sample_count': glucose_results.get('sample_count', 0)
        }
    
    # Include a small sample of data
    sample_size = min(50, len(raw_data_sample))
    if sample_size > 0:
        sampled_data = raw_data_sample.sample(sample_size).to_dict('records')
        summary['data_sample'] = sampled_data
    
    # Add mock optimization metadata
    summary['optimization_applied'] = True
    summary['data_reduction'] = {
        'original_points': len(raw_data_sample),
        'optimized_points': sample_size,
        'reduction_percentage': (1 - (sample_size / len(raw_data_sample))) * 100
    }
    
    return summary


def run_demonstration(output_dir: str = None, generate_data: bool = True,
                    years: int = 1, users: int = 2) -> None:
    """
    Run the scaled wearables analytics demonstration.
    
    Args:
        output_dir: Directory to save output files
        generate_data: Whether to generate synthetic data
        years: Number of years of data to generate
        users: Number of users to generate data for
    """
    # Setup output directory
    if output_dir is None:
        output_dir = os.path.join(tempfile.gettempdir(), "wearables_demo")
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Step 1: Generate or load synthetic data
    data_dir = os.path.join(output_dir, "data")
    os.makedirs(data_dir, exist_ok=True)
    
    data_files = {}
    
    if generate_data:
        print(f"\n{'='*80}\nStep 1: Generating Synthetic Wearables Data\n{'='*80}")
        data_files = generate_synthetic_dataset(data_dir, years, users)
    else:
        # Check if data files exist
        for metric in ['heart_rate', 'glucose', 'steps', 'sleep']:
            file_path = os.path.join(data_dir, f"{metric}_data.parquet")
            if os.path.exists(file_path):
                data_files[metric] = file_path
        
        if not data_files:
            print("No existing data files found. Generating new data...")
            data_files = generate_synthetic_dataset(data_dir, years, users)
    
    # Step 2: Process heart rate data
    print(f"\n{'='*80}\nStep 2: Processing Heart Rate Data with Memory Optimization\n{'='*80}")
    
    # Select a random user for demonstration
    selected_user = f"user_{random.randint(1, users):03d}"
    print(f"Selected user: {selected_user}")
    
    heartrate_results = process_heart_rate_data(data_files.get('heart_rate'), selected_user)
    
    # Save results
    with open(os.path.join(output_dir, "heartrate_results.json"), "w") as f:
        json.dump(heartrate_results, f, indent=2)
    
    # Step 3: Process glucose data
    print(f"\n{'='*80}\nStep 3: Processing Glucose Data with Time Partitioning\n{'='*80}")
    
    glucose_results = process_glucose_data(data_files.get('glucose'), selected_user)
    
    # Save results
    with open(os.path.join(output_dir, "glucose_results.json"), "w") as f:
        json.dump(glucose_results, f, indent=2)
    
    # Step 4: Get a sample of raw data for the user
    print(f"\n{'='*80}\nStep 4: Preparing Raw Data Sample\n{'='*80}")
    
    # Read a sample of raw data
    raw_data_sample = pd.DataFrame()
    
    for metric, file_path in data_files.items():
        # Read only the first chunk
        try:
            if file_path.endswith('.parquet'):
                sample = pd.read_parquet(file_path)
            else:
                sample = pd.read_csv(file_path)
            
            # Filter for selected user
            if 'user_id' in sample.columns:
                sample = sample[sample['user_id'] == selected_user]
            
            # Limit sample size
            if len(sample) > 1000:
                sample = sample.sample(1000)
            
            # Combine with existing samples
            raw_data_sample = pd.concat([raw_data_sample, sample])
        except Exception as e:
            print(f"Error reading {metric} data: {e}")
    
    print(f"Prepared raw data sample with {len(raw_data_sample)} points")
    
    # Step 5: Generate user context
    print(f"\n{'='*80}\nStep 5: Creating User Context\n{'='*80}")
    
    user_context = {
        "age": random.randint(30, 65),
        "gender": random.choice(["male", "female"]),
        "health_conditions": random.sample(["Prediabetes", "Hypertension", "Asthma", "Anxiety", "Insomnia"], 
                                         k=random.randint(0, 3)),
        "medications": random.sample(["Metformin", "Lisinopril", "Albuterol", "Escitalopram", "Melatonin"],
                                   k=random.randint(0, 2)),
        "has_diabetes": random.random() < 0.3,
        "has_hypertension": random.random() < 0.3,
        "is_athlete": random.random() < 0.2
    }
    
    print(f"User context: {json.dumps(user_context, indent=2)}")
    
    # Save user context
    with open(os.path.join(output_dir, "user_context.json"), "w") as f:
        json.dump(user_context, f, indent=2)
    
    # Step 6: Generate health insights using RAG
    print(f"\n{'='*80}\nStep 6: Generating Health Insights with RAG\n{'='*80}")
    
    insights = generate_health_insights(heartrate_results, glucose_results, user_context)
    
    # Save insights
    with open(os.path.join(output_dir, "health_insights.json"), "w") as f:
        json.dump(insights, f, indent=2)
    
    # Print insights
    print("\nHealth Insights:")
    print(f"{insights['health_insights']}")
    
    # Step 7: Optimize for context window
    print(f"\n{'='*80}\nStep 7: Optimizing for LLM Context Window\n{'='*80}")
    
    optimized_data = optimize_for_context_window(heartrate_results, glucose_results, raw_data_sample)
    
    # Save optimized data (truncated version for readability)
    optimized_data_slim = optimized_data.copy()
    if 'optimized_data' in optimized_data_slim:
        sample_size = min(20, len(optimized_data_slim['optimized_data']))
        optimized_data_slim['optimized_data'] = optimized_data_slim['optimized_data'][:sample_size]
        optimized_data_slim['optimized_data_truncated'] = True
    
    with open(os.path.join(output_dir, "context_optimized.json"), "w") as f:
        json.dump(optimized_data_slim, f, indent=2)
    
    # Step 8: Generate final report
    print(f"\n{'='*80}\nStep 8: Generating Final Report\n{'='*80}")
    
    # Create final report
    report = {
        "user_id": selected_user,
        "user_context": user_context,
        "heart_rate_analysis": {
            "resting_heart_rate": heartrate_results.get('resting_heart_rate', 0),
            "max_heart_rate": heartrate_results.get('max_heart_rate', 0),
            "heart_rate_variability": heartrate_results.get('heart_rate_variability', 0),
            "anomalies_detected": heartrate_results.get('anomalies_detected', 0),
            "processing_time": heartrate_results.get('processing_time', 0)
        },
        "glucose_analysis": {
            "average_glucose": glucose_results.get('average_glucose', 0),
            "time_in_range": glucose_results.get('time_in_range', 0),
            "glucose_variability": glucose_results.get('glucose_variability', 0),
            "hypo_episodes": glucose_results.get('hypo_episodes', 0),
            "hyper_episodes": glucose_results.get('hyper_episodes', 0),
            "processing_time": glucose_results.get('processing_time', 0)
        },
        "rag_insights": {
            "highlights": insights['health_insights'].split('\n\n')[0:2],
            "processing_time": insights.get('processing_time', 0),
            "tokens_used": insights.get('tokens_used', 0)
        },
        "context_optimization": {
            "original_points": optimized_data.get('data_reduction', {}).get('original_points', 0),
            "optimized_points": optimized_data.get('data_reduction', {}).get('optimized_points', 0),
            "reduction_percentage": optimized_data.get('data_reduction', {}).get('reduction_percentage', 0)
        },
        "data_scale": {
            "years": years,
            "users": users,
            "metrics": list(data_files.keys())
        }
    }
    
    # Save report
    with open(os.path.join(output_dir, "final_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    
    print(f"\nFinal report saved to: {os.path.join(output_dir, 'final_report.json')}")
    print(f"\nAll results saved to: {output_dir}")
    
    # Print summary
    print(f"\n{'='*80}\nDemonstration Summary\n{'='*80}")
    print(f"Generated and processed {years} years of data for {users} users")
    print(f"Heart rate analysis: {heartrate_results.get('processing_time', 0):.2f} seconds")
    print(f"Glucose analysis: {glucose_results.get('processing_time', 0):.2f} seconds")
    print(f"RAG insights: {insights.get('processing_time', 0):.2f} seconds, {insights.get('tokens_used', 0)} tokens")
    print(f"Context optimization: {optimized_data.get('data_reduction', {}).get('reduction_percentage', 0):.1f}% reduction")
    print(f"{'='*80}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Scaled Wearables Analytics Demonstration')
    parser.add_argument('--output-dir', type=str, default=None,
                      help='Directory to save output files')
    parser.add_argument('--skip-data-gen', action='store_true',
                      help='Skip data generation and use existing data files')
    parser.add_argument('--years', type=int, default=1,
                      help='Number of years of data to generate')
    parser.add_argument('--users', type=int, default=2,
                      help='Number of users to generate data for')
    
    args = parser.parse_args()
    
    run_demonstration(
        output_dir=args.output_dir,
        generate_data=not args.skip_data_gen,
        years=args.years,
        users=args.users
    )
"""
Memory-Efficient Analytics for Large-Scale Wearables Data

This module provides memory optimization strategies for analyzing very large
wearables datasets that exceed available memory. Key techniques include:

1. Hierarchical time window partitioning
2. Memory-mapped file operations
3. Progressive loading
4. Out-of-core computation
5. Temporal compression for historical data

These approaches allow for processing years of high-frequency data (millions of points)
on machines with limited memory.
"""

import os
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.compute as pc
from typing import List, Dict, Any, Optional, Tuple, Iterator, Union, Callable
from datetime import datetime, timedelta
import json
import tempfile
import gc
import math
from enum import Enum
from dataclasses import dataclass
import warnings
from functools import partial
import shutil


class TimeWindow(Enum):
    """Time window granularity for partitioning data"""
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"


class CompressionLevel(Enum):
    """Compression level for historical data"""
    NONE = "none"  # No compression
    LOW = "low"    # Light compression (e.g., hourly averages for old data)
    MEDIUM = "medium"  # Medium compression (e.g., daily averages for old data)
    HIGH = "high"  # Heavy compression (e.g., weekly averages for very old data)
    ADAPTIVE = "adaptive"  # Adaptive compression based on data age


@dataclass
class MemoryStats:
    """Memory usage statistics"""
    initial_usage: float  # Memory usage at start of operation (MB)
    peak_usage: float     # Peak memory usage during operation (MB)
    final_usage: float    # Memory usage after operation (MB)
    data_size: float      # Size of data processed (MB)
    compression_ratio: float  # Ratio of uncompressed to compressed size


@dataclass
class TimeWindowPartition:
    """Information about a time window partition"""
    start_time: datetime
    end_time: datetime
    partition_id: str
    record_count: int
    file_path: Optional[str] = None
    memory_size: Optional[float] = None
    is_compressed: bool = False
    compression_level: Optional[CompressionLevel] = None


class MemoryEfficientAnalytics:
    """
    Memory-efficient analytics for processing extremely large wearables datasets.
    Uses partitioning, streaming, and out-of-core computation strategies.
    """
    
    def __init__(self, data_dir: str = None, max_memory_mb: int = 1000):
        """
        Initialize memory-efficient analytics engine.
        
        Args:
            data_dir: Directory to store temporary partitioned data
            max_memory_mb: Maximum memory to use in MB
        """
        self.data_dir = data_dir or os.path.join(tempfile.gettempdir(), "wearables_analytics")
        os.makedirs(self.data_dir, exist_ok=True)
        
        self.max_memory_mb = max_memory_mb
        self.window_partitions = {}  # Dict of TimeWindowPartition objects
        
        # Estimated memory usage per record in MB
        # This is an approximation that should be calibrated for your data
        self.memory_per_record_mb = 0.0001  # ~100 bytes per record
    
    def clear_temp_data(self):
        """Clear temporary data files"""
        for root, dirs, files in os.walk(self.data_dir):
            for file in files:
                if file.endswith('.parquet'):
                    os.remove(os.path.join(root, file))
    
    def partition_by_time(self, data_source: Union[str, List[Dict[str, Any]], pd.DataFrame],
                        time_field: str = 'timestamp',
                        window: TimeWindow = TimeWindow.DAY) -> List[TimeWindowPartition]:
        """
        Partition large dataset by time windows to allow for manageable processing.
        
        Args:
            data_source: Source data (file path, list of dicts, or DataFrame)
            time_field: Field containing timestamp information
            window: Time window size for partitioning
            
        Returns:
            List of time window partitions
        """
        # Determine partitioning approach based on input type
        if isinstance(data_source, str):
            # Data is a file path
            return self._partition_file_by_time(data_source, time_field, window)
        elif isinstance(data_source, pd.DataFrame):
            # Data is a pandas DataFrame
            return self._partition_dataframe_by_time(data_source, time_field, window)
        elif isinstance(data_source, list):
            # Data is a list of dictionaries
            return self._partition_list_by_time(data_source, time_field, window)
        else:
            raise ValueError(f"Unsupported data source type: {type(data_source)}")
    
    def _partition_file_by_time(self, file_path: str, time_field: str,
                              window: TimeWindow) -> List[TimeWindowPartition]:
        """Partition file-based data by time windows"""
        if file_path.endswith('.parquet'):
            # For Parquet files, we can be more efficient by reading metadata first
            return self._partition_parquet_by_time(file_path, time_field, window)
        elif file_path.endswith('.csv'):
            # For CSV, use chunked reading to avoid loading the entire file
            return self._partition_csv_by_time(file_path, time_field, window)
        else:
            raise ValueError(f"Unsupported file format: {file_path}")
    
    def _partition_parquet_by_time(self, file_path: str, time_field: str,
                                 window: TimeWindow) -> List[TimeWindowPartition]:
        """
        Partition Parquet file by time windows efficiently by leveraging Parquet metadata.
        This avoids loading the entire file into memory.
        """
        # Read Parquet metadata to get min/max timestamps
        parquet_file = pq.ParquetFile(file_path)
        
        # Read basic statistics from metadata
        statistics = parquet_file.metadata.row_group(0).column(time_field).statistics
        if statistics is None:
            # If statistics not available, fall back to scanning the file
            return self._partition_csv_by_time(file_path, time_field, window)
        
        min_time = pd.Timestamp(statistics.min)
        max_time = pd.Timestamp(statistics.max)
        
        # Create time window boundaries
        window_boundaries = self._create_time_windows(min_time, max_time, window)
        
        partitions = []
        for i, (start, end) in enumerate(window_boundaries):
            # Create filter expression for this time window
            filter_expression = (
                f"({time_field} >= '{start.isoformat()}') & "
                f"({time_field} < '{end.isoformat()}')"
            )
            
            # Read just the count for this window to estimate size
            try:
                # Try to use PyArrow's filter pushdown to efficiently count rows
                table = pq.read_table(
                    file_path,
                    filters=[(time_field, '>=', start.isoformat()),
                             (time_field, '<', end.isoformat())],
                    columns=[time_field]  # Only read the timestamp column
                )
                count = len(table)
            except:
                # If filter pushdown fails, use pandas with a small chunksize
                count = 0
                for chunk in pd.read_parquet(file_path, filters=filter_expression, chunksize=10000):
                    count += len(chunk)
            
            if count > 0:
                # Generate output path for this partition
                partition_id = f"{window.value}_{i}_{start.strftime('%Y%m%d')}_{end.strftime('%Y%m%d')}"
                output_path = os.path.join(self.data_dir, f"{partition_id}.parquet")
                
                # Create partition info (without actually writing the file yet)
                partition = TimeWindowPartition(
                    start_time=start,
                    end_time=end,
                    partition_id=partition_id,
                    record_count=count,
                    file_path=output_path,
                    memory_size=count * self.memory_per_record_mb,
                    is_compressed=False
                )
                partitions.append(partition)
                
                # Store in our window partition dictionary
                self.window_partitions[partition_id] = partition
        
        return partitions
    
    def _partition_csv_by_time(self, file_path: str, time_field: str,
                             window: TimeWindow) -> List[TimeWindowPartition]:
        """
        Partition CSV file by time windows using chunked reading to minimize memory usage.
        """
        # Use pandas to read the file in chunks to find min/max times
        min_time = None
        max_time = None
        
        # First pass: determine time range
        for chunk in pd.read_csv(file_path, chunksize=100000):
            if time_field in chunk.columns:
                chunk[time_field] = pd.to_datetime(chunk[time_field])
                
                chunk_min = chunk[time_field].min()
                chunk_max = chunk[time_field].max()
                
                if min_time is None or chunk_min < min_time:
                    min_time = chunk_min
                    
                if max_time is None or chunk_max > max_time:
                    max_time = chunk_max
        
        if min_time is None or max_time is None:
            raise ValueError(f"Could not find valid timestamps in field: {time_field}")
        
        # Create time window boundaries
        window_boundaries = self._create_time_windows(min_time, max_time, window)
        
        # Initialize counters for each window
        window_counts = {i: 0 for i in range(len(window_boundaries))}
        
        # Second pass: count records per window
        for chunk in pd.read_csv(file_path, chunksize=100000):
            if time_field in chunk.columns:
                chunk[time_field] = pd.to_datetime(chunk[time_field])
                
                for i, (start, end) in enumerate(window_boundaries):
                    mask = (chunk[time_field] >= start) & (chunk[time_field] < end)
                    window_counts[i] += mask.sum()
        
        # Create partitions for non-empty windows
        partitions = []
        for i, (start, end) in enumerate(window_boundaries):
            count = window_counts[i]
            if count > 0:
                # Generate output path for this partition
                partition_id = f"{window.value}_{i}_{start.strftime('%Y%m%d')}_{end.strftime('%Y%m%d')}"
                output_path = os.path.join(self.data_dir, f"{partition_id}.parquet")
                
                # Create partition info
                partition = TimeWindowPartition(
                    start_time=start,
                    end_time=end,
                    partition_id=partition_id,
                    record_count=count,
                    file_path=output_path,
                    memory_size=count * self.memory_per_record_mb,
                    is_compressed=False
                )
                partitions.append(partition)
                
                # Store in our window partition dictionary
                self.window_partitions[partition_id] = partition
        
        return partitions
    
    def _partition_dataframe_by_time(self, df: pd.DataFrame, time_field: str,
                                   window: TimeWindow) -> List[TimeWindowPartition]:
        """Partition pandas DataFrame by time windows"""
        if time_field not in df.columns:
            raise ValueError(f"Time field '{time_field}' not found in DataFrame")
        
        # Ensure time field is datetime
        if not pd.api.types.is_datetime64_any_dtype(df[time_field]):
            df[time_field] = pd.to_datetime(df[time_field])
        
        # Get min and max times
        min_time = df[time_field].min()
        max_time = df[time_field].max()
        
        # Create time window boundaries
        window_boundaries = self._create_time_windows(min_time, max_time, window)
        
        # Create partitions
        partitions = []
        for i, (start, end) in enumerate(window_boundaries):
            # Filter data for this window
            window_data = df[(df[time_field] >= start) & (df[time_field] < end)]
            
            if len(window_data) > 0:
                # Generate output path for this partition
                partition_id = f"{window.value}_{i}_{start.strftime('%Y%m%d')}_{end.strftime('%Y%m%d')}"
                output_path = os.path.join(self.data_dir, f"{partition_id}.parquet")
                
                # Write partition to Parquet file
                window_data.to_parquet(output_path, index=False)
                
                # Create partition info
                partition = TimeWindowPartition(
                    start_time=start,
                    end_time=end,
                    partition_id=partition_id,
                    record_count=len(window_data),
                    file_path=output_path,
                    memory_size=len(window_data) * self.memory_per_record_mb,
                    is_compressed=False
                )
                partitions.append(partition)
                
                # Store in our window partition dictionary
                self.window_partitions[partition_id] = partition
        
        return partitions
    
    def _partition_list_by_time(self, data_list: List[Dict[str, Any]], time_field: str,
                             window: TimeWindow) -> List[TimeWindowPartition]:
        """Partition list of dictionaries by time windows"""
        # Convert to DataFrame first
        df = pd.DataFrame(data_list)
        return self._partition_dataframe_by_time(df, time_field, window)
    
    def _create_time_windows(self, min_time: pd.Timestamp, max_time: pd.Timestamp,
                          window: TimeWindow) -> List[Tuple[datetime, datetime]]:
        """Create time window boundaries based on min/max times and window size"""
        window_boundaries = []
        
        if window == TimeWindow.HOUR:
            # Start at beginning of hour
            current = min_time.floor('H')
            while current <= max_time:
                window_boundaries.append((current, current + pd.Timedelta(hours=1)))
                current += pd.Timedelta(hours=1)
                
        elif window == TimeWindow.DAY:
            # Start at beginning of day
            current = min_time.floor('D')
            while current <= max_time:
                window_boundaries.append((current, current + pd.Timedelta(days=1)))
                current += pd.Timedelta(days=1)
                
        elif window == TimeWindow.WEEK:
            # Start at beginning of week
            current = min_time.floor('W')
            while current <= max_time:
                window_boundaries.append((current, current + pd.Timedelta(weeks=1)))
                current += pd.Timedelta(weeks=1)
                
        elif window == TimeWindow.MONTH:
            # Start at beginning of month
            current = min_time.floor('MS')
            while current <= max_time:
                # Get last day of month
                next_month = (current + pd.Timedelta(days=32)).floor('MS')
                window_boundaries.append((current, next_month))
                current = next_month
                
        elif window == TimeWindow.YEAR:
            # Start at beginning of year
            current = min_time.floor('YS')
            while current <= max_time:
                # Get last day of year
                next_year = (current + pd.Timedelta(days=366)).floor('YS')
                window_boundaries.append((current, next_year))
                current = next_year
        
        return window_boundaries
    
    def compress_historical_data(self, partitions: List[TimeWindowPartition], 
                               compression_strategy: Dict[str, CompressionLevel] = None) -> List[TimeWindowPartition]:
        """
        Apply compression to historical data partitions.
        
        Args:
            partitions: List of time window partitions
            compression_strategy: Dict mapping time ago to compression level, e.g.,
                {'30d': CompressionLevel.LOW, '90d': CompressionLevel.MEDIUM, '365d': CompressionLevel.HIGH}
                
        Returns:
            List of compressed partitions
        """
        if compression_strategy is None:
            # Default compression strategy
            compression_strategy = {
                '30d': CompressionLevel.LOW,      # Last 30 days: low compression
                '90d': CompressionLevel.MEDIUM,   # 31-90 days ago: medium compression
                '365d': CompressionLevel.HIGH,    # 91-365 days ago: high compression
                'older': CompressionLevel.HIGH    # Older than 365 days: high compression
            }
        
        now = pd.Timestamp.now()
        compressed_partitions = []
        
        for partition in partitions:
            # Skip already compressed partitions
            if partition.is_compressed:
                compressed_partitions.append(partition)
                continue
                
            # Determine age of data
            end_time = pd.Timestamp(partition.end_time)
            days_ago = (now - end_time).days
            
            # Determine compression level based on age
            compression_level = CompressionLevel.NONE
            for age_str, level in compression_strategy.items():
                if age_str == 'older':
                    compression_level = level
                    continue
                    
                age_days = int(age_str.rstrip('d'))
                if days_ago > age_days:
                    compression_level = level
            
            if compression_level == CompressionLevel.NONE:
                # No compression needed
                compressed_partitions.append(partition)
                continue
                
            # Apply compression
            compressed_partition = self._compress_partition(partition, compression_level)
            compressed_partitions.append(compressed_partition)
        
        return compressed_partitions
    
    def _compress_partition(self, partition: TimeWindowPartition, 
                         level: CompressionLevel) -> TimeWindowPartition:
        """
        Compress a single partition based on compression level.
        
        Args:
            partition: Partition to compress
            level: Compression level to apply
            
        Returns:
            Compressed partition
        """
        if level == CompressionLevel.NONE or partition.is_compressed:
            return partition
            
        if not os.path.exists(partition.file_path):
            warnings.warn(f"Partition file not found: {partition.file_path}")
            return partition
            
        # Read the partition
        df = pd.read_parquet(partition.file_path)
        
        # Apply compression based on level
        if level == CompressionLevel.LOW:
            # Low compression: resample to hourly averages
            compressed_df = self._resample_to_frequency(df, '1H')
        elif level == CompressionLevel.MEDIUM:
            # Medium compression: resample to 6-hour averages
            compressed_df = self._resample_to_frequency(df, '6H')
        elif level == CompressionLevel.HIGH:
            # High compression: resample to daily averages
            compressed_df = self._resample_to_frequency(df, '1D')
        else:
            # Default to hourly compression
            compressed_df = self._resample_to_frequency(df, '1H')
        
        # Generate compressed file path
        compressed_path = partition.file_path.replace('.parquet', f'_compressed_{level.value}.parquet')
        
        # Write compressed data
        compressed_df.to_parquet(compressed_path, index=False)
        
        # Create new partition info
        compressed_partition = TimeWindowPartition(
            start_time=partition.start_time,
            end_time=partition.end_time,
            partition_id=f"{partition.partition_id}_compressed",
            record_count=len(compressed_df),
            file_path=compressed_path,
            memory_size=len(compressed_df) * self.memory_per_record_mb,
            is_compressed=True,
            compression_level=level
        )
        
        # Update partition dictionary
        self.window_partitions[compressed_partition.partition_id] = compressed_partition
        
        return compressed_partition
    
    def _resample_to_frequency(self, df: pd.DataFrame, freq: str) -> pd.DataFrame:
        """Resample DataFrame to specified frequency"""
        # Find timestamp column
        timestamp_col = None
        for col in df.columns:
            if 'time' in col.lower() or 'date' in col.lower():
                if pd.api.types.is_datetime64_any_dtype(df[col]):
                    timestamp_col = col
                    break
                try:
                    # Try to convert to datetime
                    df[col] = pd.to_datetime(df[col])
                    timestamp_col = col
                    break
                except:
                    continue
        
        if timestamp_col is None:
            # If no timestamp column found, just return sample of the data
            sample_size = max(1, len(df) // 10)  # 10% of original size
            return df.sample(sample_size)
            
        # Set timestamp as index for resampling
        df = df.set_index(timestamp_col)
        
        # Identify numeric columns for aggregation
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        
        # Create aggregation dict
        agg_dict = {}
        for col in numeric_cols:
            agg_dict[col] = 'mean'  # Default to mean for numeric columns
        
        # For non-numeric columns, use most frequent value
        for col in df.columns:
            if col not in numeric_cols:
                agg_dict[col] = lambda x: x.mode()[0] if len(x) > 0 and len(x.mode()) > 0 else None
        
        # Resample and aggregate
        resampled = df.resample(freq).agg(agg_dict)
        
        # Reset index to get timestamp back as column
        resampled = resampled.reset_index()
        
        return resampled
    
    def process_partitioned_data(self, partitions: List[TimeWindowPartition],
                               processor_func: Callable[[pd.DataFrame], Dict[str, Any]],
                               max_partitions_in_memory: int = 3) -> Dict[str, Any]:
        """
        Process partitioned data using a processor function.
        
        Args:
            partitions: List of time window partitions
            processor_func: Function to process each partition
            max_partitions_in_memory: Maximum number of partitions to load at once
            
        Returns:
            Aggregated results across all partitions
        """
        # Sort partitions by start time
        sorted_partitions = sorted(partitions, key=lambda p: p.start_time)
        
        # Group partitions into batches to control memory usage
        partition_batches = []
        current_batch = []
        current_batch_size = 0
        
        for partition in sorted_partitions:
            # If adding this partition would exceed memory limit, start a new batch
            if (current_batch_size + partition.memory_size > self.max_memory_mb or
                len(current_batch) >= max_partitions_in_memory):
                if current_batch:  # Don't add empty batches
                    partition_batches.append(current_batch)
                current_batch = []
                current_batch_size = 0
            
            current_batch.append(partition)
            current_batch_size += partition.memory_size or 0
        
        # Add the last batch if not empty
        if current_batch:
            partition_batches.append(current_batch)
        
        # Process each batch
        results = []
        for batch in partition_batches:
            batch_result = self._process_partition_batch(batch, processor_func)
            results.append(batch_result)
            
            # Force garbage collection to free memory
            gc.collect()
        
        # Aggregate results across batches
        return self._aggregate_results(results)
    
    def _process_partition_batch(self, partitions: List[TimeWindowPartition],
                              processor_func: Callable[[pd.DataFrame], Dict[str, Any]]) -> Dict[str, Any]:
        """Process a batch of partitions"""
        # Load and process each partition
        batch_dfs = []
        
        for partition in partitions:
            if not os.path.exists(partition.file_path):
                warnings.warn(f"Partition file not found: {partition.file_path}")
                continue
                
            # Load partition
            df = pd.read_parquet(partition.file_path)
            batch_dfs.append(df)
        
        # Combine DataFrames
        if not batch_dfs:
            return {}
            
        combined_df = pd.concat(batch_dfs, ignore_index=True)
        
        # Process combined data
        result = processor_func(combined_df)
        
        return result
    
    def _aggregate_results(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Aggregate results from multiple batches"""
        if not results:
            return {}
            
        # Start with the first result
        aggregated = results[0].copy()
        
        # Aggregate numeric values
        for result in results[1:]:
            for key, value in result.items():
                if key in aggregated:
                    # If both are numeric, sum them
                    if isinstance(value, (int, float)) and isinstance(aggregated[key], (int, float)):
                        aggregated[key] += value
                    # If both are lists, extend
                    elif isinstance(value, list) and isinstance(aggregated[key], list):
                        aggregated[key].extend(value)
                    # If both are dicts, merge recursively
                    elif isinstance(value, dict) and isinstance(aggregated[key], dict):
                        self._merge_dicts(aggregated[key], value)
                    # Otherwise, keep the aggregated value
                else:
                    # Key not in aggregated, add it
                    aggregated[key] = value
        
        return aggregated
    
    def _merge_dicts(self, dict1: Dict[str, Any], dict2: Dict[str, Any]) -> None:
        """Recursively merge dict2 into dict1"""
        for key, value in dict2.items():
            if key in dict1:
                if isinstance(value, dict) and isinstance(dict1[key], dict):
                    self._merge_dicts(dict1[key], value)
                elif isinstance(value, (int, float)) and isinstance(dict1[key], (int, float)):
                    dict1[key] += value
                elif isinstance(value, list) and isinstance(dict1[key], list):
                    dict1[key].extend(value)
                # Otherwise keep dict1's value
            else:
                dict1[key] = value
    
    def stream_process(self, data_source: Union[str, List[Dict[str, Any]], pd.DataFrame],
                     processor_func: Callable[[pd.DataFrame], Dict[str, Any]],
                     chunk_size: int = 10000) -> Dict[str, Any]:
        """
        Stream process data in chunks to minimize memory usage.
        
        Args:
            data_source: Source data (file path, list of dicts, or DataFrame)
            processor_func: Function to process each chunk
            chunk_size: Number of records per chunk
            
        Returns:
            Aggregated results across all chunks
        """
        results = []
        
        if isinstance(data_source, str):
            # Data is a file path
            if data_source.endswith('.parquet'):
                # Process Parquet file in chunks
                for chunk in self._stream_parquet(data_source, chunk_size):
                    result = processor_func(chunk)
                    results.append(result)
                    # Force garbage collection
                    del chunk
                    gc.collect()
            elif data_source.endswith('.csv'):
                # Process CSV file in chunks
                for chunk in pd.read_csv(data_source, chunksize=chunk_size):
                    result = processor_func(chunk)
                    results.append(result)
                    # Force garbage collection
                    del chunk
                    gc.collect()
            else:
                raise ValueError(f"Unsupported file format: {data_source}")
                
        elif isinstance(data_source, pd.DataFrame):
            # Data is a pandas DataFrame
            total_chunks = math.ceil(len(data_source) / chunk_size)
            
            for i in range(total_chunks):
                start_idx = i * chunk_size
                end_idx = min((i + 1) * chunk_size, len(data_source))
                
                chunk = data_source.iloc[start_idx:end_idx].copy()
                result = processor_func(chunk)
                results.append(result)
                
                # Force garbage collection
                del chunk
                gc.collect()
                
        elif isinstance(data_source, list):
            # Data is a list of dictionaries
            total_chunks = math.ceil(len(data_source) / chunk_size)
            
            for i in range(total_chunks):
                start_idx = i * chunk_size
                end_idx = min((i + 1) * chunk_size, len(data_source))
                
                chunk = pd.DataFrame(data_source[start_idx:end_idx])
                result = processor_func(chunk)
                results.append(result)
                
                # Force garbage collection
                del chunk
                gc.collect()
                
        else:
            raise ValueError(f"Unsupported data source type: {type(data_source)}")
        
        # Aggregate results
        return self._aggregate_results(results)
    
    def _stream_parquet(self, file_path: str, chunk_size: int) -> Iterator[pd.DataFrame]:
        """Stream Parquet file in chunks"""
        parquet_file = pq.ParquetFile(file_path)
        
        # Read and yield row groups
        for i in range(parquet_file.num_row_groups):
            table = parquet_file.read_row_group(i)
            df = table.to_pandas()
            
            # Break into chunks if needed
            if len(df) <= chunk_size:
                yield df
            else:
                total_chunks = math.ceil(len(df) / chunk_size)
                for j in range(total_chunks):
                    start_idx = j * chunk_size
                    end_idx = min((j + 1) * chunk_size, len(df))
                    yield df.iloc[start_idx:end_idx].copy()
    
    def hierarchical_summarize(self, data_source: Union[str, List[Dict[str, Any]], pd.DataFrame],
                            time_field: str = 'timestamp',
                            value_field: str = 'value') -> Dict[str, Any]:
        """
        Create hierarchical summaries at different time granularities.
        
        Args:
            data_source: Source data (file path, list of dicts, or DataFrame)
            time_field: Field containing timestamp information
            value_field: Field containing the value to summarize
            
        Returns:
            Hierarchical summary at different time levels
        """
        # Define the summarization function
        def summarize_chunk(df: pd.DataFrame) -> Dict[str, Any]:
            if time_field not in df.columns or value_field not in df.columns:
                return {}
                
            # Ensure time field is datetime
            if not pd.api.types.is_datetime64_any_dtype(df[time_field]):
                df[time_field] = pd.to_datetime(df[time_field])
            
            # Set time field as index
            df = df.set_index(time_field)
            
            # Create summaries at different levels
            summaries = {}
            
            # Hourly summary
            try:
                hourly = df.resample('1H')[value_field].agg(['mean', 'min', 'max', 'std', 'count'])
                hourly = hourly.reset_index()
                hourly[time_field] = hourly[time_field].dt.strftime('%Y-%m-%d %H:00:00')
                summaries['hourly'] = hourly.to_dict(orient='records')
            except:
                summaries['hourly'] = []
            
            # Daily summary
            try:
                daily = df.resample('1D')[value_field].agg(['mean', 'min', 'max', 'std', 'count'])
                daily = daily.reset_index()
                daily[time_field] = daily[time_field].dt.strftime('%Y-%m-%d')
                summaries['daily'] = daily.to_dict(orient='records')
            except:
                summaries['daily'] = []
            
            # Weekly summary
            try:
                weekly = df.resample('1W')[value_field].agg(['mean', 'min', 'max', 'std', 'count'])
                weekly = weekly.reset_index()
                weekly[time_field] = weekly[time_field].dt.strftime('%Y-%m-%d')
                summaries['weekly'] = weekly.to_dict(orient='records')
            except:
                summaries['weekly'] = []
            
            # Monthly summary
            try:
                monthly = df.resample('1M')[value_field].agg(['mean', 'min', 'max', 'std', 'count'])
                monthly = monthly.reset_index()
                monthly[time_field] = monthly[time_field].dt.strftime('%Y-%m')
                summaries['monthly'] = monthly.to_dict(orient='records')
            except:
                summaries['monthly'] = []
            
            return summaries
        
        # Process data and create summaries
        return self.stream_process(data_source, summarize_chunk)
    
    def progressive_load_and_analyze(self, file_path: str,
                                  processor_func: Callable[[pd.DataFrame], Dict[str, Any]],
                                  priority_filter: Callable[[pd.DataFrame], pd.Series] = None,
                                  sample_size: int = 1000) -> Dict[str, Any]:
        """
        Progressively load and analyze data, prioritizing important data points.
        
        Args:
            file_path: Path to data file
            processor_func: Function to process data
            priority_filter: Function that returns a boolean mask for high-priority data
            sample_size: Initial sample size to analyze
            
        Returns:
            Analysis results
        """
        if not os.path.exists(file_path):
            raise ValueError(f"File not found: {file_path}")
            
        # Initialize memory tracker
        initial_memory = self._get_memory_usage()
        peak_memory = initial_memory
        
        # Phase 1: Load a small sample first for quick initial analysis
        sample_df = None
        if file_path.endswith('.parquet'):
            # For Parquet, read first row group
            parquet_file = pq.ParquetFile(file_path)
            if parquet_file.num_row_groups > 0:
                table = parquet_file.read_row_group(0)
                sample_df = table.to_pandas()
                
                # Limit to sample size
                if len(sample_df) > sample_size:
                    sample_df = sample_df.sample(sample_size)
        else:
            # For other formats, read a small sample
            try:
                sample_df = pd.read_csv(file_path, nrows=sample_size)
            except:
                # If CSV reading fails, try other approaches
                pass
        
        # If we couldn't get a sample, skip initial analysis
        initial_results = {}
        if sample_df is not None and not sample_df.empty:
            # Run initial analysis on sample
            initial_results = processor_func(sample_df)
            
            # Update peak memory
            current_memory = self._get_memory_usage()
            peak_memory = max(peak_memory, current_memory)
            
            # Force garbage collection
            del sample_df
            gc.collect()
        
        # Phase 2: Identify high-priority data if filter provided
        priority_data = pd.DataFrame()
        
        if priority_filter is not None:
            # Stream through data to find high-priority points
            priority_chunks = []
            
            if file_path.endswith('.parquet'):
                for chunk in self._stream_parquet(file_path, chunk_size=10000):
                    if priority_filter is not None:
                        # Apply priority filter
                        mask = priority_filter(chunk)
                        if mask.any():
                            priority_chunks.append(chunk[mask])
                    
                    # Update peak memory
                    current_memory = self._get_memory_usage()
                    peak_memory = max(peak_memory, current_memory)
                    
                    # Force garbage collection
                    del chunk
                    gc.collect()
            else:
                for chunk in pd.read_csv(file_path, chunksize=10000):
                    if priority_filter is not None:
                        # Apply priority filter
                        mask = priority_filter(chunk)
                        if mask.any():
                            priority_chunks.append(chunk[mask])
                    
                    # Update peak memory
                    current_memory = self._get_memory_usage()
                    peak_memory = max(peak_memory, current_memory)
                    
                    # Force garbage collection
                    del chunk
                    gc.collect()
            
            # Combine priority chunks
            if priority_chunks:
                priority_data = pd.concat(priority_chunks, ignore_index=True)
                
                # Update peak memory
                current_memory = self._get_memory_usage()
                peak_memory = max(peak_memory, current_memory)
        
        # Phase 3: Full progressive analysis
        chunks_processed = 0
        total_rows = 0
        results = initial_results.copy() if initial_results else {}
        
        # Process file in chunks
        if file_path.endswith('.parquet'):
            for chunk in self._stream_parquet(file_path, chunk_size=50000):
                # Combine with priority data if this is the first chunk
                if chunks_processed == 0 and not priority_data.empty:
                    combined = pd.concat([priority_data, chunk], ignore_index=True)
                    # Drop duplicates if there's an ID column
                    id_col = None
                    for col in combined.columns:
                        if col.lower() in ['id', 'uuid', 'key']:
                            id_col = col
                            break
                    
                    if id_col is not None:
                        combined = combined.drop_duplicates(subset=[id_col])
                    
                    chunk_result = processor_func(combined)
                else:
                    chunk_result = processor_func(chunk)
                
                # Merge results
                self._merge_dicts(results, chunk_result)
                
                # Update counters
                chunks_processed += 1
                total_rows += len(chunk)
                
                # Update peak memory
                current_memory = self._get_memory_usage()
                peak_memory = max(peak_memory, current_memory)
                
                # Force garbage collection
                del chunk
                gc.collect()
        else:
            for chunk in pd.read_csv(file_path, chunksize=50000):
                # Combine with priority data if this is the first chunk
                if chunks_processed == 0 and not priority_data.empty:
                    combined = pd.concat([priority_data, chunk], ignore_index=True)
                    # Drop duplicates if there's an ID column
                    id_col = None
                    for col in combined.columns:
                        if col.lower() in ['id', 'uuid', 'key']:
                            id_col = col
                            break
                    
                    if id_col is not None:
                        combined = combined.drop_duplicates(subset=[id_col])
                    
                    chunk_result = processor_func(combined)
                else:
                    chunk_result = processor_func(chunk)
                
                # Merge results
                self._merge_dicts(results, chunk_result)
                
                # Update counters
                chunks_processed += 1
                total_rows += len(chunk)
                
                # Update peak memory
                current_memory = self._get_memory_usage()
                peak_memory = max(peak_memory, current_memory)
                
                # Force garbage collection
                del chunk
                gc.collect()
        
        # Add processing metadata
        final_memory = self._get_memory_usage()
        
        results['_metadata'] = {
            'file_path': file_path,
            'total_rows': total_rows,
            'chunks_processed': chunks_processed,
            'priority_rows': len(priority_data),
            'memory_stats': {
                'initial_mb': initial_memory,
                'peak_mb': peak_memory,
                'final_mb': final_memory
            }
        }
        
        return results
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB"""
        try:
            import psutil
            process = psutil.Process(os.getpid())
            memory_info = process.memory_info()
            return memory_info.rss / (1024 * 1024)  # Convert to MB
        except ImportError:
            # If psutil is not available, return an estimate
            return 0.0


class TimescaleDBAdapter:
    """
    Adapter for storing and retrieving wearables data from TimescaleDB.
    This is a mock implementation for demonstration purposes.
    """
    
    def __init__(self, connection_string: str = None):
        """
        Initialize TimescaleDB adapter.
        
        Args:
            connection_string: Connection string for TimescaleDB
        """
        self.connection_string = connection_string
        self.connected = False
    
    def connect(self) -> bool:
        """Connect to TimescaleDB"""
        # In a real implementation, this would establish a connection
        self.connected = True
        return True
    
    def store_partitioned_data(self, partitions: List[TimeWindowPartition]) -> bool:
        """
        Store partitioned data in TimescaleDB.
        
        Args:
            partitions: List of time window partitions
            
        Returns:
            Success status
        """
        if not self.connected:
            self.connect()
        
        # This is a mock implementation
        # In a real implementation, this would:
        # 1. Create hypertables if they don't exist
        # 2. Efficiently load data from partition files
        # 3. Apply TimescaleDB-specific optimizations
        
        print(f"[MOCK] Storing {len(partitions)} partitions in TimescaleDB")
        return True
    
    def query_data(self, metric: str, start_time: datetime, end_time: datetime,
                 aggregation: str = 'avg', interval: str = '1h') -> pd.DataFrame:
        """
        Query data from TimescaleDB with time-bucket aggregation.
        
        Args:
            metric: Metric to query
            start_time: Start time
            end_time: End time
            aggregation: Aggregation function (avg, min, max, etc.)
            interval: Time bucket interval
            
        Returns:
            DataFrame with query results
        """
        if not self.connected:
            self.connect()
        
        # This is a mock implementation
        # In a real implementation, this would execute SQL like:
        # SELECT time_bucket('1h', time) as bucket,
        #        avg(value) as avg_value
        # FROM metrics
        # WHERE metric = 'heart_rate' AND time BETWEEN '2023-01-01' AND '2023-01-31'
        # GROUP BY bucket
        # ORDER BY bucket;
        
        # Generate mock data
        periods = pd.date_range(start=start_time, end=end_time, freq=interval)
        mock_data = {
            'time': periods,
            f'{aggregation}_value': np.random.normal(loc=70, scale=10, size=len(periods))
        }
        
        return pd.DataFrame(mock_data)


# Usage example:
if __name__ == "__main__":
    # Create memory-efficient analytics engine
    analytics = MemoryEfficientAnalytics()
    
    # Example data (in real usage, this would be a file path)
    data = []
    for i in range(1000):
        timestamp = datetime(2023, 1, 1) + timedelta(hours=i)
        value = 70 + 10 * math.sin(i / 24 * 2 * math.pi) + np.random.normal(0, 3)
        data.append({
            'timestamp': timestamp,
            'value': value,
            'device_id': 'device_001',
            'metric': 'heart_rate'
        })
    
    # Partition data by day
    partitions = analytics.partition_by_time(data, 'timestamp', TimeWindow.DAY)
    print(f"Created {len(partitions)} time window partitions")
    
    # Apply compression to older partitions
    compressed = analytics.compress_historical_data(partitions)
    print(f"Compressed to {len(compressed)} partitions")
    
    # Example processor function
    def process_heartrate(df: pd.DataFrame) -> Dict[str, Any]:
        if 'value' not in df.columns:
            return {}
            
        return {
            'count': len(df),
            'mean': float(df['value'].mean()),
            'min': float(df['value'].min()),
            'max': float(df['value'].max()),
            'std': float(df['value'].std()),
            'anomalies': float((df['value'] > 100).sum())
        }
    
    # Process partitioned data
    results = analytics.process_partitioned_data(compressed, process_heartrate)
    print(f"Processing results: {results}")
    
    # Create hierarchical summary
    summary = analytics.hierarchical_summarize(data, 'timestamp', 'value')
    print(f"Created summaries at {len(summary)} time levels")
    
    # Clean up temporary files
    analytics.clear_temp_data()
    print("Cleaned up temporary files")
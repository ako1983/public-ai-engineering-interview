"""
Health RAG Engine for Wearables Analytics

This module implements a Retrieval Augmented Generation (RAG) system that enhances
wearables analytics with medical knowledge to provide more accurate and insightful
health recommendations.

Key features:
1. Medical knowledge base with vector embeddings
2. Contextual retrieval of relevant health information
3. Dynamic prompt generation based on detected patterns
4. Optimized for LLM context window limitations
"""

import os
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import json
import hashlib
import time
from dataclasses import dataclass
from enum import Enum

# Simulated dependencies for RAG components
# In a real implementation, these would be actual imports
try:
    from langchain.embeddings import OpenAIEmbeddings
    from langchain.vectorstores import Chroma
    from langchain.document_loaders import TextLoader, DirectoryLoader
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain.chains import RetrievalQA
    from langchain.prompts import PromptTemplate
    from langchain.chat_models import ChatOpenAI
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    # Create mock classes for documentation purposes
    class OpenAIEmbeddings:
        def __init__(self, *args, **kwargs):
            pass
            
    class Chroma:
        @staticmethod
        def from_documents(*args, **kwargs):
            pass
    
    class TextSplitter:
        def split_documents(self, *args, **kwargs):
            pass
    
    class RecursiveCharacterTextSplitter(TextSplitter):
        def __init__(self, *args, **kwargs):
            pass
    
    class PromptTemplate:
        def __init__(self, *args, **kwargs):
            pass
    
    class ChatOpenAI:
        def __init__(self, *args, **kwargs):
            pass


class KnowledgeCategory(str, Enum):
    """Categories of medical knowledge for retrieval"""
    CARDIOVASCULAR = "cardiovascular"
    DIABETES = "diabetes"
    SLEEP = "sleep"
    GENERAL_WELLNESS = "general_wellness"
    EXERCISE = "exercise"
    NUTRITION = "nutrition"
    MEDICAL_GUIDELINES = "medical_guidelines"


@dataclass
class RetrievedDocument:
    """Document retrieved from the knowledge base"""
    content: str
    metadata: Dict[str, Any]
    relevance_score: float


@dataclass
class RAGResult:
    """Result from RAG pipeline"""
    insight: str
    supporting_docs: List[RetrievedDocument]
    processing_time: float
    tokens_used: int
    prompt_tokens: int
    completion_tokens: int


class HealthKnowledgeBase:
    """
    Vector database of health and medical knowledge for RAG.
    Stores medical guidelines, research, and health information.
    """
    
    def __init__(self, knowledge_dir: str = "medical_knowledge", 
                embedding_model: str = "text-embedding-ada-002"):
        """
        Initialize the health knowledge base.
        
        Args:
            knowledge_dir: Directory containing medical knowledge documents
            embedding_model: Model to use for text embeddings
        """
        self.knowledge_dir = knowledge_dir
        self.embedding_model = embedding_model
        self.vector_store = None
        self.embeddings = None
        
        # Track document statistics
        self.doc_count = 0
        self.categories = {}
        
        # Cache for frequent queries
        self.query_cache = {}
        
        if LANGCHAIN_AVAILABLE:
            self.embeddings = OpenAIEmbeddings(model=embedding_model)
    
    def initialize(self, force_reload: bool = False) -> bool:
        """
        Initialize or load the knowledge base.
        
        Args:
            force_reload: Force reloading knowledge even if already initialized
            
        Returns:
            Success status
        """
        if self.vector_store is not None and not force_reload:
            return True
            
        try:
            if not LANGCHAIN_AVAILABLE:
                print("LangChain not available. Using mock knowledge base.")
                self._initialize_mock_knowledge()
                return True
                
            # Check if persisted DB exists
            db_path = f"{self.knowledge_dir}_vectordb"
            if os.path.exists(db_path) and not force_reload:
                self.vector_store = Chroma(
                    persist_directory=db_path,
                    embedding_function=self.embeddings
                )
                self.doc_count = len(self.vector_store.get()['ids'])
                return True
            
            # Create vector store from documents
            if not os.path.exists(self.knowledge_dir):
                os.makedirs(self.knowledge_dir, exist_ok=True)
                self._populate_sample_knowledge()
            
            # Load and process documents
            documents = self._load_documents()
            
            # Split documents into chunks
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1000, 
                chunk_overlap=100
            )
            doc_chunks = text_splitter.split_documents(documents)
            
            # Create vector store
            self.vector_store = Chroma.from_documents(
                documents=doc_chunks,
                embedding=self.embeddings,
                persist_directory=db_path
            )
            
            self.doc_count = len(doc_chunks)
            return True
            
        except Exception as e:
            print(f"Error initializing knowledge base: {e}")
            self._initialize_mock_knowledge()
            return False
    
    def _initialize_mock_knowledge(self):
        """Initialize a mock knowledge base for demonstration"""
        self.doc_count = 100  # Pretend we have 100 documents
        self.categories = {
            KnowledgeCategory.CARDIOVASCULAR: 25,
            KnowledgeCategory.DIABETES: 20,
            KnowledgeCategory.SLEEP: 15,
            KnowledgeCategory.GENERAL_WELLNESS: 15,
            KnowledgeCategory.EXERCISE: 10,
            KnowledgeCategory.NUTRITION: 10,
            KnowledgeCategory.MEDICAL_GUIDELINES: 5
        }
    
    def _populate_sample_knowledge(self):
        """Populate sample medical knowledge for demonstration"""
        # In a real implementation, this would download or extract
        # actual medical guidelines and knowledge documents
        
        sample_knowledge = {
            "cardiovascular_guidelines.txt": """
                Cardiovascular Health Guidelines
                
                Resting Heart Rate:
                - Normal resting heart rate for adults: 60-100 bpm
                - Athletic/fit individuals: 40-60 bpm
                - Consistently above 100 bpm (tachycardia) may indicate:
                  * Stress, anxiety, or emotional distress
                  * Fever or infection
                  * Anemia
                  * Thyroid issues (hyperthyroidism)
                  * Heart failure or cardiomyopathy
                  * Medication side effects
                
                Heart Rate Variability (HRV):
                - Higher HRV generally indicates better cardiovascular health and fitness
                - Low HRV is associated with:
                  * Increased stress and poor recovery
                  * Higher risk of cardiovascular events
                  * Autonomic nervous system imbalance
                
                Blood Pressure Guidelines:
                - Normal: <120/80 mmHg
                - Elevated: 120-129/<80 mmHg
                - Hypertension Stage 1: 130-139/80-89 mmHg
                - Hypertension Stage 2: ≥140/≥90 mmHg
                - Hypertensive Crisis: >180/>120 mmHg
                
                Recommended Actions for Abnormal Heart Rate Patterns:
                1. Persistent high resting heart rate: Consult healthcare provider
                2. Frequent episodes of very high heart rate: Cardiac evaluation
                3. Irregular heart rhythm: ECG monitoring
                4. Very low heart rate with symptoms: Urgent medical attention
            """,
            
            "glucose_management.txt": """
                Glucose Management Guidelines
                
                Normal Blood Glucose Ranges:
                - Fasting: 3.9-5.6 mmol/L (70-100 mg/dL)
                - 2 hours postprandial: <7.8 mmol/L (<140 mg/dL)
                
                Prediabetes Ranges:
                - Fasting: 5.6-6.9 mmol/L (100-125 mg/dL)
                - 2 hours postprandial: 7.8-11.0 mmol/L (140-199 mg/dL)
                
                Diabetes Ranges:
                - Fasting: ≥7.0 mmol/L (≥126 mg/dL)
                - 2 hours postprandial: ≥11.1 mmol/L (≥200 mg/dL)
                
                Continuous Glucose Monitoring Metrics:
                - Time in Range (TIR): Aim for >70% within 3.9-10.0 mmol/L (70-180 mg/dL)
                - Glycemic Variability: Coefficient of variation <36%
                - Hypoglycemia: <3.9 mmol/L (<70 mg/dL) for <4% of time
                - Hyperglycemia: >10.0 mmol/L (>180 mg/dL) for <25% of time
                
                Dawn Phenomenon:
                - Characterized by early morning rise in blood glucose
                - Caused by hormonal changes (growth hormone, cortisol)
                - Management strategies:
                  * Adjust medication timing
                  * Modify evening carbohydrate intake
                  * Consider overnight continuous glucose monitoring
                
                Warning Signs Requiring Medical Attention:
                1. Severe hypoglycemia (<3.0 mmol/L or <54 mg/dL)
                2. Persistent hyperglycemia (>13.9 mmol/L or >250 mg/dL)
                3. Large daily glucose fluctuations (>5.6 mmol/L or >100 mg/dL)
                4. Progressive deterioration in glycemic control
            """,
            
            "sleep_health.txt": """
                Sleep Health Guidelines
                
                Recommended Sleep Duration:
                - Adults: 7-9 hours
                - Older adults (65+): 7-8 hours
                
                Normal Sleep Architecture:
                - Sleep cycles: 90-110 minutes each
                - 4-5 cycles per night
                - REM sleep: 20-25% of total sleep time
                - Deep sleep: 10-20% of total sleep time
                
                Sleep Efficiency:
                - Normal: >85% (time asleep / time in bed)
                - Poor: <75%
                
                Factors Affecting Sleep Quality:
                - Environmental: noise, light, temperature
                - Behavioral: caffeine, alcohol, screen time
                - Physiological: pain, respiratory issues, movement disorders
                
                Impact on Health Biomarkers:
                - Poor sleep linked to increased inflammation markers
                - Sleep restriction impacts glucose metabolism
                - Sleep quality affects heart rate variability
                - Chronic sleep deficiency linked to hypertension risk
                
                Recommendations for Sleep Improvement:
                1. Consistent sleep-wake schedule
                2. Sleep-conducive environment (dark, quiet, cool)
                3. Limit screen time before bed
                4. Regular physical activity (not too close to bedtime)
                5. Mindfulness practices for sleep onset
            """
        }
        
        # Write sample knowledge files
        for filename, content in sample_knowledge.items():
            category = filename.split('_')[0]
            category_dir = os.path.join(self.knowledge_dir, category)
            os.makedirs(category_dir, exist_ok=True)
            
            with open(os.path.join(category_dir, filename), 'w') as f:
                f.write(content.strip())
    
    def _load_documents(self) -> List[Any]:
        """Load documents from knowledge directory"""
        if not LANGCHAIN_AVAILABLE:
            return []
            
        try:
            # Use LangChain's DirectoryLoader if available
            from langchain.document_loaders import DirectoryLoader
            loader = DirectoryLoader(
                self.knowledge_dir, 
                glob="**/*.txt",
                show_progress=True
            )
            documents = loader.load()
            
            # Update categories stats
            self.categories = {}
            for doc in documents:
                category = doc.metadata.get('source', '').split('/')[-2]
                if category in KnowledgeCategory.__members__:
                    self.categories[category] = self.categories.get(category, 0) + 1
            
            return documents
            
        except Exception as e:
            print(f"Error loading documents: {e}")
            return []
    
    def query_knowledge(self, query: str, categories: List[KnowledgeCategory] = None, 
                       max_docs: int = 5) -> List[RetrievedDocument]:
        """
        Query the knowledge base for relevant documents.
        
        Args:
            query: Query string
            categories: Optional list of categories to filter by
            max_docs: Maximum number of documents to return
            
        Returns:
            List of relevant document chunks
        """
        # Check cache first
        cache_key = f"{query}_{str(categories)}_{max_docs}"
        if cache_key in self.query_cache:
            return self.query_cache[cache_key]
            
        if not self.vector_store:
            if not self.initialize():
                return self._get_mock_results(query, categories, max_docs)
        
        try:
            if not LANGCHAIN_AVAILABLE:
                return self._get_mock_results(query, categories, max_docs)
                
            # Prepare filters based on categories
            filter_dict = {}
            if categories:
                category_paths = [f"{cat.value}" for cat in categories]
                filter_dict["source"] = {"$or": [{"$contains": path} for path in category_paths]}
            
            # Query vector store
            docs_with_scores = self.vector_store.similarity_search_with_score(
                query, k=max_docs, filter=filter_dict if filter_dict else None
            )
            
            # Format results
            results = []
            for doc, score in docs_with_scores:
                results.append(RetrievedDocument(
                    content=doc.page_content,
                    metadata=doc.metadata,
                    relevance_score=float(score)
                ))
            
            # Cache results
            self.query_cache[cache_key] = results
            return results
            
        except Exception as e:
            print(f"Error querying knowledge base: {e}")
            return self._get_mock_results(query, categories, max_docs)
    
    def _get_mock_results(self, query: str, categories: List[KnowledgeCategory] = None, 
                         max_docs: int = 5) -> List[RetrievedDocument]:
        """Generate mock results when the real knowledge base is unavailable"""
        results = []
        
        # Create mock results based on the query
        if "heart" in query.lower() or "cardio" in query.lower():
            results.append(RetrievedDocument(
                content="Normal resting heart rate for adults ranges from 60-100 bpm. Athletes may have lower resting heart rates, typically 40-60 bpm. Consistently elevated heart rates may indicate cardiovascular issues.",
                metadata={"source": "cardiovascular/guidelines.txt", "category": "cardiovascular"},
                relevance_score=0.92
            ))
            results.append(RetrievedDocument(
                content="Heart rate variability (HRV) is a measure of variation in time between heartbeats. Higher HRV generally indicates better cardiovascular health and autonomic nervous system function.",
                metadata={"source": "cardiovascular/hrv_research.txt", "category": "cardiovascular"},
                relevance_score=0.87
            ))
        
        if "glucose" in query.lower() or "diabetes" in query.lower():
            results.append(RetrievedDocument(
                content="Normal blood glucose ranges are 3.9-5.6 mmol/L (70-100 mg/dL) when fasting and below 7.8 mmol/L (140 mg/dL) two hours after eating. Time in range (TIR) target is >70% within 3.9-10.0 mmol/L.",
                metadata={"source": "diabetes/glucose_targets.txt", "category": "diabetes"},
                relevance_score=0.94
            ))
            results.append(RetrievedDocument(
                content="Dawn phenomenon is characterized by an early morning increase in blood glucose, typically between 4am and 8am, caused by normal hormonal changes during sleep.",
                metadata={"source": "diabetes/common_patterns.txt", "category": "diabetes"},
                relevance_score=0.88
            ))
        
        if "sleep" in query.lower():
            results.append(RetrievedDocument(
                content="Adults typically need 7-9 hours of sleep per night. Quality sleep includes 4-5 complete sleep cycles, each lasting 90-110 minutes and including both REM and deep sleep phases.",
                metadata={"source": "sleep/requirements.txt", "category": "sleep"},
                relevance_score=0.91
            ))
        
        # Add generic results if we don't have enough specific ones
        while len(results) < max_docs:
            results.append(RetrievedDocument(
                content=f"Generic health information related to {query}. This is placeholder content for demonstration purposes.",
                metadata={"source": "general_wellness/overview.txt", "category": "general_wellness"},
                relevance_score=0.7 - (0.05 * len(results))  # Decreasing relevance
            ))
        
        return results[:max_docs]


class WearablesRAGEngine:
    """
    RAG-enhanced analytics engine for wearables data.
    Combines statistical analysis with medical knowledge retrieval.
    """
    
    def __init__(self, knowledge_base: Optional[HealthKnowledgeBase] = None,
                llm_model: str = "gpt-3.5-turbo", 
                api_key: Optional[str] = None):
        """
        Initialize the RAG engine.
        
        Args:
            knowledge_base: Optional pre-initialized knowledge base
            llm_model: LLM model to use for insight generation
            api_key: Optional API key for LLM
        """
        self.knowledge_base = knowledge_base or HealthKnowledgeBase()
        self.llm_model = llm_model
        
        # Set API key if provided
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
        
        # Initialize LLM if available
        self.llm = None
        if LANGCHAIN_AVAILABLE:
            try:
                self.llm = ChatOpenAI(
                    model_name=llm_model,
                    temperature=0.2,
                    max_tokens=1000
                )
            except Exception as e:
                print(f"Error initializing LLM: {e}")
    
    def initialize(self) -> bool:
        """Initialize the RAG engine and its components"""
        return self.knowledge_base.initialize()
    
    def generate_insights(self, analysis_results: Dict[str, Any], 
                         user_context: Dict[str, Any],
                         max_insights: int = 3) -> RAGResult:
        """
        Generate health insights by combining analytics with medical knowledge.
        
        Args:
            analysis_results: Results from wearables analytics
            user_context: User context (demographics, health history, etc.)
            max_insights: Maximum number of insights to generate
            
        Returns:
            RAG result with insights and supporting documents
        """
        start_time = time.time()
        
        # Initialize knowledge base if needed
        if not self.knowledge_base.initialize():
            return self._get_mock_insights(analysis_results, user_context)
        
        # Extract key metrics and patterns from analysis results
        metrics = self._extract_key_metrics(analysis_results)
        
        # Determine relevant knowledge categories based on metrics
        categories = self._determine_relevant_categories(metrics)
        
        # Generate queries based on detected patterns
        queries = self._generate_knowledge_queries(metrics, user_context)
        
        # Retrieve relevant knowledge
        all_docs = []
        for query in queries:
            docs = self.knowledge_base.query_knowledge(
                query, 
                categories=categories,
                max_docs=3  # Limit docs per query for context efficiency
            )
            all_docs.extend(docs)
        
        # Remove duplicates and sort by relevance
        unique_docs = {}
        for doc in all_docs:
            doc_id = hashlib.md5(doc.content.encode()).hexdigest()
            if doc_id not in unique_docs or doc.relevance_score > unique_docs[doc_id].relevance_score:
                unique_docs[doc_id] = doc
        
        sorted_docs = sorted(unique_docs.values(), key=lambda x: x.relevance_score, reverse=True)
        
        # Limit to most relevant docs to fit context window
        relevant_docs = sorted_docs[:7]  # Arbitrary limit to ensure context fits
        
        # Generate optimized prompt
        prompt = self._generate_insight_prompt(metrics, user_context, relevant_docs)
        
        # Generate insights using LLM
        insights, tokens = self._generate_llm_response(prompt)
        
        # Create RAG result
        result = RAGResult(
            insight=insights,
            supporting_docs=relevant_docs,
            processing_time=time.time() - start_time,
            tokens_used=tokens.get('total_tokens', 0),
            prompt_tokens=tokens.get('prompt_tokens', 0),
            completion_tokens=tokens.get('completion_tokens', 0)
        )
        
        return result
    
    def _extract_key_metrics(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Extract key metrics and patterns from analysis results"""
        metrics = {}
        
        # Extract heart rate metrics if available
        if hr_analysis := analysis_results.get('heartrate_analysis'):
            metrics['resting_hr'] = hr_analysis.get('resting_hr_trend', {}).get('average_value')
            metrics['resting_hr_trend'] = hr_analysis.get('resting_hr_trend', {}).get('trend_direction')
            metrics['hrv'] = hr_analysis.get('hrv_trend', {}).get('average_value')
            metrics['hr_anomalies'] = hr_analysis.get('anomaly_count')
            metrics['hr_risk_factors'] = hr_analysis.get('risk_factors', [])
        
        # Extract glucose metrics if available
        if glucose_analysis := analysis_results.get('glucose_analysis'):
            metrics['avg_glucose'] = glucose_analysis.get('average_glucose_trend', {}).get('average_value')
            metrics['glucose_trend'] = glucose_analysis.get('average_glucose_trend', {}).get('trend_direction')
            metrics['time_in_range'] = glucose_analysis.get('time_in_range_trend', {}).get('average_value')
            metrics['glucose_variability'] = glucose_analysis.get('variability_trend', {}).get('average_value')
            metrics['dawn_phenomenon'] = glucose_analysis.get('dawn_phenomenon_severity')
            metrics['hypo_episodes'] = glucose_analysis.get('hypo_episodes')
            metrics['hyper_episodes'] = glucose_analysis.get('hyper_episodes')
            metrics['glucose_risk_factors'] = glucose_analysis.get('risk_factors', [])
        
        return metrics
    
    def _determine_relevant_categories(self, metrics: Dict[str, Any]) -> List[KnowledgeCategory]:
        """Determine relevant knowledge categories based on metrics"""
        categories = []
        
        # Always include general wellness
        categories.append(KnowledgeCategory.GENERAL_WELLNESS)
        
        # Add specific categories based on metrics
        if any(k in metrics for k in ['resting_hr', 'hrv', 'hr_anomalies']):
            categories.append(KnowledgeCategory.CARDIOVASCULAR)
        
        if any(k in metrics for k in ['avg_glucose', 'time_in_range', 'glucose_variability', 
                                     'dawn_phenomenon', 'hypo_episodes', 'hyper_episodes']):
            categories.append(KnowledgeCategory.DIABETES)
        
        # Add others based on risk factors
        risk_factors = []
        risk_factors.extend(metrics.get('hr_risk_factors', []))
        risk_factors.extend(metrics.get('glucose_risk_factors', []))
        
        risk_text = ' '.join(risk_factors).lower()
        if any(term in risk_text for term in ['sleep', 'insomnia', 'fatigue']):
            categories.append(KnowledgeCategory.SLEEP)
        
        if any(term in risk_text for term in ['exercise', 'activity', 'fitness']):
            categories.append(KnowledgeCategory.EXERCISE)
        
        if any(term in risk_text for term in ['diet', 'nutrition', 'food', 'weight']):
            categories.append(KnowledgeCategory.NUTRITION)
        
        return categories
    
    def _generate_knowledge_queries(self, metrics: Dict[str, Any], 
                                  user_context: Dict[str, Any]) -> List[str]:
        """Generate specific knowledge queries based on detected patterns"""
        queries = []
        
        # Generate heart rate queries
        if 'resting_hr' in metrics:
            resting_hr = metrics['resting_hr']
            if resting_hr > 80:
                queries.append(f"Elevated resting heart rate {resting_hr} bpm health implications")
            elif resting_hr < 50:
                queries.append(f"Low resting heart rate {resting_hr} bpm in {'athletes' if user_context.get('is_athlete') else 'adults'}")
            else:
                queries.append("Normal resting heart rate health implications")
        
        if 'hrv' in metrics:
            hrv = metrics['hrv']
            if hrv:
                queries.append(f"Heart rate variability {'high' if hrv > 50 else 'low'} clinical significance")
        
        if metrics.get('hr_anomalies', 0) > 0:
            queries.append("Heart rate anomalies and arrhythmia detection")
        
        # Generate glucose queries
        if 'avg_glucose' in metrics:
            avg_glucose = metrics['avg_glucose']
            if avg_glucose > 7.8:  # > 140 mg/dL
                queries.append(f"Elevated average glucose {avg_glucose:.1f} mmol/L health implications")
            elif avg_glucose < 4.0:  # < 72 mg/dL
                queries.append(f"Low average glucose {avg_glucose:.1f} mmol/L risks")
        
        if 'time_in_range' in metrics:
            tir = metrics['time_in_range']
            if tir < 70:
                queries.append(f"Low glucose time in range {tir:.1f}% improvement strategies")
        
        if 'glucose_variability' in metrics:
            variability = metrics['glucose_variability']
            if variability > 36:
                queries.append("High glucose variability health risks")
        
        if metrics.get('dawn_phenomenon') is not None and metrics['dawn_phenomenon'] > 3:
            queries.append("Dawn phenomenon management strategies")
        
        if metrics.get('hypo_episodes', 0) > 0:
            queries.append("Hypoglycemia prevention strategies")
        
        if metrics.get('hyper_episodes', 0) > 0:
            queries.append("Hyperglycemia management strategies")
        
        # Add user context specific queries
        if user_context.get('has_diabetes'):
            queries.append("Diabetes management wearables monitoring best practices")
        
        if user_context.get('has_hypertension'):
            queries.append("Hypertension management with heart rate monitoring")
        
        if user_context.get('is_athlete'):
            queries.append("Athletic performance optimization heart rate zones")
        
        # Ensure we have at least one query
        if not queries:
            queries.append("General wearables health data interpretation guidelines")
        
        return queries
    
    def _generate_insight_prompt(self, metrics: Dict[str, Any], 
                              user_context: Dict[str, Any],
                              documents: List[RetrievedDocument]) -> str:
        """
        Generate an optimized prompt for the LLM.
        Carefully constructed to maximize context window utility.
        """
        # Extract most important user context elements
        age = user_context.get('age', 'unknown age')
        gender = user_context.get('gender', 'unknown gender')
        health_conditions = user_context.get('health_conditions', [])
        
        # Format metrics for prompt
        metrics_text = []
        
        if 'resting_hr' in metrics:
            metrics_text.append(f"Resting heart rate: {metrics['resting_hr']:.1f} bpm, trend: {metrics['resting_hr_trend']}")
        
        if 'hrv' in metrics and metrics['hrv']:
            metrics_text.append(f"Heart rate variability: {metrics['hrv']:.1f}")
        
        if 'hr_anomalies' in metrics:
            metrics_text.append(f"Heart rate anomalies detected: {metrics['hr_anomalies']}")
        
        if 'avg_glucose' in metrics:
            metrics_text.append(f"Average glucose: {metrics['avg_glucose']:.1f} mmol/L, trend: {metrics['glucose_trend']}")
        
        if 'time_in_range' in metrics:
            metrics_text.append(f"Glucose time in range: {metrics['time_in_range']:.1f}%")
        
        if 'glucose_variability' in metrics:
            metrics_text.append(f"Glucose variability: {metrics['glucose_variability']:.1f}%")
        
        if 'dawn_phenomenon' in metrics and metrics['dawn_phenomenon'] is not None:
            metrics_text.append(f"Dawn phenomenon severity: {metrics['dawn_phenomenon']:.1f}/10")
        
        if 'hypo_episodes' in metrics:
            metrics_text.append(f"Hypoglycemic episodes: {metrics['hypo_episodes']}")
        
        if 'hyper_episodes' in metrics:
            metrics_text.append(f"Hyperglycemic episodes: {metrics['hyper_episodes']}")
        
        # Format risk factors
        risk_factors = []
        risk_factors.extend(metrics.get('hr_risk_factors', []))
        risk_factors.extend(metrics.get('glucose_risk_factors', []))
        
        # Format retrieved documents
        docs_text = []
        for i, doc in enumerate(documents, 1):
            # Format document with source
            source = doc.metadata.get('source', 'unknown').split('/')[-1]
            docs_text.append(f"[{i}] {source}: {doc.content.strip()}")
        
        # Construct the prompt
        prompt = f"""You are a healthcare AI assistant analyzing wearable device data and providing evidence-based health insights.

USER INFORMATION:
- {age} year old {gender}
{f"- Health conditions: {', '.join(health_conditions)}" if health_conditions else "- No known health conditions"}

WEARABLE METRICS:
{chr(10).join(f"- {m}" for m in metrics_text)}

{f"DETECTED RISK FACTORS: {chr(10)}{chr(10).join(f'- {r}' for r in risk_factors)}" if risk_factors else "NO SPECIFIC RISK FACTORS DETECTED."}

RELEVANT MEDICAL KNOWLEDGE:
{chr(10).join(docs_text)}

Based on this wearable data and medical knowledge, provide 2-3 evidence-based health insights. For each insight:
1. Explain what the data shows
2. Why it matters for this person's health
3. Specific, actionable recommendations
4. Reference relevant medical knowledge where appropriate

Keep recommendations practical and personalized. Focus on the most important health patterns. Format your response concisely with clear headings.
"""
        return prompt
    
    def _generate_llm_response(self, prompt: str) -> Tuple[str, Dict[str, int]]:
        """Generate response from LLM with token tracking"""
        if not LANGCHAIN_AVAILABLE or not self.llm:
            return self._get_mock_llm_response(prompt)
        
        try:
            from langchain.schema import HumanMessage
            
            # Use a simple approach with token counting
            response = self.llm.predict_messages([HumanMessage(content=prompt)])
            
            # Extract content
            content = response.content
            
            # Estimate token counts
            tokens = {
                'prompt_tokens': len(prompt) // 4,  # Rough estimate
                'completion_tokens': len(content) // 4,  # Rough estimate
                'total_tokens': (len(prompt) + len(content)) // 4  # Rough estimate
            }
            
            return content, tokens
            
        except Exception as e:
            print(f"Error generating LLM response: {e}")
            return self._get_mock_llm_response(prompt)
    
    def _get_mock_llm_response(self, prompt: str) -> Tuple[str, Dict[str, int]]:
        """Generate a mock LLM response when real LLM is unavailable"""
        # Extract key information from prompt for more realistic mock
        is_athlete = "athlete" in prompt.lower()
        has_diabetes = "diabetes" in prompt.lower()
        has_high_glucose = "high glucose" in prompt.lower() or "elevated glucose" in prompt.lower()
        has_low_hrv = "low hrv" in prompt.lower() or "low heart rate variability" in prompt.lower()
        
        # Generate appropriate mock response
        if has_diabetes or has_high_glucose:
            response = """# Glucose Management Insights

## Elevated Glucose Variability
**Analysis:** Your glucose data shows significant variability throughout the day with a coefficient of variation of 38%, which is above the recommended target of <36%.

**Health Impact:** High glucose variability can increase oxidative stress and inflammation even when average glucose levels appear acceptable. This pattern is associated with increased risk of diabetes complications.

**Recommendations:**
- Spread carbohydrate intake more evenly throughout the day
- Consider adding protein to carbohydrate-rich meals to slow absorption
- Monitor timing of meals in relation to glucose peaks

## Dawn Phenomenon Detected
**Analysis:** Your data shows consistent glucose elevations between 4-8am, characteristic of dawn phenomenon.

**Health Impact:** Morning glucose spikes can contribute to elevated A1c levels and may increase cardiovascular risk over time.

**Recommendations:**
- Discuss medication timing adjustments with your healthcare provider
- Consider earlier dinner times (at least 3 hours before bed)
- Experiment with different evening snack compositions (high protein, low carb)

Reference: Guidelines recommend addressing dawn phenomenon when morning glucose levels consistently rise >2.2 mmol/L from baseline."""
        elif is_athlete:
            response = """# Athletic Performance Insights

## Excellent Heart Rate Recovery
**Analysis:** Your heart rate data shows rapid recovery after exercise, dropping an average of 35 bpm in the first minute post-exertion.

**Health Impact:** Rapid heart rate recovery indicates excellent cardiovascular fitness and efficient autonomic nervous system function, which supports performance and recovery.

**Recommendations:**
- Continue your current training approach as recovery metrics are optimal
- Consider heart rate zone training to further optimize cardio sessions
- Track HRV trends to identify optimal high-intensity training days

## Training Load Optimization
**Analysis:** Your resting heart rate and HRV data suggest optimal recovery on Wednesdays and Saturdays.

**Health Impact:** Training during periods of high HRV and low resting heart rate leads to better adaptations and reduced injury risk.

**Recommendations:**
- Schedule your most intense training sessions on Wednesdays and Saturdays
- Consider lighter recovery activities on Mondays when metrics show highest stress
- Continue monitoring for changes in this pattern with seasonal training changes"""
        elif has_low_hrv:
            response = """# Cardiovascular Health Insights

## Reduced Heart Rate Variability
**Analysis:** Your heart rate variability (HRV) shows consistently low values (25-30ms), particularly during weekdays.

**Health Impact:** Low HRV indicates autonomic nervous system imbalance and increased stress load, which is associated with higher cardiovascular risk and reduced recovery capacity.

**Recommendations:**
- Incorporate daily breathwork or meditation (starting with just 5 minutes)
- Review sleep hygiene as sleep quality directly impacts HRV
- Consider stress management techniques during high-stress workdays

## Elevated Nighttime Heart Rate
**Analysis:** Your nighttime resting heart rate averages 72 bpm, which is higher than optimal for recovery.

**Health Impact:** Elevated nighttime heart rate may indicate insufficient recovery, poor sleep quality, or excessive evening stimulation.

**Recommendations:**
- Avoid caffeine after 2pm and alcohol within 3 hours of bedtime
- Establish a consistent sleep schedule, even on weekends
- Create a 30-minute wind-down routine before sleep to activate parasympathetic nervous system

Reference: Clinical guidelines suggest HRV should ideally exceed 50ms for adults, with higher values indicating better cardiovascular health."""
        else:
            response = """# Health Optimization Insights

## Metabolic Stability Patterns
**Analysis:** Your glucose levels remain within optimal range 78% of the time with minimal hypoglycemic episodes, indicating good metabolic health.

**Health Impact:** Stable glucose patterns support consistent energy levels, reduced inflammation, and long-term metabolic health.

**Recommendations:**
- Continue your current dietary pattern, especially your consistent meal timing
- The mid-afternoon protein snack appears particularly effective for glucose stability
- Consider walking after your largest meal of the day to further improve metrics

## Cardiovascular Recovery Opportunity
**Analysis:** Your resting heart rate shows elevated patterns (82-88 bpm) during work days with improved recovery (65-72 bpm) on weekends.

**Health Impact:** The significant work/weekend heart rate difference suggests your nervous system is under stress during workdays without adequate recovery time.

**Recommendations:**
- Incorporate brief relaxation breaks during workdays (2-5 minutes every 2 hours)
- Schedule at least one 20-minute nature walk during each workday
- Practice 4-7-8 breathing (4 second inhale, 7 second hold, 8 second exhale) before stressful meetings

Reference: Research shows even brief stress-reduction techniques can significantly improve heart rate metrics and autonomic balance within 2-3 weeks of consistent practice."""
        
        # Mock token usage
        tokens = {
            'prompt_tokens': len(prompt) // 4,
            'completion_tokens': len(response) // 4,
            'total_tokens': (len(prompt) + len(response)) // 4
        }
        
        return response, tokens
    
    def _get_mock_insights(self, analysis_results: Dict[str, Any], 
                         user_context: Dict[str, Any]) -> RAGResult:
        """Generate mock insights when the real RAG pipeline is unavailable"""
        # Generate a simple mock response
        mock_response, tokens = self._get_mock_llm_response("")
        
        # Create mock retrieved documents
        mock_docs = [
            RetrievedDocument(
                content="Heart rate variability (HRV) is an important measure of autonomic nervous system function. Higher HRV generally indicates better cardiovascular health and stress resilience.",
                metadata={"source": "cardiovascular/hrv_basics.txt", "category": "cardiovascular"},
                relevance_score=0.92
            ),
            RetrievedDocument(
                content="Normal glucose values are 3.9-5.6 mmol/L (70-100 mg/dL) when fasting, and below 7.8 mmol/L (140 mg/dL) two hours after eating.",
                metadata={"source": "diabetes/glucose_ranges.txt", "category": "diabetes"},
                relevance_score=0.89
            )
        ]
        
        # Create RAG result
        result = RAGResult(
            insight=mock_response,
            supporting_docs=mock_docs,
            processing_time=0.5,  # Mock processing time
            tokens_used=tokens['total_tokens'],
            prompt_tokens=tokens['prompt_tokens'],
            completion_tokens=tokens['completion_tokens']
        )
        
        return result


class ContextWindowOptimizer:
    """
    Optimizes data for LLM context windows when dealing with large datasets.
    Selects most relevant data points and summarizes others.
    """
    
    def __init__(self, max_tokens: int = 6000):
        """
        Initialize the context window optimizer.
        
        Args:
            max_tokens: Maximum tokens for context window
        """
        self.max_tokens = max_tokens
    
    def optimize_time_series(self, data: List[Dict[str, Any]],
                            anomalies: List[int] = None) -> Dict[str, Any]:
        """
        Optimize time series data for context window.
        
        Args:
            data: Time series data
            anomalies: Indices of anomalies to preserve
            
        Returns:
            Optimized data representation
        """
        if not data:
            return {"error": "No data provided"}
            
        # Estimate token usage for entire dataset
        estimated_tokens = self._estimate_tokens(data)
        
        # If data fits in context, return summary with full data
        if estimated_tokens <= self.max_tokens:
            return {
                "data_summary": self._generate_summary(data),
                "full_data": data,
                "optimization_applied": False,
                "token_estimate": estimated_tokens
            }
        
        # Need to optimize data to fit context
        optimization_result = self._apply_optimization(data, anomalies)
        
        return optimization_result
    
    def _estimate_tokens(self, data: List[Dict[str, Any]]) -> int:
        """Estimate token usage for data"""
        # Simple estimation: each data point is about 10-15 tokens
        # This is a rough estimate and should be calibrated for your data
        return len(data) * 12
    
    def _generate_summary(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate statistical summary of time series data"""
        if not data:
            return {}
            
        # Extract values
        values = [d.get('value', 0) for d in data if d.get('value') is not None]
        
        if not values:
            return {}
            
        # Calculate basic statistics
        summary = {
            "count": len(values),
            "mean": sum(values) / len(values),
            "min": min(values),
            "max": max(values),
            "range": max(values) - min(values),
        }
        
        # Add percentiles
        sorted_values = sorted(values)
        summary["median"] = sorted_values[len(sorted_values) // 2]
        summary["percentile_25"] = sorted_values[len(sorted_values) // 4]
        summary["percentile_75"] = sorted_values[3 * len(sorted_values) // 4]
        
        # Add time range if available
        timestamps = [d.get('timestamp') for d in data if d.get('timestamp')]
        if timestamps:
            summary["start_time"] = min(timestamps)
            summary["end_time"] = max(timestamps)
            summary["duration"] = str(max(timestamps) - min(timestamps))
        
        return summary
    
    def _apply_optimization(self, data: List[Dict[str, Any]], 
                          anomalies: List[int] = None) -> Dict[str, Any]:
        """Apply optimization to fit data in context window"""
        # Calculate target size
        target_points = self.max_tokens // 12  # Based on token estimate
        
        # Always include summary
        summary = self._generate_summary(data)
        
        # Points to keep
        keep_indices = set()
        
        # If anomalies are provided, always include them
        if anomalies:
            keep_indices.update(anomalies)
        
        # Always include first and last points
        keep_indices.add(0)
        keep_indices.add(len(data) - 1)
        
        # Determine if we need to downsample further
        remaining_points = target_points - len(keep_indices) - 1  # -1 for summary
        
        # If we need to downsample more
        if remaining_points < len(data) - len(keep_indices):
            # Add equidistant points
            indices = list(range(len(data)))
            # Remove already selected indices
            indices = [i for i in indices if i not in keep_indices]
            
            # Select equidistant points
            if indices:
                step = len(indices) / remaining_points
                selected = [indices[int(i * step)] for i in range(min(remaining_points, len(indices)))]
                keep_indices.update(selected)
        else:
            # We can include all points
            keep_indices = set(range(len(data)))
        
        # Get optimized dataset
        optimized_data = [data[i] for i in sorted(keep_indices)]
        
        # Return optimized result
        return {
            "data_summary": summary,
            "optimized_data": optimized_data,
            "optimization_applied": True,
            "preserved_percentage": (len(optimized_data) / len(data)) * 100,
            "preserved_anomalies": len([i for i in anomalies if i in keep_indices]) if anomalies else 0,
            "token_estimate": len(optimized_data) * 12 + 100  # +100 for summary
        }


# Usage example:
if __name__ == "__main__":
    # Initialize knowledge base
    knowledge_base = HealthKnowledgeBase()
    knowledge_base.initialize()
    
    # Initialize RAG engine
    rag_engine = WearablesRAGEngine(knowledge_base=knowledge_base)
    
    # Sample wearables analysis results
    sample_analysis = {
        "heartrate_analysis": {
            "resting_hr_trend": {
                "average_value": 72.5,
                "trend_direction": "stable"
            },
            "hrv_trend": {
                "average_value": 42.3,
                "trend_direction": "improving"
            },
            "anomaly_count": 2,
            "risk_factors": ["Moderate stress levels", "Occasional sleep disruption"]
        },
        "glucose_analysis": {
            "average_glucose_trend": {
                "average_value": 5.8,
                "trend_direction": "stable"
            },
            "time_in_range_trend": {
                "average_value": 85.2,
                "trend_direction": "improving"
            },
            "variability_trend": {
                "average_value": 22.5,
                "trend_direction": "stable"
            },
            "dawn_phenomenon_severity": 4.2,
            "hypo_episodes": 1,
            "hyper_episodes": 3,
            "risk_factors": ["Moderate glucose variability", "Occasional evening hyperglycemia"]
        }
    }
    
    # Sample user context
    sample_user = {
        "age": 45,
        "gender": "female",
        "health_conditions": ["Prediabetes", "Hypertension"],
        "medications": ["Metformin", "Lisinopril"],
        "has_diabetes": False,
        "has_hypertension": True,
        "is_athlete": False
    }
    
    # Generate insights
    insights = rag_engine.generate_insights(sample_analysis, sample_user)
    
    # Print results
    print("=" * 80)
    print("HEALTH INSIGHTS")
    print("=" * 80)
    print(insights.insight)
    
    print("\n" + "=" * 80)
    print(f"Supporting References ({len(insights.supporting_docs)})")
    print("=" * 80)
    for i, doc in enumerate(insights.supporting_docs, 1):
        src = doc.metadata.get('source', 'unknown').split('/')[-1]
        print(f"{i}. {src} (relevance: {doc.relevance_score:.2f})")
    
    print("\n" + "=" * 80)
    print(f"Generated in {insights.processing_time:.2f}s using {insights.tokens_used} tokens")
"""
Generate a comprehensive health report based on EMR and wearables data.

This script runs automatically without user interaction and produces a complete
health report for the sample patient.
"""

import os
import sys
import json
from datetime import datetime, timedelta

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import our services
from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient,
    extract_chronic_conditions,
    extract_vital_events,
    initialize_emr_data
)

def generate_health_report():
    """Generate a comprehensive health report for the sample patient."""
    print("Initializing EMR data...")
    initialize_emr_data()
    
    # Get filtered data
    chronic_conditions = extract_chronic_conditions("test_user_id")
    vital_events = extract_vital_events("test_user_id")
    
    # Get raw data for additional information
    synthea_data = load_sample_synthea_data()
    patient_profile = parse_synthea_patient(synthea_data)
    
    # Format the report
    report = []
    report.append("=" * 80)
    report.append(f"PATIENT HEALTH REPORT")
    report.append("=" * 80)
    report.append(f"Patient ID: {patient_profile.patient_id}")
    report.append(f"Report Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append("-" * 80)
    
    # Demographics summary (from FHIR data)
    patient_resource = None
    for entry in synthea_data.get("entry", []):
        if entry.get("resource", {}).get("resourceType") == "Patient":
            patient_resource = entry.get("resource", {})
            break
    
    if patient_resource:
        # Extract name
        name = "Unknown"
        if patient_resource.get("name") and len(patient_resource["name"]) > 0:
            name_parts = []
            if patient_resource["name"][0].get("given"):
                name_parts.extend(patient_resource["name"][0]["given"])
            if patient_resource["name"][0].get("family"):
                name_parts.append(patient_resource["name"][0]["family"])
            if name_parts:
                name = " ".join(name_parts)
        
        # Extract gender and birthdate
        gender = patient_resource.get("gender", "Unknown")
        birthdate = patient_resource.get("birthDate", "Unknown")
        
        # Calculate age
        age = "Unknown"
        if birthdate != "Unknown":
            try:
                birth_date = datetime.strptime(birthdate, "%Y-%m-%d")
                age = (datetime.now() - birth_date).days // 365
            except:
                pass
        
        report.append("\nPATIENT DEMOGRAPHICS:")
        report.append(f"Name: {name}")
        report.append(f"Gender: {gender.capitalize()}")
        report.append(f"Birthdate: {birthdate}")
        report.append(f"Age: {age} years")
    
    # Health summary
    report.append("\nHEALTH SUMMARY:")
    report.append(f"Chronic Conditions: {len(chronic_conditions)}")
    report.append(f"Significant Health Events: {len(vital_events)}")
    report.append(f"Medications: {len(patient_profile.medications)}")
    
    # Chronic conditions section
    report.append("\n" + "=" * 80)
    report.append("CHRONIC CONDITIONS")
    report.append("=" * 80)
    
    if chronic_conditions:
        for i, condition in enumerate(chronic_conditions, 1):
            onset_str = condition.onset_date.strftime("%Y-%m-%d") if condition.onset_date else "Unknown"
            report.append(f"{i}. {condition.description}")
            report.append(f"   Status: {condition.status}")
            report.append(f"   Onset: {onset_str}")
            if condition.severity:
                report.append(f"   Severity: {condition.severity}")
            report.append("")
    else:
        report.append("No active chronic conditions found.")
    
    # Health events section
    report.append("\n" + "=" * 80)
    report.append("SIGNIFICANT HEALTH EVENTS (Most Recent First)")
    report.append("=" * 80)
    
    if vital_events:
        # Sort by date (most recent first)
        sorted_events = sorted(vital_events, key=lambda e: e.date, reverse=True)
        for i, event in enumerate(sorted_events, 1):
            date_str = event.date.strftime("%Y-%m-%d") if event.date else "Unknown"
            report.append(f"{i}. {event.description}")
            report.append(f"   Type: {event.event_type}")
            report.append(f"   Date: {date_str}")
            if event.provider:
                report.append(f"   Provider: {event.provider}")
            report.append("")
    else:
        report.append("No significant health events found.")
    
    # Medications section
    report.append("\n" + "=" * 80)
    report.append("MEDICATIONS")
    report.append("=" * 80)
    
    if patient_profile.medications:
        # Group by status
        active_meds = [m for m in patient_profile.medications if m.status.lower() == "active"]
        completed_meds = [m for m in patient_profile.medications if m.status.lower() == "completed"]
        
        if active_meds:
            report.append("\nCurrent Medications:")
            report.append("-" * 40)
            for i, med in enumerate(active_meds, 1):
                prescribed_str = med.prescribed_date.strftime("%Y-%m-%d") if med.prescribed_date else "Unknown"
                report.append(f"{i}. {med.display}")
                if med.dosage_instructions:
                    report.append(f"   Instructions: {med.dosage_instructions}")
                report.append(f"   Prescribed: {prescribed_str}")
                report.append("")
        
        if completed_meds:
            report.append("\nPast Medications:")
            report.append("-" * 40)
            # Sort by prescribed date (most recent first)
            sorted_meds = sorted(completed_meds, 
                                key=lambda m: m.prescribed_date if m.prescribed_date else datetime.min, 
                                reverse=True)
            for i, med in enumerate(sorted_meds[:10], 1):  # Show only the 10 most recent
                prescribed_str = med.prescribed_date.strftime("%Y-%m-%d") if med.prescribed_date else "Unknown"
                report.append(f"{i}. {med.display}")
                if med.dosage_instructions:
                    report.append(f"   Instructions: {med.dosage_instructions}")
                report.append(f"   Prescribed: {prescribed_str}")
                report.append("")
            
            if len(sorted_meds) > 10:
                report.append(f"... and {len(sorted_meds) - 10} more past medications.")
    else:
        report.append("No medications found.")
    
    # Footer
    report.append("\n" + "=" * 80)
    report.append("END OF REPORT")
    report.append("=" * 80)
    
    # Write the report to a file
    report_text = "\n".join(report)
    print(report_text)
    
    # Save to file
    with open("patient_health_report.txt", "w") as f:
        f.write(report_text)
    
    print(f"\nReport saved to patient_health_report.txt")

if __name__ == "__main__":
    generate_health_report()
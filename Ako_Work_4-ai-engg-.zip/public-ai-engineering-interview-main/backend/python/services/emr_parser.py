"""
EMR Data Processing Service

This module handles parsing and extracting key health information from various EMR formats,
specifically Synthea patient JSON files.

TODO: Implement the following functions for the coding interview:
1. parse_synthea_patient() - Extract key health events and conditions
2. extract_chronic_conditions() - Identify chronic conditions from patient data
3. extract_vital_events() - Parse key health events (hospitalizations, procedures, etc.)
"""
import json
import os
from typing import Dict, List, Any, Optional
from datetime import datetime
from pydantic import BaseModel


class ChronicCondition(BaseModel):
    """Represents a chronic condition from EMR data"""
    code: str
    description: str
    onset_date: Optional[datetime]
    severity: Optional[str]
    status: str  # active, resolved, etc.


class HealthEvent(BaseModel):
    """Represents a significant health event"""
    event_type: str  # hospitalization, procedure, medication, etc.
    description: str
    date: datetime
    code: Optional[str]
    provider: Optional[str]


class Medication(BaseModel):
    """Represents a medication from EMR data"""
    status: str  # active, completed, etc.
    code: Optional[str]
    display: str
    dosage_instructions: Optional[str] 
    prescribed_date: Optional[datetime]

class PatientHealthProfile(BaseModel):
    """Consolidated patient health profile from EMR data"""
    patient_id: str
    chronic_conditions: List[ChronicCondition]
    health_events: List[HealthEvent]
    medications: List[Medication]
    last_updated: datetime

# Global variable to store parsed patient data
_parsed_patient_data: Optional[PatientHealthProfile] = None


def initialize_emr_data() -> None:
    """
    Initialize EMR data by loading and parsing sample Synthea data.
    This should be called once at application startup.
    """
    global _parsed_patient_data
    
    # Load sample data
    synthea_json = load_sample_synthea_data()
    
    # Parse the data
    _parsed_patient_data = parse_synthea_patient(synthea_json)
    
    print(f"EMR data initialized for patient: {_parsed_patient_data.patient_id}")


def extract_patient_id(synthea_json: Dict[str, Any]) -> str:
    """
    Extract patient ID from FHIR Bundle.
    
    Args:
        synthea_json: Raw Synthea patient JSON (FHIR Bundle)
        
    Returns:
        str: Patient ID
    """
    try:
        # The patient ID is in the first entry's resource
        if synthea_json.get("entry") and len(synthea_json["entry"]) > 0:
            first_entry = synthea_json["entry"][0]
            if first_entry.get("resource") and first_entry["resource"].get("resourceType") == "Patient":
                return first_entry["resource"]["id"]
        
        # Fallback: try to extract from fullUrl
        if synthea_json.get("entry") and len(synthea_json["entry"]) > 0:
            full_url = synthea_json["entry"][0].get("fullUrl", "")
            if full_url.startswith("urn:uuid:"):
                return full_url.replace("urn:uuid:", "")
        
        return "Unknown"
    except Exception as e:
        print(f"Error extracting patient ID: {e}")
        return "Unknown"


def parse_synthea_patient(synthea_json: Dict[str, Any]) -> PatientHealthProfile:
    """
    Parse Synthea patient JSON and extract key health information.
    
    Expected input: Synthea JSON
    Expected output: PatientHealthProfile with extracted conditions and events
    
    Key areas to implement:
    - Extract Condition resources for chronic conditions
    - Parse Encounter resources for hospitalizations/visits
    - Extract Procedure resources for medical procedures
    - Parse MedicationRequest resources for current medications
    
    Args:
        synthea_json: Raw Synthea patient JSON (FHIR Bundle)
        
    Returns:
        PatientHealthProfile: Structured patient health data
    """
    patient_id = extract_patient_id(synthea_json)
    
    # Initialize lists to store extracted data
    chronic_conditions = []
    health_events = []
    medications = []
    
    # Process each entry in the FHIR bundle
    if synthea_json.get("entry"):
        for entry in synthea_json["entry"]:
            if not entry.get("resource"):
                continue
                
            resource = entry["resource"]
            resource_type = resource.get("resourceType")
            
            # Extract Condition resources for chronic conditions
            if resource_type == "Condition":
                try:
                    # Check if it has clinical status (active, resolved, etc.)
                    clinical_status = "unknown"
                    if resource.get("clinicalStatus") and resource["clinicalStatus"].get("coding"):
                        for coding in resource["clinicalStatus"]["coding"]:
                            if coding.get("code"):
                                clinical_status = coding["code"]
                                break
                    
                    # Extract code and description
                    code = ""
                    description = "Unknown condition"
                    if resource.get("code") and resource["code"].get("coding"):
                        for coding in resource["code"]["coding"]:
                            if coding.get("code") and coding.get("system") == "http://snomed.info/sct":
                                code = coding["code"]
                                description = coding.get("display", "Unknown condition")
                                break
                        # If no SNOMED code found, try the text field
                        if not code and resource["code"].get("text"):
                            description = resource["code"]["text"]
                    
                    # Extract onset date
                    onset_date = None
                    if resource.get("onsetDateTime"):
                        onset_date = datetime.fromisoformat(resource["onsetDateTime"].replace("Z", "+00:00"))
                    
                    # Extract severity if available
                    severity = None
                    if resource.get("severity") and resource["severity"].get("coding"):
                        for coding in resource["severity"]["coding"]:
                            severity = coding.get("display") or coding.get("code")
                            if severity:
                                break
                    
                    # Create ChronicCondition object
                    condition = ChronicCondition(
                        code=code,
                        description=description,
                        onset_date=onset_date,
                        severity=severity,
                        status=clinical_status
                    )
                    
                    chronic_conditions.append(condition)
                except Exception as e:
                    print(f"Error processing condition: {e}")
            
            # Extract Encounter resources for health events
            elif resource_type == "Encounter":
                try:
                    # Extract encounter type/class
                    event_type = "visit"
                    if resource.get("class") and resource["class"].get("code"):
                        encounter_class = resource["class"]["code"]
                        if encounter_class == "EMER":
                            event_type = "emergency"
                        elif encounter_class == "IMP":
                            event_type = "hospitalization"
                        elif encounter_class == "AMB":
                            event_type = "ambulatory"
                        # Add more mappings as needed
                    
                    # Extract description
                    description = "Healthcare visit"
                    if resource.get("type") and len(resource["type"]) > 0:
                        for type_entry in resource["type"]:
                            if type_entry.get("coding") and len(type_entry["coding"]) > 0:
                                for coding in type_entry["coding"]:
                                    if coding.get("display"):
                                        description = coding["display"]
                                        break
                    
                    # Extract date
                    event_date = datetime.now()  # Default to current time
                    if resource.get("period") and resource["period"].get("start"):
                        event_date = datetime.fromisoformat(resource["period"]["start"].replace("Z", "+00:00"))
                    
                    # Extract provider/location
                    provider = None
                    if resource.get("serviceProvider") and resource["serviceProvider"].get("display"):
                        provider = resource["serviceProvider"]["display"]
                    
                    # Extract code
                    code = None
                    if resource.get("type") and len(resource["type"]) > 0:
                        for type_entry in resource["type"]:
                            if type_entry.get("coding") and len(type_entry["coding"]) > 0:
                                for coding in type_entry["coding"]:
                                    if coding.get("code"):
                                        code = coding["code"]
                                        break
                    
                    # Create HealthEvent object
                    event = HealthEvent(
                        event_type=event_type,
                        description=description,
                        date=event_date,
                        code=code,
                        provider=provider
                    )
                    
                    health_events.append(event)
                except Exception as e:
                    print(f"Error processing encounter: {e}")
            
            # Extract Procedure resources for health events
            elif resource_type == "Procedure":
                try:
                    # Extract procedure code and description
                    code = None
                    description = "Medical procedure"
                    if resource.get("code") and resource["code"].get("coding"):
                        for coding in resource["code"]["coding"]:
                            if coding.get("code"):
                                code = coding["code"]
                            if coding.get("display"):
                                description = coding["display"]
                                break
                        # If no description in coding, try text field
                        if description == "Medical procedure" and resource["code"].get("text"):
                            description = resource["code"]["text"]
                    
                    # Extract date
                    event_date = datetime.now()  # Default to current time
                    if resource.get("performedPeriod") and resource["performedPeriod"].get("start"):
                        event_date = datetime.fromisoformat(resource["performedPeriod"]["start"].replace("Z", "+00:00"))
                    elif resource.get("performedDateTime"):
                        event_date = datetime.fromisoformat(resource["performedDateTime"].replace("Z", "+00:00"))
                    
                    # Extract performer/provider
                    provider = None
                    if resource.get("performer") and len(resource["performer"]) > 0:
                        for performer in resource["performer"]:
                            if performer.get("actor") and performer["actor"].get("display"):
                                provider = performer["actor"]["display"]
                                break
                    
                    # Create HealthEvent object for the procedure
                    event = HealthEvent(
                        event_type="procedure",
                        description=description,
                        date=event_date,
                        code=code,
                        provider=provider
                    )
                    
                    health_events.append(event)
                except Exception as e:
                    print(f"Error processing procedure: {e}")
            
            # Extract MedicationRequest resources for medications
            elif resource_type == "MedicationRequest":
                try:
                    # Extract medication status
                    status = resource.get("status", "unknown")
                    
                    # Extract medication code and display name
                    code = None
                    display = "Unknown medication"
                    if resource.get("medicationCodeableConcept") and resource["medicationCodeableConcept"].get("coding"):
                        for coding in resource["medicationCodeableConcept"]["coding"]:
                            if coding.get("code"):
                                code = coding["code"]
                            if coding.get("display"):
                                display = coding["display"]
                                break
                        # If no display name in coding, try text field
                        if display == "Unknown medication" and resource["medicationCodeableConcept"].get("text"):
                            display = resource["medicationCodeableConcept"]["text"]
                    
                    # Extract dosage instructions
                    dosage_instructions = None
                    if resource.get("dosageInstruction") and len(resource["dosageInstruction"]) > 0:
                        for dosage in resource["dosageInstruction"]:
                            if dosage.get("text"):
                                dosage_instructions = dosage["text"]
                                break
                    
                    # Extract prescribed date
                    prescribed_date = None
                    if resource.get("authoredOn"):
                        prescribed_date = datetime.fromisoformat(resource["authoredOn"].replace("Z", "+00:00"))
                    
                    # Create Medication object
                    medication = Medication(
                        status=status,
                        code=code,
                        display=display,
                        dosage_instructions=dosage_instructions,
                        prescribed_date=prescribed_date
                    )
                    
                    medications.append(medication)
                except Exception as e:
                    print(f"Error processing medication request: {e}")
    
    # Create and return the PatientHealthProfile
    return PatientHealthProfile(
        patient_id=patient_id,
        chronic_conditions=chronic_conditions,
        health_events=health_events,
        medications=medications,
        last_updated=datetime.now()
    )


def extract_chronic_conditions(user_id: str) -> List[ChronicCondition]:
    """
    Extract and classify chronic conditions from FHIR Condition resources.
    
    Focus on conditions that are:
    - Currently active
    - Chronic/long-term (not acute)
    
    Args:
        user_id: Ignored for now since sample data is used
        
    Returns:
        List[ChronicCondition]: Filtered chronic conditions
    """
    global _parsed_patient_data
    
    if _parsed_patient_data is None:
        print("Warning: EMR data not initialized. Call initialize_emr_data() first.")
        return []
    
    # Define a list of SNOMED CT codes that represent chronic conditions
    # Based on the SNOMED_CT_README.md and common chronic conditions
    chronic_condition_codes = [
        # From SNOMED_CT_README.md
        "40055000",  # Chronic sinusitis
        "82423001",  # Chronic pain
        "278860009", # Chronic low back pain
        "1121000119107", # Chronic neck pain
        "714628002", # Prediabetes
        "271737000", # Anemia
        "73595000",  # Stress
        "66383009",  # Gingivitis
        
        # Additional common chronic conditions
        "73211009",  # Diabetes mellitus type 1
        "44054006",  # Diabetes mellitus type 2
        "13645005",  # Chronic obstructive pulmonary disease
        "38341003",  # Hypertension
        "56265001",  # Heart disease
        "195967001", # Asthma
        "396275006", # Osteoarthritis
        "69896004",  # Rheumatoid arthritis
        "35489007",  # Depression
        "370143000", # Major depressive disorder
        "59621000",  # Essential hypertension
    ]
    
    # Keywords that indicate chronic conditions (for text-based filtering)
    chronic_keywords = [
        "chronic", "long-term", "persistent", "ongoing", "lifelong",
        "diabetes", "hypertension", "arthritis", "asthma", "depression",
        "hypothyroidism", "hyperthyroidism", "COPD", "heart disease",
        "kidney disease", "hepatitis", "HIV", "AIDS", "multiple sclerosis",
        "Parkinson's", "Alzheimer's", "epilepsy", "fibromyalgia"
    ]
    
    # Filter conditions based on:
    # 1. Active status
    # 2. Chronic condition codes or keywords in description
    chronic_conditions = []
    for condition in _parsed_patient_data.chronic_conditions:
        # Only include active conditions
        if condition.status.lower() != "active":
            continue
        
        # Check if it's a known chronic condition by code
        if condition.code in chronic_condition_codes:
            chronic_conditions.append(condition)
            continue
        
        # If no code match, check for keywords in the description
        description_lower = condition.description.lower()
        if any(keyword in description_lower for keyword in chronic_keywords):
            chronic_conditions.append(condition)
    
    # Sort by onset date if available
    chronic_conditions.sort(
        key=lambda c: c.onset_date if c.onset_date is not None else datetime.min,
        reverse=True  # Most recent first
    )
    
    return chronic_conditions


def extract_vital_events(user_id: str) -> List[HealthEvent]:
    """
    Extract significant health events from encounters and procedures.
    
    Focus on events that impact health:
    - Emergency room visits
    - Hospitalizations
    - Major procedures
    - Specialist consultations
    
    Args:
        user_id: Ignored for now since sample data is used
        
    Returns:
        List[HealthEvent]: Significant health events chronologically ordered
    """
    global _parsed_patient_data
    
    if _parsed_patient_data is None:
        print("Warning: EMR data not initialized. Call initialize_emr_data() first.")
        return []
    
    # Define criteria for significant health events
    significant_event_types = [
        "emergency",        # Emergency room visits
        "hospitalization",  # Hospital stays
        "procedure"         # Medical procedures
    ]
    
    # Keywords that indicate significant procedures or events
    significant_keywords = [
        "surgery", "operation", "transplant", "implant", "biopsy",
        "catheterization", "endoscopy", "emergency", "urgent", "critical",
        "fracture", "trauma", "stroke", "heart attack", "myocardial infarction",
        "cardiac", "pulmonary", "respiratory", "seizure", "infection",
        "specialist", "consultation", "intensive care", "ICU", "icu",
        "physical therapy", "rehabilitation", "transfusion", "dialysis"
    ]
    
    # Significant SNOMED CT procedure codes (common major procedures)
    significant_procedure_codes = [
        "80146002",    # Appendectomy
        "234336002",   # Pulmonary function test
        "117015009",   # Thoracic surgery procedure
        "64915003",    # Cardiac catheterization
        "71388002",    # Colonoscopy
        "25267002",    # Biopsy procedure
        "387713003",   # Surgical procedure
        "52734007",    # Total hip replacement
        "79068005",    # Needle biopsy
        "309795001",   # Surgical removal of foreign body
        "395094005",   # Insertion of pacemaker
        "110468005",   # Heart valve replacement
        "108241001",   # Thoracentesis
        "73761001",    # Colonoscopy
        "80146002",    # Appendectomy
        "34068001",    # Heart valve replacement
        "427889009",   # Knee joint replacement
    ]
    
    # Filter health events
    vital_events = []
    for event in _parsed_patient_data.health_events:
        # Include events based on type (emergency, hospitalization, etc.)
        if event.event_type in significant_event_types:
            # Always include emergency visits and hospitalizations
            if event.event_type in ["emergency", "hospitalization"]:
                vital_events.append(event)
                continue
                
            # For procedures, check if they are significant
            if event.event_type == "procedure":
                # Check if procedure has a significant code
                if event.code in significant_procedure_codes:
                    vital_events.append(event)
                    continue
                    
                # Check for keywords in the description
                description_lower = event.description.lower()
                if any(keyword in description_lower for keyword in significant_keywords):
                    vital_events.append(event)
                    continue
        
        # For other event types, check if description contains significant keywords
        description_lower = event.description.lower()
        if any(keyword in description_lower for keyword in significant_keywords):
            vital_events.append(event)
    
    # Sort by date (most recent first)
    vital_events.sort(key=lambda e: e.date, reverse=True)
    
    return vital_events


def load_sample_synthea_data() -> Dict[str, Any]:
    try:
        # Get the directory where this module is located
        module_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Try multiple possible paths for the synthea data
        possible_paths = [
            # Docker path: /app/synthea/data
            os.path.join("/app", "synthea", "data"),
            # Local development path: go up from services/ to project root, then to synthea/data
            os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(module_dir))), "synthea", "data"),
            # Alternative local path: relative to current working directory
            os.path.join("synthea", "data"),
        ]
        
        sample_file = "Colleen54_Maxie520_Olson653_e49e402a-d3c3-e448-18a6-388444f8825e.json"
        
        for data_dir in possible_paths:
            file_path = os.path.join(data_dir, sample_file)
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    return json.load(f)
        
        # If we get here, none of the paths worked
        print(f"Could not find sample data file. Tried paths: {possible_paths}")
        return {}
        
    except Exception as e:
        print(f"Error loading sample data: {e}")
        return {}
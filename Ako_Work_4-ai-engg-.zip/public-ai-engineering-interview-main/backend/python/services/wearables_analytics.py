"""
Wearables Data Analytics Service

This module processes and analyzes wearables data to identify health trends
and patterns.

TODO: Implement the following functions for the coding interview:
1. analyze_heartrate_trends() - Process heartrate data
2. analyze_glucose_trends() - Process glucose data
"""

from typing import List, Optional
from datetime import datetime, timedelta
from pydantic import BaseModel
from enum import Enum
from vital import Client
import os
from dotenv import load_dotenv

# Load environment variables and initialize Vital client
load_dotenv()
VITAL_API_KEY = os.getenv("VITAL_API_KEY")
VITAL_ENVIRONMENT = os.getenv("VITAL_ENV")
VITAL_REGION = os.getenv("VITAL_REGION")

client = Client(api_key=VITAL_API_KEY, environment=VITAL_ENVIRONMENT, region=VITAL_REGION)


class TrendDirection(str, Enum):
    IMPROVING = "improving"
    STABLE = "stable"
    DECLINING = "declining"
    INSUFFICIENT_DATA = "insufficient_data"


class BiometricTrend(BaseModel):
    """Represents a trend analysis for a specific biometric"""
    metric_name: str
    trend_direction: TrendDirection
    confidence_score: float  # 0.0 to 1.0
    average_value: float
    trend_percentage: float  # positive = improving, negative = declining
    data_points: int
    analysis_period_days: int
    last_updated: datetime


class HeartRateAnalysis(BaseModel):
    """Heartrate trend analysis results"""
    resting_hr_trend: BiometricTrend
    max_hr_trend: BiometricTrend
    hrv_trend: Optional[BiometricTrend]
    anomaly_count: int
    risk_factors: List[str]


class GlucoseAnalysis(BaseModel):
    """Glucose trend analysis results"""
    average_glucose_trend: BiometricTrend
    time_in_range_trend: BiometricTrend  # Percentage time in 70-180 mg/dL
    variability_trend: BiometricTrend
    dawn_phenomenon_severity: Optional[float]
    hypo_episodes: int
    hyper_episodes: int
    risk_factors: List[str]


# class WearablesHealthMetrics(BaseModel):
#     """Consolidated wearables health metrics for scoring"""
#     user_id: str
#     heartrate_analysis: Optional[HeartRateAnalysis]
#     glucose_analysis: Optional[GlucoseAnalysis]
#     overall_trend_score: float  # 0-100, higher = better trends
#     data_quality_score: float  # 0-100, higher = more reliable data
#     last_analysis: datetime


def analyze_heartrate_trends(user_id: str) -> HeartRateAnalysis:
    """
    Analyze heartrate trends from Vital API data (Oura, Fitbit, etc.).
    
    Key metrics to analyze:
    - Resting heartrate trends (lower is generally better)
    - Heartrate variability (HRV) trends (higher is generally better)
    - Anomaly detection (unusual spikes/drops)
    
    Args:
        user_id: Vital user ID
        
    Returns:
        HeartRateAnalysis: Comprehensive heartrate trend analysis
    """
    try:
        # Get heartrate data from Vital API
        heartrate_data = get_heartrate_data(user_id)
        if not heartrate_data:
            return None
        
        # Process the heartrate data
        # Sort data by timestamp
        sorted_data = sorted(heartrate_data, key=lambda x: x.get('timestamp'))
        
        # Extract heart rate values
        hr_values = [item.get('value') for item in sorted_data if item.get('value') is not None]
        
        if not hr_values or len(hr_values) < 3:  # Need at least 3 data points for meaningful analysis
            return HeartRateAnalysis(
                resting_hr_trend=BiometricTrend(
                    metric_name="resting_heartrate",
                    trend_direction=TrendDirection.INSUFFICIENT_DATA,
                    confidence_score=0.0,
                    average_value=0.0,
                    trend_percentage=0.0,
                    data_points=len(hr_values),
                    analysis_period_days=7,
                    last_updated=datetime.now()
                ),
                max_hr_trend=BiometricTrend(
                    metric_name="max_heartrate",
                    trend_direction=TrendDirection.INSUFFICIENT_DATA,
                    confidence_score=0.0,
                    average_value=0.0,
                    trend_percentage=0.0,
                    data_points=len(hr_values),
                    analysis_period_days=7,
                    last_updated=datetime.now()
                ),
                hrv_trend=None,
                anomaly_count=0,
                risk_factors=[]
            )
        
        # Calculate resting heart rate (assume lowest 10% of values represent resting)
        resting_values = sorted(hr_values)[:max(1, int(len(hr_values) * 0.1))]
        avg_resting_hr = sum(resting_values) / len(resting_values)
        
        # Calculate max heart rate (highest 5% of values)
        max_hr_values = sorted(hr_values, reverse=True)[:max(1, int(len(hr_values) * 0.05))]
        avg_max_hr = sum(max_hr_values) / len(max_hr_values)
        
        # Calculate heart rate variability
        # In a real implementation, we would use RMSSD or SDNN from actual RR intervals
        # For this example, we'll use a simple standard deviation
        hrv = calculate_hrv(hr_values) if len(hr_values) > 5 else None
        
        # Analyze trend by comparing first half with second half of the data
        half_point = len(sorted_data) // 2
        first_half = [item.get('value') for item in sorted_data[:half_point] if item.get('value') is not None]
        second_half = [item.get('value') for item in sorted_data[half_point:] if item.get('value') is not None]
        
        if len(first_half) > 0 and len(second_half) > 0:
            first_half_resting = sorted(first_half)[:max(1, int(len(first_half) * 0.1))]
            second_half_resting = sorted(second_half)[:max(1, int(len(second_half) * 0.1))]
            
            avg_first_resting = sum(first_half_resting) / len(first_half_resting)
            avg_second_resting = sum(second_half_resting) / len(second_half_resting)
            
            # Calculate trend percentage (negative means improving since lower HR is better)
            resting_trend_pct = ((avg_second_resting - avg_first_resting) / avg_first_resting) * 100
            
            # Determine trend direction
            resting_trend_direction = TrendDirection.STABLE
            if abs(resting_trend_pct) < 3:  # Less than 3% change is considered stable
                resting_trend_direction = TrendDirection.STABLE
            elif resting_trend_pct < 0:  # Decreasing resting HR is good
                resting_trend_direction = TrendDirection.IMPROVING
            else:  # Increasing resting HR could indicate issues
                resting_trend_direction = TrendDirection.DECLINING
                
            # Calculate confidence based on number of data points and consistency
            confidence_score = min(0.9, 0.5 + (len(hr_values) / 100))
        else:
            resting_trend_pct = 0.0
            resting_trend_direction = TrendDirection.INSUFFICIENT_DATA
            confidence_score = 0.3  # Low confidence with limited data
        
        # Detect anomalies (values that are 30% higher than average)
        anomaly_threshold = 1.3 * sum(hr_values) / len(hr_values)
        anomalies = [v for v in hr_values if v > anomaly_threshold]
        anomaly_count = len(anomalies)
        
        # Determine risk factors based on heart rate patterns
        risk_factors = identify_hr_risk_factors(hr_values, avg_resting_hr, anomaly_count)
        
        # Create HRV trend if we have enough data
        hrv_trend = None
        if hrv is not None:
            hrv_trend = BiometricTrend(
                metric_name="heart_rate_variability",
                trend_direction=TrendDirection.STABLE,  # Without historical data, assume stable
                confidence_score=confidence_score * 0.8,  # Slightly lower confidence for HRV
                average_value=hrv,
                trend_percentage=0.0,  # Cannot calculate trend without historical data
                data_points=len(hr_values),
                analysis_period_days=7,
                last_updated=datetime.now()
            )
        
        return HeartRateAnalysis(
            resting_hr_trend=BiometricTrend(
                metric_name="resting_heartrate",
                trend_direction=resting_trend_direction,
                confidence_score=confidence_score,
                average_value=avg_resting_hr,
                trend_percentage=resting_trend_pct,
                data_points=len(hr_values),
                analysis_period_days=7,
                last_updated=datetime.now()
            ),
            max_hr_trend=BiometricTrend(
                metric_name="max_heartrate",
                trend_direction=resting_trend_direction,  # Use same direction as resting for simplicity
                confidence_score=confidence_score * 0.9,  # Slightly lower confidence for max HR
                average_value=avg_max_hr,
                trend_percentage=resting_trend_pct,  # Use same trend as resting for simplicity
                data_points=len(hr_values),
                analysis_period_days=7,
                last_updated=datetime.now()
            ),
            hrv_trend=hrv_trend,
            anomaly_count=anomaly_count,
            risk_factors=risk_factors
        )
    except Exception as e:
        print(f"Error analyzing heartrate data for user {user_id}: {e}")
        return None


def calculate_hrv(hr_values: List[float]) -> float:
    """
    Calculate a simple heart rate variability metric.
    In a real implementation, this would use RMSSD or SDNN from RR intervals.
    
    Args:
        hr_values: List of heart rate values
        
    Returns:
        A simple HRV metric (standard deviation of heart rates)
    """
    if len(hr_values) < 2:
        return 0.0
    
    # Calculate standard deviation as a simple proxy for HRV
    mean = sum(hr_values) / len(hr_values)
    variance = sum((x - mean) ** 2 for x in hr_values) / len(hr_values)
    return variance ** 0.5  # square root to get standard deviation


def identify_hr_risk_factors(hr_values: List[float], resting_hr: float, anomaly_count: int) -> List[str]:
    """
    Identify potential risk factors based on heart rate patterns.
    
    Args:
        hr_values: List of heart rate values
        resting_hr: Average resting heart rate
        anomaly_count: Number of anomalies detected
        
    Returns:
        List of risk factor strings
    """
    risk_factors = []
    
    # Check for high resting heart rate
    if resting_hr > 80:  # Generally, resting HR above 80 can indicate issues
        risk_factors.append("Elevated resting heart rate")
    
    # Check for high variability (standard deviation)
    hr_std_dev = calculate_hrv(hr_values)
    if hr_std_dev > 20:  # Arbitrary threshold for demonstration
        risk_factors.append("High heart rate variability")
    elif hr_std_dev < 5 and len(hr_values) > 10:  # Very low variability can also be concerning
        risk_factors.append("Unusually low heart rate variability")
    
    # Check for frequent anomalies
    if anomaly_count > 5 or (anomaly_count > 0 and len(hr_values) < 20):
        risk_factors.append("Frequent heart rate spikes")
    
    return risk_factors


def analyze_glucose_trends(user_id: str) -> GlucoseAnalysis:
    """
    Analyze glucose trends from CGM data (Freestyle Libre, Dexcom).
    
    Key metrics to analyze:
    - Average glucose levels
    - Time in range (70-180 mg/dL for non-diabetics, 70-140 for diabetics)
    - Glucose variability (coefficient of variation)
    - Dawn phenomenon detection; periodic episodes of hyperglycemia experienced by patients with diabetes in the early morning hours
    - Hypoglycemic/hyperglycemic episodes
        - Hypoglycemic episodes: episodes of blood glucose below 70 mg/dL
        - Hyperglycemic episodes: episodes of blood glucose above 180 mg/dL
    
    Args:
        user_id: Vital user ID
        
    Returns:
        GlucoseAnalysis: Comprehensive glucose trend analysis
    """
    try:
        glucose_data = get_glucose_data(user_id)
        if not glucose_data:
            return None
        
        # Constants for glucose analysis (in mmol/L)
        # Normal ranges: 3.9-10.0 mmol/L (70-180 mg/dL) for non-diabetics
        HYPO_THRESHOLD = 3.9  # 70 mg/dL
        HYPER_THRESHOLD = 10.0  # 180 mg/dL
        OPTIMAL_RANGE = (4.4, 7.8)  # 80-140 mg/dL (tighter control)
        
        # Sort data by timestamp
        sorted_data = sorted(glucose_data, key=lambda x: x.get('timestamp'))
        
        # Extract glucose values
        glucose_values = [item.get('value') for item in sorted_data if item.get('value') is not None]
        
        if not glucose_values or len(glucose_values) < 5:  # Need at least 5 readings for meaningful analysis
            return GlucoseAnalysis(
                average_glucose_trend=BiometricTrend(
                    metric_name="average_glucose",
                    trend_direction=TrendDirection.INSUFFICIENT_DATA,
                    confidence_score=0.0,
                    average_value=0.0,
                    trend_percentage=0.0,
                    data_points=len(glucose_values),
                    analysis_period_days=7,
                    last_updated=datetime.now()
                ),
                time_in_range_trend=BiometricTrend(
                    metric_name="time_in_range",
                    trend_direction=TrendDirection.INSUFFICIENT_DATA,
                    confidence_score=0.0,
                    average_value=0.0,
                    trend_percentage=0.0,
                    data_points=len(glucose_values),
                    analysis_period_days=7,
                    last_updated=datetime.now()
                ),
                variability_trend=BiometricTrend(
                    metric_name="glucose_variability",
                    trend_direction=TrendDirection.INSUFFICIENT_DATA,
                    confidence_score=0.0,
                    average_value=0.0,
                    trend_percentage=0.0,
                    data_points=len(glucose_values),
                    analysis_period_days=7,
                    last_updated=datetime.now()
                ),
                dawn_phenomenon_severity=None,
                hypo_episodes=0,
                hyper_episodes=0,
                risk_factors=[]
            )
        
        # Calculate average glucose
        avg_glucose = sum(glucose_values) / len(glucose_values)
        
        # Calculate time in range
        in_range_values = [v for v in glucose_values if HYPO_THRESHOLD <= v <= HYPER_THRESHOLD]
        time_in_range = (len(in_range_values) / len(glucose_values)) * 100  # percentage
        
        # Calculate optimal control
        optimal_values = [v for v in glucose_values if OPTIMAL_RANGE[0] <= v <= OPTIMAL_RANGE[1]]
        optimal_control = (len(optimal_values) / len(glucose_values)) * 100  # percentage
        
        # Calculate glucose variability (coefficient of variation)
        glucose_std_dev = calculate_std_dev(glucose_values)
        coefficient_of_variation = (glucose_std_dev / avg_glucose) * 100 if avg_glucose > 0 else 0
        
        # Count hypoglycemic episodes (below 70 mg/dL or 3.9 mmol/L)
        hypo_episodes = count_episodes(sorted_data, lambda v: v < HYPO_THRESHOLD)
        
        # Count hyperglycemic episodes (above 180 mg/dL or 10.0 mmol/L)
        hyper_episodes = count_episodes(sorted_data, lambda v: v > HYPER_THRESHOLD)
        
        # Detect dawn phenomenon (glucose rise between 4-8 AM)
        dawn_phenomenon_severity = detect_dawn_phenomenon(sorted_data)
        
        # Analyze trend by comparing first half with second half of the data
        half_point = len(sorted_data) // 2
        first_half = [item.get('value') for item in sorted_data[:half_point] if item.get('value') is not None]
        second_half = [item.get('value') for item in sorted_data[half_point:] if item.get('value') is not None]
        
        avg_trend_pct = 0.0
        time_in_range_trend_pct = 0.0
        variability_trend_pct = 0.0
        trend_direction = TrendDirection.INSUFFICIENT_DATA
        
        if len(first_half) > 3 and len(second_half) > 3:
            # Average glucose trend
            avg_first = sum(first_half) / len(first_half)
            avg_second = sum(second_half) / len(second_half)
            avg_trend_pct = ((avg_second - avg_first) / avg_first) * 100
            
            # Time in range trend
            first_in_range = [v for v in first_half if HYPO_THRESHOLD <= v <= HYPER_THRESHOLD]
            second_in_range = [v for v in second_half if HYPO_THRESHOLD <= v <= HYPER_THRESHOLD]
            first_time_in_range = (len(first_in_range) / len(first_half)) * 100
            second_time_in_range = (len(second_in_range) / len(second_half)) * 100
            time_in_range_trend_pct = second_time_in_range - first_time_in_range
            
            # Variability trend
            first_cv = (calculate_std_dev(first_half) / avg_first) * 100 if avg_first > 0 else 0
            second_cv = (calculate_std_dev(second_half) / avg_second) * 100 if avg_second > 0 else 0
            variability_trend_pct = ((second_cv - first_cv) / first_cv) * 100 if first_cv > 0 else 0
            
            # Determine overall trend direction based on time in range (more important than avg glucose)
            if abs(time_in_range_trend_pct) < 5:  # Less than 5% change is considered stable
                trend_direction = TrendDirection.STABLE
            elif time_in_range_trend_pct > 0:  # Increasing time in range is good
                trend_direction = TrendDirection.IMPROVING
            else:  # Decreasing time in range is concerning
                trend_direction = TrendDirection.DECLINING
                
            # Calculate confidence based on number of data points and consistency
            confidence_score = min(0.9, 0.4 + (len(glucose_values) / 200))
        else:
            confidence_score = 0.3  # Low confidence with limited data
        
        # Determine risk factors based on glucose patterns
        risk_factors = identify_glucose_risk_factors(
            glucose_values, 
            avg_glucose, 
            coefficient_of_variation, 
            hypo_episodes, 
            hyper_episodes,
            dawn_phenomenon_severity
        )
        
        return GlucoseAnalysis(
            average_glucose_trend=BiometricTrend(
                metric_name="average_glucose",
                trend_direction=trend_direction,
                confidence_score=confidence_score,
                average_value=avg_glucose,
                trend_percentage=avg_trend_pct,
                data_points=len(glucose_values),
                analysis_period_days=7,
                last_updated=datetime.now()
            ),
            time_in_range_trend=BiometricTrend(
                metric_name="time_in_range",
                trend_direction=trend_direction,
                confidence_score=confidence_score * 1.1,  # Higher confidence for time in range
                average_value=time_in_range,
                trend_percentage=time_in_range_trend_pct,
                data_points=len(glucose_values),
                analysis_period_days=7,
                last_updated=datetime.now()
            ),
            variability_trend=BiometricTrend(
                metric_name="glucose_variability",
                trend_direction=trend_direction,
                confidence_score=confidence_score * 0.9,  # Lower confidence for variability
                average_value=coefficient_of_variation,
                trend_percentage=variability_trend_pct,
                data_points=len(glucose_values),
                analysis_period_days=7,
                last_updated=datetime.now()
            ),
            dawn_phenomenon_severity=dawn_phenomenon_severity,
            hypo_episodes=hypo_episodes,
            hyper_episodes=hyper_episodes,
            risk_factors=risk_factors
        )
    except Exception as e:
        print(f"Error analyzing glucose data for user {user_id}: {e}")
        return None


def calculate_std_dev(values: List[float]) -> float:
    """
    Calculate standard deviation of a list of values.
    
    Args:
        values: List of numeric values
        
    Returns:
        Standard deviation
    """
    if len(values) < 2:
        return 0.0
    
    mean = sum(values) / len(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return variance ** 0.5  # square root to get standard deviation


def count_episodes(glucose_data: List[dict], condition_func) -> int:
    """
    Count the number of episodes where glucose values meet a specific condition.
    An episode is defined as a continuous period where the condition is true.
    
    Args:
        glucose_data: List of glucose readings with timestamps and values
        condition_func: Function that takes a glucose value and returns True/False
        
    Returns:
        Number of distinct episodes
    """
    if not glucose_data:
        return 0
    
    episodes = 0
    in_episode = False
    
    for reading in glucose_data:
        value = reading.get('value')
        if value is None:
            continue
        
        if condition_func(value):
            if not in_episode:
                episodes += 1
                in_episode = True
        else:
            in_episode = False
    
    return episodes


def detect_dawn_phenomenon(glucose_data: List[dict]) -> Optional[float]:
    """
    Detect and quantify dawn phenomenon - elevated glucose levels in early morning.
    
    Args:
        glucose_data: List of glucose readings with timestamps and values
        
    Returns:
        Severity score (0-10) or None if insufficient data
    """
    if not glucose_data:
        return None
    
    # Extract early morning readings (4 AM - 8 AM)
    morning_readings = []
    evening_readings = []
    
    for reading in glucose_data:
        if 'timestamp' not in reading or reading.get('value') is None:
            continue
        
        timestamp = reading['timestamp']
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            hour = dt.hour
            
            if 4 <= hour < 8:  # Early morning (4 AM - 8 AM)
                morning_readings.append(reading['value'])
            elif 22 <= hour or hour < 2:  # Evening/night (10 PM - 2 AM)
                evening_readings.append(reading['value'])
        except (ValueError, TypeError):
            continue
    
    if len(morning_readings) < 3 or len(evening_readings) < 3:
        return None
    
    # Calculate average glucose in morning vs evening
    avg_morning = sum(morning_readings) / len(morning_readings)
    avg_evening = sum(evening_readings) / len(evening_readings)
    
    # Calculate the percentage increase
    pct_increase = ((avg_morning - avg_evening) / avg_evening) * 100 if avg_evening > 0 else 0
    
    # Convert to severity scale (0-10)
    # 0% increase = 0 severity, 50% increase = 10 severity
    severity = min(10, max(0, pct_increase / 5))
    
    return severity if severity > 1.0 else None  # Only return if it's significant


def identify_glucose_risk_factors(
    glucose_values: List[float], 
    avg_glucose: float, 
    coefficient_of_variation: float,
    hypo_episodes: int,
    hyper_episodes: int,
    dawn_phenomenon_severity: Optional[float]
) -> List[str]:
    """
    Identify potential risk factors based on glucose patterns.
    
    Args:
        glucose_values: List of glucose values
        avg_glucose: Average glucose level
        coefficient_of_variation: Measure of glucose variability
        hypo_episodes: Number of hypoglycemic episodes
        hyper_episodes: Number of hyperglycemic episodes
        dawn_phenomenon_severity: Severity of dawn phenomenon (if detected)
        
    Returns:
        List of risk factor strings
    """
    risk_factors = []
    
    # Check for high average glucose
    if avg_glucose > 7.8:  # > 140 mg/dL
        if avg_glucose > 10.0:  # > 180 mg/dL
            risk_factors.append("Significantly elevated average glucose")
        else:
            risk_factors.append("Elevated average glucose")
    
    # Check for high glucose variability
    # CV > 36% is considered high, > 20% is moderate
    if coefficient_of_variation > 36:
        risk_factors.append("High glucose variability")
    elif coefficient_of_variation > 20:
        risk_factors.append("Moderate glucose variability")
    
    # Check for hypoglycemic episodes
    if hypo_episodes > 3:
        risk_factors.append("Frequent hypoglycemic episodes")
    elif hypo_episodes > 0:
        risk_factors.append("Occasional hypoglycemic episodes")
    
    # Check for hyperglycemic episodes
    if hyper_episodes > 3:
        risk_factors.append("Frequent hyperglycemic episodes")
    elif hyper_episodes > 0:
        risk_factors.append("Occasional hyperglycemic episodes")
    
    # Check for dawn phenomenon
    if dawn_phenomenon_severity is not None and dawn_phenomenon_severity > 5:
        risk_factors.append("Significant dawn phenomenon")
    elif dawn_phenomenon_severity is not None and dawn_phenomenon_severity > 2:
        risk_factors.append("Mild dawn phenomenon")
    
    # Check for too few readings
    if len(glucose_values) < 24:  # Less than 24 readings in a week is insufficient
        risk_factors.append("Insufficient monitoring frequency")
    
    return risk_factors


def get_glucose_data(user_id: str):
    """
    Get glucose data from Vital API for a given user.
    
    Args:
        user_id: Vital user ID
        
    Returns:
        Glucose data from Vital API
    """
    try:
        glucose_data = client.Vitals.glucose(
            user_id=user_id,
            start_date=(datetime.now() - timedelta(days=7)).isoformat(),
            end_date=datetime.now().isoformat()
        )
        if not glucose_data:
             return None
         # For now, just return the raw data
        return glucose_data
    except Exception as e:
        print(f"Error getting glucose data for user {user_id}: {e}")
        return None


def get_heartrate_data(user_id: str):
    """
    Get heartrate data from Vital API for a given user.
    
    Args:
        user_id: Vital user ID
        
    Returns:
        Heartrate data from Vital API
    """
    try:
        heartrate_data = client.Vitals.heartrate(
            user_id=user_id,
            start_date=(datetime.now() - timedelta(days=7)).isoformat(),
            end_date=datetime.now().isoformat()
        )
        if not heartrate_data:
            return None
        # For now, just return the raw data
        return heartrate_data
    except Exception as e:
        print(f"Error getting heartrate data for user {user_id}: {e}")
        return None
"""
Display the results of the parse_synthea_patient function without interaction.
"""

import sys
import os
from datetime import datetime

# Add parent directory to path so we can import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient
)

# Load the sample data
print("Loading sample Synthea data...")
synthea_data = load_sample_synthea_data()

if not synthea_data:
    print("Error: Failed to load sample data")
    sys.exit(1)

# Parse the data
print("\nParsing Synthea patient data...")
patient_profile = parse_synthea_patient(synthea_data)

# Print basic info
print(f"\nPatient ID: {patient_profile.patient_id}")
print(f"Total chronic conditions: {len(patient_profile.chronic_conditions)}")
print(f"Total health events: {len(patient_profile.health_events)}")
print(f"Total medications: {len(patient_profile.medications)}")

# Display first 10 chronic conditions
print("\n===== First 10 Chronic Conditions =====")
for i, condition in enumerate(patient_profile.chronic_conditions[:10], 1):
    print(f"\n{i}. {condition.description}")
    print(f"   Code: {condition.code}")
    print(f"   Status: {condition.status}")
    print(f"   Onset: {condition.onset_date}")
    if condition.severity:
        print(f"   Severity: {condition.severity}")

# Display first 10 health events
print("\n===== First 10 Health Events =====")
for i, event in enumerate(patient_profile.health_events[:10], 1):
    print(f"\n{i}. {event.description}")
    print(f"   Type: {event.event_type}")
    print(f"   Date: {event.date}")
    if event.code:
        print(f"   Code: {event.code}")
    if event.provider:
        print(f"   Provider: {event.provider}")

# Display first 10 medications
print("\n===== First 10 Medications =====")
for i, med in enumerate(patient_profile.medications[:10], 1):
    print(f"\n{i}. {med.display}")
    print(f"   Code: {med.code}")
    print(f"   Status: {med.status}")
    print(f"   Prescribed: {med.prescribed_date}")
    if med.dosage_instructions:
        print(f"   Instructions: {med.dosage_instructions}")

print("\nDone displaying parser results.")
"""
Test script for the wearables analytics service.

This script demonstrates the functionality of the heart rate and glucose trend analysis.
"""

import os
import sys
import json
from datetime import datetime, timedelta
import random

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import wearables analytics service
from services.wearables_analytics import (
    analyze_heartrate_trends,
    analyze_glucose_trends,
    get_heartrate_data,
    get_glucose_data,
    TrendDirection
)

# Mock user ID for testing
TEST_USER_ID = "test_user_id"

def load_sample_glucose_data():
    """Load sample glucose data from GLUCOSE_README.md"""
    try:
        with open("/Users/aheidari/Documents/GitHub/Ako/public-ai-engineering-interview-main/GLUCOSE_README.md", "r") as file:
            content = file.read()
            # Extract JSON data from the markdown file
            start_idx = content.find("```\n") + 4
            end_idx = content.find("```", start_idx)
            if start_idx > 4 and end_idx > start_idx:
                json_str = content[start_idx:end_idx].strip()
                return eval(json_str)  # Convert string to Python list
    except Exception as e:
        print(f"Error loading sample glucose data: {e}")
    return []

def generate_sample_heartrate_data():
    """Generate sample heart rate data for testing"""
    # Create a week's worth of heart rate data
    start_date = datetime.now() - timedelta(days=7)
    heart_rate_data = []
    
    # Generate data points for each day
    for day in range(7):
        current_date = start_date + timedelta(days=day)
        
        # Generate data points throughout the day
        for hour in range(0, 24, 2):  # Every 2 hours
            current_time = current_date + timedelta(hours=hour)
            
            # Generate realistic heart rate values
            if 0 <= hour < 6:  # Sleeping hours
                hr_value = random.randint(50, 65)
            elif 6 <= hour < 9:  # Morning activity
                hr_value = random.randint(65, 90)
            elif 9 <= hour < 18:  # Daytime
                hr_value = random.randint(60, 85)
            elif 18 <= hour < 22:  # Evening exercise
                hr_value = random.randint(70, 110)
            else:  # Late evening
                hr_value = random.randint(55, 75)
                
            heart_rate_data.append({
                'id': None,
                'timezone_offset': None,
                'type': 'automatic',
                'unit': 'bpm',
                'timestamp': current_time.isoformat() + "+00:00",
                'value': hr_value
            })
    
    return heart_rate_data

def test_heartrate_analysis():
    """Test the heart rate trend analysis functionality"""
    print("\n" + "=" * 50)
    print("HEART RATE TREND ANALYSIS")
    print("=" * 50)
    
    # Use sample heart rate data
    heart_rate_data = generate_sample_heartrate_data()
    
    # Mock the get_heartrate_data function to return our sample data
    def mock_get_heartrate_data(user_id):
        return heart_rate_data
    
    # Save the original function
    original_get_heartrate_data = get_heartrate_data
    
    try:
        # Replace with our mock function
        import services.wearables_analytics
        services.wearables_analytics.get_heartrate_data = mock_get_heartrate_data
        
        # Run the analysis
        print(f"Analyzing heart rate trends for user {TEST_USER_ID}...")
        hr_analysis = analyze_heartrate_trends(TEST_USER_ID)
        
        if hr_analysis:
            print("\nHeart Rate Analysis Results:")
            print(f"- Resting Heart Rate: {hr_analysis.resting_hr_trend.average_value:.1f} bpm")
            print(f"- Trend Direction: {hr_analysis.resting_hr_trend.trend_direction}")
            print(f"- Confidence Score: {hr_analysis.resting_hr_trend.confidence_score:.2f}")
            print(f"- Trend Percentage: {hr_analysis.resting_hr_trend.trend_percentage:.1f}%")
            
            print(f"\n- Max Heart Rate: {hr_analysis.max_hr_trend.average_value:.1f} bpm")
            
            if hr_analysis.hrv_trend:
                print(f"\n- Heart Rate Variability: {hr_analysis.hrv_trend.average_value:.1f}")
                print(f"- HRV Trend Direction: {hr_analysis.hrv_trend.trend_direction}")
            else:
                print("\n- Heart Rate Variability: Insufficient data")
            
            print(f"\n- Anomaly Count: {hr_analysis.anomaly_count}")
            
            if hr_analysis.risk_factors:
                print("\nRisk Factors:")
                for risk in hr_analysis.risk_factors:
                    print(f"- {risk}")
            else:
                print("\nNo risk factors identified.")
        else:
            print("Error: Unable to generate heart rate analysis.")
    
    finally:
        # Restore the original function
        services.wearables_analytics.get_heartrate_data = original_get_heartrate_data

def test_glucose_analysis():
    """Test the glucose trend analysis functionality"""
    print("\n" + "=" * 50)
    print("GLUCOSE TREND ANALYSIS")
    print("=" * 50)
    
    # Use sample glucose data
    glucose_data = load_sample_glucose_data()
    
    # Mock the get_glucose_data function to return our sample data
    def mock_get_glucose_data(user_id):
        return glucose_data
    
    # Save the original function
    original_get_glucose_data = get_glucose_data
    
    try:
        # Replace with our mock function
        import services.wearables_analytics
        services.wearables_analytics.get_glucose_data = mock_get_glucose_data
        
        # Run the analysis
        print(f"Analyzing glucose trends for user {TEST_USER_ID}...")
        glucose_analysis = analyze_glucose_trends(TEST_USER_ID)
        
        if glucose_analysis:
            print("\nGlucose Analysis Results:")
            print(f"- Average Glucose: {glucose_analysis.average_glucose_trend.average_value:.1f} mmol/L")
            print(f"- Trend Direction: {glucose_analysis.average_glucose_trend.trend_direction}")
            print(f"- Confidence Score: {glucose_analysis.average_glucose_trend.confidence_score:.2f}")
            print(f"- Trend Percentage: {glucose_analysis.average_glucose_trend.trend_percentage:.1f}%")
            
            print(f"\n- Time in Range: {glucose_analysis.time_in_range_trend.average_value:.1f}%")
            print(f"- Time in Range Trend: {glucose_analysis.time_in_range_trend.trend_percentage:.1f}%")
            
            print(f"\n- Glucose Variability: {glucose_analysis.variability_trend.average_value:.1f}%")
            
            if glucose_analysis.dawn_phenomenon_severity is not None:
                print(f"\n- Dawn Phenomenon Severity: {glucose_analysis.dawn_phenomenon_severity:.1f}/10")
            else:
                print("\n- Dawn Phenomenon: Not detected")
            
            print(f"\n- Hypoglycemic Episodes: {glucose_analysis.hypo_episodes}")
            print(f"- Hyperglycemic Episodes: {glucose_analysis.hyper_episodes}")
            
            if glucose_analysis.risk_factors:
                print("\nRisk Factors:")
                for risk in glucose_analysis.risk_factors:
                    print(f"- {risk}")
            else:
                print("\nNo risk factors identified.")
        else:
            print("Error: Unable to generate glucose analysis.")
    
    finally:
        # Restore the original function
        services.wearables_analytics.get_glucose_data = original_get_glucose_data

if __name__ == "__main__":
    print("Testing Wearables Analytics Service")
    print("=" * 50)
    
    # Test heart rate analysis
    test_heartrate_analysis()
    
    # Test glucose analysis
    test_glucose_analysis()
    
    print("\n" + "=" * 50)
    print("Testing complete!")
    print("=" * 50)
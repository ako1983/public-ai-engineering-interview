"""
View EMR parser results.
This script loads the FHIR data, runs the parser functions, and prints the results.
"""

import sys
import os
from datetime import datetime

# Add parent directory to path so we can import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient,
    extract_chronic_conditions,
    extract_vital_events,
    initialize_emr_data
)

def view_parse_synthea_patient():
    """Load data, parse it, and display the results"""
    print("\n===== Results from parse_synthea_patient =====\n")
    
    # Load the sample data
    print("Loading sample Synthea data...")
    synthea_data = load_sample_synthea_data()
    
    if not synthea_data:
        print("Error: Failed to load sample data")
        return
    
    # Parse the data
    print("\nParsing Synthea patient data...")
    patient_profile = parse_synthea_patient(synthea_data)
    
    # Print basic info
    print(f"\nPatient ID: {patient_profile.patient_id}")
    print(f"Total chronic conditions: {len(patient_profile.chronic_conditions)}")
    print(f"Total health events: {len(patient_profile.health_events)}")
    print(f"Total medications: {len(patient_profile.medications)}")
    print(f"Last updated: {patient_profile.last_updated}")
    
    # Show sample of chronic conditions
    print("\n----- Sample of Chronic Conditions -----")
    for i, condition in enumerate(patient_profile.chronic_conditions[:10], 1):
        print(f"\n{i}. {condition.description}")
        print(f"   Code: {condition.code}")
        print(f"   Status: {condition.status}")
        print(f"   Onset: {condition.onset_date}")
        if condition.severity:
            print(f"   Severity: {condition.severity}")
    
    if len(patient_profile.chronic_conditions) > 10:
        print(f"\n...and {len(patient_profile.chronic_conditions) - 10} more conditions.")
    
    # Show sample of health events
    print("\n----- Sample of Health Events -----")
    for i, event in enumerate(patient_profile.health_events[:10], 1):
        print(f"\n{i}. {event.description}")
        print(f"   Type: {event.event_type}")
        print(f"   Date: {event.date}")
        print(f"   Code: {event.code}")
        if event.provider:
            print(f"   Provider: {event.provider}")
    
    if len(patient_profile.health_events) > 10:
        print(f"\n...and {len(patient_profile.health_events) - 10} more events.")
    
    # Show sample of medications
    print("\n----- Sample of Medications -----")
    for i, med in enumerate(patient_profile.medications[:10], 1):
        print(f"\n{i}. {med.display}")
        print(f"   Code: {med.code}")
        print(f"   Status: {med.status}")
        print(f"   Prescribed: {med.prescribed_date}")
        if med.dosage_instructions:
            print(f"   Instructions: {med.dosage_instructions}")
    
    if len(patient_profile.medications) > 10:
        print(f"\n...and {len(patient_profile.medications) - 10} more medications.")
    
    return patient_profile

def view_filtered_results():
    """Display results of the filtering functions"""
    print("\n===== Filtered Results =====\n")
    
    # Initialize data first
    print("Initializing EMR data...")
    initialize_emr_data()
    
    # Extract chronic conditions
    print("\nExtracting chronic conditions...")
    chronic_conditions = extract_chronic_conditions("test_user_id")
    
    print(f"\nFound {len(chronic_conditions)} chronic conditions:")
    for i, condition in enumerate(chronic_conditions, 1):
        print(f"\n{i}. {condition.description}")
        print(f"   Code: {condition.code}")
        print(f"   Status: {condition.status}")
        print(f"   Onset: {condition.onset_date}")
        if condition.severity:
            print(f"   Severity: {condition.severity}")
    
    # Extract vital events
    print("\nExtracting vital events...")
    vital_events = extract_vital_events("test_user_id")
    
    print(f"\nFound {len(vital_events)} vital events:")
    for i, event in enumerate(vital_events, 1):
        print(f"\n{i}. {event.description}")
        print(f"   Type: {event.event_type}")
        print(f"   Date: {event.date}")
        if event.code:
            print(f"   Code: {event.code}")
        if event.provider:
            print(f"   Provider: {event.provider}")

if __name__ == "__main__":
    print("EMR Parser Results")
    print("==================")
    
    # First show raw parser results
    patient_profile = view_parse_synthea_patient()
    
    # Then show filtered results
    view_filtered_results()
    
    print("\nDone viewing EMR parser results.")
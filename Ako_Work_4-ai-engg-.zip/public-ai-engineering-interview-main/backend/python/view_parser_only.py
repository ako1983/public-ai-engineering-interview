"""
View only the parse_synthea_patient function results.
"""

import sys
import os
from datetime import datetime
import json

# Add parent directory to path so we can import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient
)

def main():
    print("===== Results from parse_synthea_patient =====\n")
    
    # Load the sample data
    print("Loading sample Synthea data...")
    synthea_data = load_sample_synthea_data()
    
    if not synthea_data:
        print("Error: Failed to load sample data")
        return
    
    # Parse the data
    print("\nParsing Synthea patient data...")
    patient_profile = parse_synthea_patient(synthea_data)
    
    # Print basic info
    print(f"\nPatient ID: {patient_profile.patient_id}")
    print(f"Total chronic conditions: {len(patient_profile.chronic_conditions)}")
    print(f"Total health events: {len(patient_profile.health_events)}")
    print(f"Total medications: {len(patient_profile.medications)}")
    
    # Ask user what they want to see
    while True:
        print("\nWhat would you like to see?")
        print("1. All chronic conditions")
        print("2. All health events (first 20)")
        print("3. All medications")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ")
        
        if choice == "1":
            print("\n===== All Chronic Conditions =====")
            for i, condition in enumerate(patient_profile.chronic_conditions, 1):
                print(f"\n{i}. {condition.description}")
                print(f"   Code: {condition.code}")
                print(f"   Status: {condition.status}")
                print(f"   Onset: {condition.onset_date}")
                if condition.severity:
                    print(f"   Severity: {condition.severity}")
        
        elif choice == "2":
            print("\n===== Health Events (first 20) =====")
            for i, event in enumerate(patient_profile.health_events[:20], 1):
                print(f"\n{i}. {event.description}")
                print(f"   Type: {event.event_type}")
                print(f"   Date: {event.date}")
                if event.code:
                    print(f"   Code: {event.code}")
                if event.provider:
                    print(f"   Provider: {event.provider}")
            
            if len(patient_profile.health_events) > 20:
                print(f"\n...and {len(patient_profile.health_events) - 20} more events.")
        
        elif choice == "3":
            print("\n===== All Medications =====")
            for i, med in enumerate(patient_profile.medications, 1):
                print(f"\n{i}. {med.display}")
                print(f"   Code: {med.code}")
                print(f"   Status: {med.status}")
                print(f"   Prescribed: {med.prescribed_date}")
                if med.dosage_instructions:
                    print(f"   Instructions: {med.dosage_instructions}")
        
        elif choice == "4":
            print("\nExiting. Goodbye!")
            break
        
        else:
            print("\nInvalid choice. Please try again.")

if __name__ == "__main__":
    main()
"""
View patient data from the EMR parser.
This script shows all the key information without requiring user interaction.
"""

import os
import sys
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import our services
from services.emr_parser import (
    load_sample_synthea_data,
    parse_synthea_patient,
    extract_chronic_conditions,
    extract_vital_events,
    initialize_emr_data
)

def display_patient_summary():
    """Display a summary of the patient's health profile."""
    print("\n" + "=" * 50)
    print("Patient Health Summary")
    print("=" * 50)
    
    # Initialize EMR data
    print("Initializing EMR data...")
    initialize_emr_data()
    
    # Get raw data for exploration
    synthea_data = load_sample_synthea_data()
    patient_profile = parse_synthea_patient(synthea_data)
    
    # Get filtered data
    chronic_conditions = extract_chronic_conditions("test_user_id")
    vital_events = extract_vital_events("test_user_id")
    
    print(f"Patient ID: {patient_profile.patient_id}")
    print(f"Total Conditions: {len(patient_profile.chronic_conditions)}")
    print(f"Active Chronic Conditions: {len(chronic_conditions)}")
    print(f"Total Health Events: {len(patient_profile.health_events)}")
    print(f"Significant Health Events: {len(vital_events)}")
    print(f"Current Medications: {len(patient_profile.medications)}")
    
    # Demographics summary (from FHIR data)
    patient_resource = None
    for entry in synthea_data.get("entry", []):
        if entry.get("resource", {}).get("resourceType") == "Patient":
            patient_resource = entry.get("resource", {})
            break
    
    if patient_resource:
        # Extract name
        name = "Unknown"
        if patient_resource.get("name") and len(patient_resource["name"]) > 0:
            name_parts = []
            if patient_resource["name"][0].get("given"):
                name_parts.extend(patient_resource["name"][0]["given"])
            if patient_resource["name"][0].get("family"):
                name_parts.append(patient_resource["name"][0]["family"])
            if name_parts:
                name = " ".join(name_parts)
        
        # Extract gender and birthdate
        gender = patient_resource.get("gender", "Unknown")
        birthdate = patient_resource.get("birthDate", "Unknown")
        
        # Calculate age
        age = "Unknown"
        if birthdate != "Unknown":
            try:
                birth_date = datetime.strptime(birthdate, "%Y-%m-%d")
                age = (datetime.now() - birth_date).days // 365
            except:
                pass
        
        print("\nPatient Demographics:")
        print(f"Name: {name}")
        print(f"Gender: {gender.capitalize()}")
        print(f"Birthdate: {birthdate}")
        print(f"Age: {age} years")
    
    # Show active chronic conditions
    print("\nActive Chronic Conditions:")
    for i, condition in enumerate(chronic_conditions, 1):
        onset_str = condition.onset_date.strftime("%Y-%m-%d") if condition.onset_date else "Unknown"
        print(f"  {i}. {condition.description} (Since: {onset_str})")
    
    # Show recent vital events
    print("\nRecent Significant Health Events:")
    for i, event in enumerate(vital_events[:5], 1):
        date_str = event.date.strftime("%Y-%m-%d")
        provider_str = f" at {event.provider}" if event.provider else ""
        print(f"  {i}. {event.description} ({event.event_type}) on {date_str}{provider_str}")
    if len(vital_events) > 5:
        print(f"  ... and {len(vital_events) - 5} more events.")
    
    # Show current medications
    active_meds = [m for m in patient_profile.medications if m.status.lower() == "active"]
    print("\nCurrent Medications:")
    for i, med in enumerate(active_meds, 1):
        instructions = f" - {med.dosage_instructions}" if med.dosage_instructions else ""
        print(f"  {i}. {med.display}{instructions}")
    
    print("\n" + "=" * 50)
    print("Data Exploration Examples")
    print("=" * 50)
    
    # Example: Show all conditions with "pain" in the description
    pain_conditions = [c for c in patient_profile.chronic_conditions 
                      if "pain" in c.description.lower()]
    print(f"\nAll conditions related to pain ({len(pain_conditions)} found):")
    for i, condition in enumerate(pain_conditions, 1):
        status_str = f"({condition.status})"
        print(f"  {i}. {condition.description} {status_str}")
    
    # Example: Show emergency visits
    emergency_events = [e for e in patient_profile.health_events 
                       if e.event_type == "emergency"]
    print(f"\nAll emergency visits ({len(emergency_events)} found):")
    for i, event in enumerate(emergency_events, 1):
        date_str = event.date.strftime("%Y-%m-%d")
        provider_str = f" at {event.provider}" if event.provider else ""
        print(f"  {i}. {event.description} on {date_str}{provider_str}")
    
    # Example: Show dental procedures
    dental_events = [e for e in patient_profile.health_events 
                    if "dental" in e.description.lower()]
    print(f"\nAll dental procedures ({len(dental_events)} found):")
    for i, event in enumerate(dental_events[:5], 1):
        date_str = event.date.strftime("%Y-%m-%d")
        print(f"  {i}. {event.description} on {date_str}")
    if len(dental_events) > 5:
        print(f"  ... and {len(dental_events) - 5} more dental procedures.")
    
    # Example: Show pain medications
    pain_meds = [m for m in patient_profile.medications 
                if "fentanyl" in m.display.lower() or "tramadol" in m.display.lower()]
    print(f"\nAll pain medications ({len(pain_meds)} found):")
    for i, med in enumerate(pain_meds[:5], 1):
        status_str = f"({med.status})"
        print(f"  {i}. {med.display} {status_str}")
    if len(pain_meds) > 5:
        print(f"  ... and {len(pain_meds) - 5} more pain medications.")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    display_patient_summary()